(function($) {
  	var body = $('body');
    var doc = $(document);  

  	var iconNav = $('#showLeftPush');
    var iconCart = $('#cartToggle');
  
    var dropdownCart = $('#dropdown-cart');
  	var navCustomer = $('.nav-customer');
  	var wrapperCart = $('.wrapper-top-cart');
    var cartNoItems = dropdownCart.find('.no-items');
    var cartHasItems = dropdownCart.find('.has-items');
    var miniProductList = dropdownCart.find('.mini-products-list');
  
  	if ($('.collection-sidebar').length) {
      History.Adapter.bind(window, 'statechange', function() {
        var State = History.getState();

        if (!sneak.isSidebarAjaxClick) {
          sneak.sidebarParams();

          var newurl = sneak.sidebarCreateUrl();

          sneak.sidebarGetContent(newurl);
        }

        sneak.isSidebarAjaxClick = false;
      });
    };
  
    var changeSwatch = function(swatch) {
      swatch.change(function() {
        var optionIndex = $(this).closest('.swatch').attr('data-option-index');
        var optionValue = $(this).val();

        $(this)
          .closest('form')
          .find('.single-option-selector')
          .eq(optionIndex)
          .val(optionValue)
          .trigger('change');
      });
    };

    if (window.use_color_swatch) {

      changeSwatch($('.swatch :radio'));

      Shopify.productOptionsMap = {};
      Shopify.quickViewOptionsMap = {};

      Shopify.updateOptionsInSelector = function(selectorIndex, wrapperSlt) {
        
        Shopify.optionsMap = wrapperSlt === '.product' ? Shopify.productOptionsMap : Shopify.quickViewOptionsMap;

        switch (selectorIndex) {
          case 0:
            var key = 'root';
            var selector = $(wrapperSlt + '.single-option-selector:eq(0)');
            break;
          case 1:
            var key = $(wrapperSlt + ' .single-option-selector:eq(0)').val();
            var selector = $(wrapperSlt + ' .single-option-selector:eq(1)');
            break;
          case 2:
            var key = $(wrapperSlt + ' .single-option-selector:eq(0)').val();
            key += ' / ' + $(wrapperSlt + ' .single-option-selector:eq(1)').val();
            var selector = $(wrapperSlt + ' .single-option-selector:eq(2)');
        }

        var initialValue = selector.val();

        selector.empty();

        var availableOptions = Shopify.optionsMap[key];

        if (availableOptions && availableOptions.length) {
          for (var i = 0; i < availableOptions.length; i++) {
            var option = availableOptions[i];

            var newOption = $('<option></option>').val(option).html(option);

            selector.append(newOption);
          }

          $(wrapperSlt + ' .swatch[data-option-index="' + selectorIndex + '"] .swatch-element').each(function() {
            if ($.inArray($(this).attr('data-value'), availableOptions) !== -1) {
              $(this).removeClass('soldout').find(':radio').removeAttr('disabled', 'disabled').removeAttr('checked');
            }
            else {
              $(this).addClass('soldout').find(':radio').removeAttr('checked').attr('disabled', 'disabled');
            }
          });

          if ($.inArray(initialValue, availableOptions) !== -1) {
            selector.val(initialValue);
          }
          
          selector.trigger('change');
        };
      };

      Shopify.linkOptionSelectors = function(product, wrapperSlt) {
        // Building our mapping object.
        Shopify.optionsMap = wrapperSlt === '.product' ? Shopify.productOptionsMap : Shopify.quickViewOptionsMap;
        
        for (var i = 0; i < product.variants.length; i++) {
          var variant = product.variants[i];

          if (variant.available) {
            // Gathering values for the 1st drop-down.
            Shopify.optionsMap['root'] = Shopify.optionsMap['root'] || [];

            Shopify.optionsMap['root'].push(variant.option1);
            Shopify.optionsMap['root'] = Shopify.uniq(Shopify.optionsMap['root']);

            // Gathering values for the 2nd drop-down.
            if (product.options.length > 1) {
              var key = variant.option1;
              Shopify.optionsMap[key] = Shopify.optionsMap[key] || [];
              Shopify.optionsMap[key].push(variant.option2);
              Shopify.optionsMap[key] = Shopify.uniq(Shopify.optionsMap[key]);
            }

            // Gathering values for the 3rd drop-down.
            if (product.options.length === 3) {
              var key = variant.option1 + ' / ' + variant.option2;
              Shopify.optionsMap[key] = Shopify.optionsMap[key] || [];
              Shopify.optionsMap[key].push(variant.option3);
              Shopify.optionsMap[key] = Shopify.uniq(Shopify.optionsMap[key]);
            }
          }
        };

        // Update options right away.
        Shopify.updateOptionsInSelector(0, wrapperSlt);

        if (product.options.length > 1) Shopify.updateOptionsInSelector(1, wrapperSlt);
        if (product.options.length === 3) Shopify.updateOptionsInSelector(2, wrapperSlt);

        // When there is an update in the first dropdown.
        $(wrapperSlt + " .single-option-selector:eq(0)").change(function() {
          Shopify.updateOptionsInSelector(1, wrapperSlt);
          if (product.options.length === 3) Shopify.updateOptionsInSelector(2, wrapperSlt);
          return true;
        });

        // When there is an update in the second dropdown.
        $(wrapperSlt + " .single-option-selector:eq(1)").change(function() {
          if (product.options.length === 3) Shopify.updateOptionsInSelector(2, wrapperSlt);
          return true;
        });

      };
    };

    $(document).ready(function() {
      sneak.init();
    });
  
    $(window).off('resize.mobileMenu').on('resize.mobileMenu', function() {
      sneak.initMobileMenu();
      sneak.initDropdownMenuMobile();
    });
  
    $(window).off('resize.initDropdownFooter').on('resize.initDropdownFooter', function() {
      sneak.initDropdownFooterMenu();
    });
  
  	if($('.template-collection').length || $('.template-product').length || $('.template-blog').length || $('.template-article').length) {
      var currentWinWidth = $(window).width();
      var resizeTimeout;
      
      $(window).off('resize.sidebarInitToggle').on('resize.sidebarInitToggle', function() {
        clearTimeout(resizeTimeout);
        
        resizeTimeout = setTimeout(function() {
          if (currentWinWidth !== $(window).width()){
            sneak.sidebarInitToggle();
            currentWinWidth = $(window).width();
          }
        }, 50);
      });
    };
  
    if($('.template-product').length) {
      $(window).off('resize.initZoom').on('resize.initZoom', function() {
        sneak.initZoom();
      });
    };
  
  
    var sneak = {
      sneakTimeout: null,
      isSidebarAjaxClick: false,
      init: function() {
		this.closeHeaderTop();
        this.initSearchToggle();
        this.initMobileMenu();
        this.initDropdownMenuMobile();
        this.initDropdownLogin();
        this.initDropdownCart();
        this.closeDropdown();
        this.initColorSwatchGrid();
        this.initScrollTop();
        this.initFiveItemSlider($('.slider-brand-wrapper .slide_brand'));
        this.closeModal();
        this.initAddToCart();
        this.initQuickView();
        this.initResizeImage($('.products-grid .product-image img'));        
        this.initMegaSliderStyle3();
        this.initPoliCySlider();
        this.initFixedTopMenu();
        this.initDropdownFooterMenu();
        
        if($('.template-index').length) {
          this.initFiveItemSliderMb2($('.hompage-category .widget-content'));
          this.initBannerSliderLeftCol();
        };
        
        if($('.template-collection').length || $('.template-product').length || $('.template-blog').length || $('.template-article').length) {
          this.initProductSidebarSlider();
          this.dropDownSubCategory();
          this.sidebarInitToggle();
        };
        
        if($('.template-collection').length) {
          this.initSidebar();
          this.initToolbar();
          this.sidebarMapPaging();
          this.initInfiniteScrolling();
        };
        
        if($('.template-product').length) {
          this.initProductMoreview();
          this.initRelatedProductSlider();
          this.initProductAddToCart();
          this.initZoom();
        };
        
        if($('.template-cart').length) {
          this.initCartQty();
        };
        
        if($('.template-search').length) {
          this.sidebarMapPaging();
          this.sidebarParams();
          this.initInfiniteScrolling();
        };
      },
      
      closeHeaderTop: function() {
        var headerTopSlt = '.header-top';
        var headerTopElm = $(headerTopSlt);
      	var headerTopCloseSlt = '.header-top a.close';
        var headerTopCloseElm = $(headerTopCloseSlt);
        
        if(headerTopCloseElm.length && headerTopCloseElm.is(':visible')) {
          if ($.cookie('headerTop') == 'closed') {
            headerTopElm.remove();
          };
          
          body.off('click.closeHeaderTop', headerTopCloseSlt).on('click.closeHeaderTop', headerTopCloseSlt, function(e) {
            e.preventDefault();
            e.stopPropagation();
            
			headerTopElm.remove();
            $.cookie('headerTop', 'closed', {expires:1, path:'/'});
          });
        }
      },
      
      initSearchToggle: function() {
      	var mbSearch = $('#mobile-search-toggle');
        var navSearch = $('.wrapper-navigation .nav-search');
        
        if(mbSearch.length) {
          mbSearch.off('click.initSearchToggle').on('click.initSearchToggle', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            if (wrapperCart.hasClass('is-open')) {
              wrapperCart.removeClass('is-open');
            };
            
            if(navCustomer.hasClass('is-open')) {
              navCustomer.removeClass('is-open');
            };
            
          	$(this).toggleClass('search-open');
            navSearch.toggle();
          });
          
          doc.off('click.closeSearch').on('click.closeSearch', function(e) {
            if (!$(e.target).closest('.nav-search').length && mbSearch.hasClass('search-open')) {
              mbSearch.removeClass('search-open');
              navSearch.hide();
            }        
          });
        }
      },
      
      initMobileMenu:function() {
        if(window.innerWidth < 992) {
          $('.header-bottom-wrapper').appendTo($('.wrapper-navigation .mb-area'));
        }
        else {
          $('.header-bottom-wrapper').prependTo($('.header-bottom-panel'));
        };
        
        if(iconNav.is(':visible')) {
          body.off('click.toggleNav', '#showLeftPush').on('click.toggleNav', '#showLeftPush', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            if($('.search-results').is(':visible')) {
              $('.search-results').hide();
            };
            
            if($('#mobile-search-toggle').hasClass('search-open')) {
              $('#mobile-search-toggle').removeClass('search-open');
              $('.wrapper-navigation .nav-search').hide();
            }
            
            if (wrapperCart.hasClass('is-open')) {
              wrapperCart.removeClass('is-open');
            };
            
            if(navCustomer.hasClass('is-open')) {
              navCustomer.removeClass('is-open');
            };

            iconNav.toggleClass('open');
            $('html').toggleClass('translate');                        
          });                

          sneak.closeMenuMobile();
        };                
      },

      closeMenuMobile: function() {
        var overlay = $('.translate-overlay');
        
        overlay.off('click.toggleNav').on('click.toggleNav', function(e) {
          if (!$(e.target).closest('.nav-bar-container').length && iconNav.hasClass('open')) {
            iconNav.removeClass('open');
            $('html').removeClass('translate');
          }        
        });
      },
      
      linkClickDropdownMenu: function() {
        var menuMobile = $('.site-nav .dropdown .menu__moblie');

        menuMobile.off('click.current').on('click.current', function(e) {
          var isClickOneTime = $(this).attr('is-click-1-time');

          if(isClickOneTime !== 'true') {
            e.preventDefault();
            e.stopPropagation();

            $(this).attr('is-click-1-time', 'true');

            $(this).next().slideDown();
            $(this).children('.icon-dropdown').addClass("mobile-toggle-open");
            
            clearTimeout(sneak.sneakTimeout);
            
            sneak.sneakTimeout = setTimeout(function() {
              if($('.mega-featured-categories .cate-slider').hasClass('slick-initialized')) {
              	$('.mega-featured-categories .cate-slider').slick('unslick');    
              	$('.mega-featured-categories .cate-slider').find('.slick-list').removeAttr('style');
              };
              sneak.initMegaSliderStyle3();
            }, 50);
          };
        });
      },
      
      initDropdownMenuMobile: function() {
        if(window.innerWidth < 1600) {
          var iconDropdown = $('.site-nav .icon-dropdown');

          iconDropdown.off('click.dropdownMenu').on('click.dropdownMenu', function(e) {
            e.preventDefault();
            e.stopPropagation();

            if($(this).hasClass('mobile-toggle-open')) {
              $(this).parent().next().slideUp();
              $(this).removeClass("mobile-toggle-open");                           
            }

            else {              
              $(this).parent().next().slideDown();
              $(this).addClass("mobile-toggle-open");
              
              clearTimeout(sneak.sneakTimeout);
              
              sneak.sneakTimeout = setTimeout(function() {
                if($('.mega-featured-categories .cate-slider').hasClass('slick-initialized')) {
                  $('.mega-featured-categories .cate-slider').slick('unslick');    
                  $('.mega-featured-categories .cate-slider').find('.slick-list').removeAttr('style');
                };

                sneak.initMegaSliderStyle3();
              }, 50);
            }
          });

          sneak.linkClickDropdownMenu();
        }

        else {
          $('.site-nav-dropdown').css({"display": ""});
        };
      },
      
      initFixedTopMenu: function() {
        if(window.fixtop_menu = true) {
          $(window).scroll(function() {
            var scrollTop = $(this).scrollTop();
            var wrapNav = $('.wrapper-navigation');

            if(scrollTop > 200) {
              body.addClass('fixed_top');
              wrapNav.addClass('fadeInDown');
              wrapNav.css({'position': 'fixed', 'left': 0, 'right': 0, 'top': 0 });
            }
            else {
              body.removeClass('fixed_top');
              wrapNav.removeClass('fadeInDown');
              wrapNav.css({'position': '', 'left': '', 'right': '', 'top': '' });
            }
          });
        };        
      },
      
      doOpenDropdown: function(icon, parentSlt) {
        icon.off('click.toogleDropdown').on('click.toogleDropdown', function(e) {
          e.preventDefault();
          e.stopPropagation();
          
          if($('.search-results').is(':visible')) {
            $('.search-results').hide();
          };
          
          if($('#mobile-search-toggle').hasClass('search-open')) {
            $('#mobile-search-toggle').removeClass('search-open');
            $('.wrapper-navigation .nav-search').hide();
          }
          
          if(parentSlt == '.nav-customer') {
            if (wrapperCart.hasClass('is-open')) {
              wrapperCart.removeClass('is-open');
            }
          }
          else if(parentSlt == '.wrapper-top-cart') {
            if(navCustomer.hasClass('is-open')) {
              navCustomer.removeClass('is-open');
            };
          };

          $(this).parent(parentSlt).toggleClass('is-open');
      	});
      },
      
      closeDropdown:function() {
        var dropdownCustomerSlt = '#dropdown-customer';
        var dropdownCartSlt = '#dropdown-cart';
        
      	doc.off('click.closeDropdown').on('click.closeDropdown', function(e) {   
          if ((!$(e.target).closest(dropdownCustomerSlt).length && !$(e.target).closest('.nav-customer').length && navCustomer.hasClass('is-open')) || (!$(e.target).closest(dropdownCartSlt).length && !$(e.target).closest('.wrapper-top-cart').length && wrapperCart.hasClass('is-open'))) {
            wrapperCart.removeClass('is-open');
            navCustomer.removeClass('is-open');
          }
        });
      },
      
      initDropdownLogin: function() {
      	sneak.doOpenDropdown($('#icon-user'), '.nav-customer');        
      },
      
      clickDropdownCart:function() {
      	sneak.doOpenDropdown($('#cartToggle'), '.wrapper-top-cart');        
      },
      
      initDropdownCart:function() {
      	if(window.dropdowncart_type == 'click') {
          sneak.clickDropdownCart();
        }
        else {
          if(!('ontouchstart' in document)) {
              iconCart.hover(function() {
                if(navCustomer.hasClass('is-open')) {
                  navCustomer.removeClass('is-open');
                };
                
                if (!wrapperCart.hasClass('is-open')) {
                  wrapperCart.addClass('is-open');
                }                                          
              });

              wrapperCart.mouseleave(function() {
                if (wrapperCart.hasClass('is-open')) {
                  wrapperCart.removeClass('is-open');
                };
              });

            }

          else {
            sneak.clickDropdownCart();
          };
        };
        
        sneak.checkItemsInDropdownCart();
        sneak.removeItemDropdownCart();
      },
      
      initFiveItemSlider: function(fiveItemSlider) {
        if(fiveItemSlider.length && !fiveItemSlider.hasClass('slick-initialized')) {
          fiveItemSlider.slick({
            infinite: true,
            verticalSwiping: false,
            speed: 500,
            slidesToShow: 5,
            slidesToScroll: 1,
            nextArrow: '<button type="button" class="slick-next"><i class="fa fa-angle-right"></i></button>',
            prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-angle-left"></i></button>',
            responsive: [
              {
                breakpoint: 1200,
                settings: {
                  slidesToShow: 4,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 992,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 768,
                settings: {
                  slidesToShow: 2,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 480,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
              }
            ]
          });
        };
      },
      
      initFiveItemSliderMb2: function(fiveItemSliderMb2) {
        if(fiveItemSliderMb2.length && !fiveItemSliderMb2.hasClass('slick-initialized')) {
          fiveItemSliderMb2.slick({
            infinite: false,
            verticalSwiping: false,
            speed: 500,
            slidesToShow: 5,
            dots: true,
            slidesToScroll: 1,
            nextArrow: '<button type="button" class="slick-next"><i class="fa fa-angle-right"></i></button>',
            prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-angle-left"></i></button>',
            responsive: [
              {
                breakpoint: 1200,
                settings: {
                  slidesToShow: 4,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 992,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 768,
                settings: {
                  slidesToShow: 2,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 370,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
              }
            ]
          });
        };
      },
      
      initColorSwatchGrid: function() {
        var itemSwatchSlt = '.item-swatch li label';
        var itemSwatch = $(itemSwatchSlt);
        
        body.off('click.toggleClass').on('click.toggleClass', itemSwatchSlt, function() {
          var self = $(this);
          var productItemElm = self.closest('.grid-item');
                    
          itemSwatch.removeClass('active');
          
          self.addClass('active');
          
          var newImage = self.data('img');
          
          if(newImage) {
          	productItemElm.find('.product-grid-image img').attr({ src: newImage }); 
          }
          
          return false;
        });
      },
      
      initBannerSliderLeftCol: function() {
      	var bannerSlider = $('.block-banners .banner-slider');
        
        if(bannerSlider.length && !bannerSlider.hasClass('slick-initialized')) {
          bannerSlider.slick({
            dots: true,
            infinite: true,
            autoplay: true,
            slidesToScroll: 1,
            verticalSwiping: false,
            cssEase: "ease",
            speed: 500,
            arrows: false
          }); 
        };
      },
      
      initScrollTop: function() {
        $(window).scroll(function() {
          if ($(this).scrollTop() > 220) {
            $('#back-top').fadeIn(400);
          }

          else {
            $('#back-top').fadeOut(400);
          }
        });

        $('#back-top').off('click.scrollTop').on('click.scrollTop', function(e) {
          e.preventDefault();
          e.stopPropagation();

          $('html, body').animate({scrollTop: 0}, 400);
          return false;
        });
      },
      
      initProductSidebarSlider: function() {
      	var widgetFeaturedProduct = $('.sidebar .widget-featured-product');
        
        widgetFeaturedProduct.each(function() {
          var productGrid = $(this).find('.products-grid');
          
          if(productGrid.length && !productGrid.hasClass('slick-initialized')) {
            productGrid.slick({
              dots: false,
              slidesToScroll: 1,
              verticalSwiping: false,
              nextArrow: '<button type="button" class="slick-next"><i class="fa fa-angle-right"></i></button>',
              prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-angle-left"></i></button>',
              responsive: [
                {
                  breakpoint: 992,
                  settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1
                  }
                },
                {
                  breakpoint: 768,
                  settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                  }
                },
                {
                  breakpoint: 480,
                  settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                  }
                }
              ]
            });
          };           
        });
      },
      
      dropDownSubCategory: function() {
        var iconDropdownSlt = '.sidebar-links .icon-dropdown';
        var iconDropdown = $(iconDropdownSlt);

        body.off('click.dropDownSubCategory', iconDropdownSlt).on('click.dropDownSubCategory', iconDropdownSlt, function(e) {
          e.preventDefault();
          e.stopPropagation();

          var self = $(this);
          var parent = self.parent();

          if(parent.hasClass('open')) {
            parent.removeClass('open');
            self.next().hide();
          }
          else {
            parent.addClass('open');
            self.next().show();
          }
        });
      },
      
      sidebarParams: function() {
        Shopify.queryParams = {};

        //get after ?...=> Object {q: "Acme"} 

        if (location.search.length) {
          for (var aKeyValue, i = 0, aCouples = location.search.substr(1).split('&'); i < aCouples.length; i++) {
            aKeyValue = aCouples[i].split('=');

            if (aKeyValue.length > 1) {
              Shopify.queryParams[decodeURIComponent(aKeyValue[0])] = decodeURIComponent(aKeyValue[1]);
            }
          }
        };
      },
      
      showLoading: function() {
        $('.loading-modal').show();
      },

      hideLoading: function() {
        $('.loading-modal').hide();
      },

      showModal: function(selector) {
        $(selector).fadeIn(500);

        sneak.sneakTimeout = setTimeout(function() {
          $(selector).fadeOut(500);
        }, 5000);
      },

      closeModal: function() {
        $('.close-modal, .overlay').click(function(e) {
          e.preventDefault();
          e.stopPropagation();

          clearTimeout(sneak.sneakTimeout);

          $('.ajax-success-modal').fadeOut(500);
        });
      },
      
      initResizeImage: function(image) {
        if (window.product_image_resize) {
          image.fakecrop({
            fill: window.images_size.is_crop,
            widthSelector: ".products-grid .grid-item .product-image",
            ratioWrapper: window.images_size
          });
        };
      },
      
      checkNeedToConvertCurrency: function() {
        return window.show_multiple_currencies && Currency.currentCurrency != shopCurrency;
      },
      
      sidebarMapEvents: function() {
        sneak.sidebarMapCategories();
        sneak.sidebarMapTagEvents();
      },
      
      toolbarMapEvents:function() {
        sneak.sidebarParams();
      	sneak.sidebarMapView();
        sneak.sidebarMapSorting();
      },
      
      initSidebar: function() {
        if ($('.collection-sidebar').length) {
          sneak.sidebarParams();
          sneak.sidebarMapEvents();          
          sneak.sidebarMapClear();
          sneak.sidebarMapClearAll();
        };
      },
      
      initToolbar: function() {
        sneak.initDropdownFilterSortby();
      	sneak.toolbarMapEvents();
      },
      
      sidebarMapPaging: function() {
        var paginationSlt = '.pagination-page a';
        
        body.off('click.initMapPaging', paginationSlt).on('click.initMapPaging', paginationSlt, function(e) {
          e.preventDefault();
          e.stopPropagation();

          var page = $(this).attr('href').match(/page=\d+/g);

          if (page) {
            Shopify.queryParams.page = parseInt(page[0].match(/\d+/g));

            if (Shopify.queryParams.page) {
              var newurl = sneak.sidebarCreateUrl();

              sneak.isSidebarAjaxClick = true;

              History.pushState({
                param: Shopify.queryParams
              }, newurl, newurl);

              sneak.sidebarGetContent(newurl);

              var top = $('.block-row > div > .toolbar, .search-page').offset().top;

              $('body,html').animate({
                scrollTop: top
              }, 600);
            };
          };

        });
      },
      
      initInfiniteScrolling: function() {
        var infiniteScrolling = $('.infinite-scrolling');
        var infiniteScrollingLinkSlt = '.infinite-scrolling a';

        if(infiniteScrolling.length) {
          body.off('click.initInfiniteScrolling', infiniteScrollingLinkSlt).on('click.initInfiniteScrolling', infiniteScrollingLinkSlt, function(e) {
            e.preventDefault();
            e.stopPropagation();

            if (!$(this).hasClass('disabled')) {
              sneak.doInfiniteScrolling();
            };
          });
          
          if(window.infinity_scroll_feature) {
            window.infinitPos = 0;
            
            $(window).scroll(function() {
              var pos = infiniteScrolling.offset().top;
              
              if ($(this).scrollTop() > (pos - 600) && $(this).scrollTop() - window.infinitPos > 1000) {
                window.infinitPos = $(this).scrollTop();
                
                $(infiniteScrollingLinkSlt).trigger("click");
              }
            });
          }
        };
      },
      
      doInfiniteScrolling: function() {
        var currentList = $('.block-row .products-grid');

        if (!currentList.length) {
          currentList = $('.block-row .product-list');
        };

        if (currentList) {
          var showMoreButton = $('.infinite-scrolling a');

          $.ajax({
            type: 'GET',
            url: showMoreButton.attr('href'),

            beforeSend: function() {
              sneak.showLoading();
            },

            success: function(data) {
              sneak.hideLoading();

              var products = $(data).find('.block-row .products-grid');

              if (!products.length) {
                products = $(data).find('.block-row .product-list');
              };

              if (products.length) {
                if (products.hasClass('products-grid')) {
                  sneak.initResizeImage(products.children().find('img'));
                };

                currentList.append(products.children());
                sneak.translateBlock('.main-content');

                //get link of Show more
                if ($(data).find('.infinite-scrolling').length > 0) {
                  showMoreButton.attr('href', $(data).find('.infinite-scrolling a').attr('href'));
                }
                else {
                  //no more products
                  var noMoreText = window.inventory_text.no_more_product;

                  if (translator.isLang2()) 
                    noMoreText = window.lang2.collections.general.no_more_product;

                  showMoreButton.html(noMoreText).addClass('disabled');
                };

                //currency
                if (sneak.checkNeedToConvertCurrency()) {
                  Currency.convertAll(window.shop_currency, jQuery('#currencies').val(), 'span.money', 'money_format');
                };

                //product review
                if ($(".shopify-product-reviews-badge").length > 0) {
                  return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
                };
              }
            },

            error: function(xhr, text) {
              sneak.hideLoading();
              $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);
              sneak.showModal('.ajax-error-modal');
            },
            dataType: "html"
          });
        }
      },

      sidebarMapCategories: function() {
        var sidebarLinkSlt = '.sidebar-links a';
        var sidebarLink = $(sidebarLinkSlt);      

        body.off('click.activeCategory', sidebarLinkSlt).on('click.activeCategory', sidebarLinkSlt, function(e) {
          if($(this).attr('href') !== '/') {
            e.preventDefault();
            e.stopPropagation();

            var self = $(this);
            var parent = self.parent();

            if(!$(this).hasClass('active')) {
              delete Shopify.queryParams.q;
              delete Shopify.queryParams.constraint;
              sneak.sidebarAjaxClick($(this).attr('href'));
            };

            sidebarLink.not(self).removeClass('active');
            $(this).addClass('active'); 

            if (parent.hasClass('dropdown') && !parent.hasClass('open')) {
              $('.dropdown.open').removeClass('open');
              sidebarLink.siblings('.dropdown-cat').hide();
              self.siblings('.dropdown-cat').show();
              parent.addClass('open');                  	  
            };
          };
        });
      },

      sidebarMapTagEvents: function() {
        var sidebarTag = $('.sidebar-tag a:not(".clear"), .sidebar-tag label, .refined .selected-tag');
    
        sidebarTag.off('click.checkedTag').on('click.checkedTag', function(e) {
          e.preventDefault();
          e.stopPropagation();

          var currentTags = [];

          if (Shopify.queryParams.constraint) {
            currentTags = Shopify.queryParams.constraint.split('+'); //Array
          };

          //one selection or multi selection
          if (!window.enable_sidebar_multiple_choice && !$(this).prev().is(':checked')) {
            //remove other selection first
            var otherTag = $(this).closest('.sidebar-tag, .refined-widgets').find('input:checked');

            if (otherTag.length) {
              var tagName = otherTag.val();
              if (tagName) {
                var tagPos = currentTags.indexOf(tagName);
                if (tagPos >= 0) {
                  //remove tag
                  currentTags.splice(tagPos, 1);
                }
              }
            };
          };

          var tagName = $(this).prev().val();

          if (tagName) {
            var tagPos = currentTags.indexOf(tagName);

            if (tagPos >= 0) {
              //tag already existed, remove tag
              currentTags.splice(tagPos, 1);
            }
            else {
              //tag not existed
              currentTags.push(tagName);
            }
          };

          if (currentTags.length) {
            Shopify.queryParams.constraint = currentTags.join('+');
          }
          else {
            delete Shopify.queryParams.constraint;
          };

          sneak.sidebarAjaxClick();
        });
      },
      
      sidebarMapClear: function() {
        var sidebarTag = $('.sidebar-tag');

        sidebarTag.each(function() {
          var sidebarTag = $(this);

          if (sidebarTag.find('input:checked').length) {
            //has active tag
            sidebarTag.find('.clear').show().click(function(e) {
              e.preventDefault();
              e.stopPropagation();

              var currentTags = [];

              if (Shopify.queryParams.constraint) {
                currentTags = Shopify.queryParams.constraint.split('+');
              };

              sidebarTag.find("input:checked").each(function() {
                var selectedTag = $(this);
                var tagName = selectedTag.val();

                if (tagName) {
                  var tagPos = currentTags.indexOf(tagName);
                  if (tagPos >= 0) {
                    //remove tag
                    currentTags.splice(tagPos, 1);
                  };
                };
              });

              if (currentTags.length) {
                Shopify.queryParams.constraint = currentTags.join('+');
              }
              else {
                delete Shopify.queryParams.constraint;
              };

              sneak.sidebarAjaxClick();

            });
          }
        });
      },
      
      sidebarMapClearAll: function() {
        var clearAllSlt = '.refined-widgets a.clear-all';
        var clearAllElm = $(clearAllSlt);

        body.off('click.clearAllTags', clearAllSlt).on('click.clearAllTags', clearAllSlt, function(e) {
          e.preventDefault();
          e.stopPropagation();

          delete Shopify.queryParams.constraint;
          delete Shopify.queryParams.q;

          sneak.sidebarAjaxClick();
        });
      },
      
      sidebarMapView: function() {
        var viewAsSlt = '.toolbar .view-mode .view-as';
        var viewAs = $(viewAsSlt);

        body.off('click.mapView', viewAsSlt).on('click.mapView', viewAsSlt, function(e) {
          e.preventDefault();
          e.stopPropagation();

          if (!$(this).hasClass('active')) {

            if ($(this).hasClass('list')) {
              Shopify.queryParams.view = 'list';
            }
            else {
              Shopify.queryParams.view = '';
            }

            sneak.sidebarAjaxClick();

            $('.view-mode .view-as.active').removeClass('active');
            $(this).addClass('active');
          }
        });
      },
      
      initDropdownFilterSortby:function() {
        var labelSlt = '.toolbar .filter-sortby .label-tab';
        var dropdownMenuSlt = '.toolbar .filter-sortby .dropdown-menu';
        
        body.off('click.dropdownFilterSortby', labelSlt).on('click.dropdownFilterSortby', labelSlt, function(e) {
          e.preventDefault();
          e.stopPropagation();
          
          $(this).toggleClass('active').next('.dropdown-menu').toggle();
        });
        
        doc.off('click.hideFilterSortby').on('click.hideFilterSortby', function(e) {
          if (!$(e.target).closest(dropdownMenuSlt).length && $(labelSlt).hasClass('active')) {
            $(labelSlt).removeClass('active').next('.dropdown-menu').hide();
          }
        });
      },
      
      sidebarMapSorting: function() {
        var sortbyFilterSlt = '.filter-sortby li span';
        var sortbyFilter = $(sortbyFilterSlt);

        body.off('click.sortBy', sortbyFilterSlt).on('click.sortBy', sortbyFilterSlt, function(e) {
          e.preventDefault();
          e.stopPropagation();

          var self = $(this);
          var parent = self.parent();
          var sortbyText = self.text();
          var label = $('.filter-sortby .label-tab .label-text');

          if(!parent.hasClass('active')) {
            Shopify.queryParams.sort_by = $(this).attr('data-href');
            sneak.sidebarAjaxClick();
            label.text(sortbyText);
          }

          sortbyFilter.not(self).parent().removeClass('active');
          self.parent().addClass('active');
          
          $('.filter-sortby .label-tab').removeClass('active').next('.dropdown-menu').hide();
        });
        
        if (Shopify.queryParams.sort_by) {
          var sortby = Shopify.queryParams.sort_by;
          var sortbyText = $(".filter-sortby span[data-href='" + sortby + "']").text();

          $('.filter-sortby .label-tab .label-text').text(sortbyText);
          $('.filter-sortby li.active').removeClass('active');
          $(".filter-sortby span[data-href='" + sortby + "']").parent().addClass("active");
        }

        else {
          var sortbyText = $('.filter-sortby .dropdown-menu .active').text();

          $('.filter-sortby .label-tab .label-text').text(sortbyText);
        }
      },
      
      sidebarAjaxClick: function(baseLink) {
        delete Shopify.queryParams.page;

        var newurl = sneak.sidebarCreateUrl(baseLink);

        sneak.isSidebarAjaxClick = true;

        History.pushState({
          param: Shopify.queryParams
        }, newurl, newurl);

        sneak.sidebarGetContent(newurl);
      },
      
      sidebarCreateUrl: function(baseLink) {
        var newQuery = $.param(Shopify.queryParams).replace(/%2B/g, '+');

        if (baseLink) {
          if (newQuery != "")
            return baseLink + "?" + newQuery;
          else
            return baseLink;
        }
        return location.pathname + "?" + newQuery;
      },
      
      sidebarInitToggle: function() {
        var sidebarLabelSlt = '.col-sidebar .sidebar-label';
        var sidebarLabel = $(sidebarLabelSlt);

        if(sidebarLabel.is(':visible')) {
          body.off('click.showSidebar', sidebarLabelSlt).on('click.showSidebar', sidebarLabelSlt, function(e) {
            $('.sidebar').toggleClass('open').slideToggle();

            var top = $(this).offset().top - 63;

            $('body,html').animate({
              scrollTop: top
            }, 600)
          });
        };
        
        var widgetTitleSlt = '.sidebar .widget-title';
        var widgetTitle = $(widgetTitleSlt);
        
        if(window.innerWidth < 992) {
          widgetTitle.addClass('open'); 
          widgetTitle.next().hide();
        }
        else {
          widgetTitle.removeClass('open'); 
          widgetTitle.next().show();
        }
        
        body.off('click.slideToogle', widgetTitleSlt).on('click.slideToogle', widgetTitleSlt, function(e) {
          clearTimeout(sneak.sneakTimeout);

          sneak.sneakTimeout = setTimeout(function() {
			$('.widget-product .products-grid').slick('unslick');    
            $('.widget-product .products-grid').find('.slick-list').removeAttr('style');
            
            sneak.initProductSidebarSlider();
          }, 50);
          
          $(this).toggleClass('open');
          $(this).next().slideToggle();
        });
      },
      
      sidebarGetContent: function(newurl) {
        $.ajax({
          type: 'get',
          url: newurl,

          beforeSend: function() {
            sneak.showLoading();
          },

          success: function(data) {
            sneak.sidebarMapData(data);
            sneak.translateBlock('.main-content');
            sneak.initColorSwatchGrid();
            sneak.sidebarMapTagEvents();
            sneak.sidebarMapClear();
            sneak.hideLoading();
            
            if(window.innerWidth < 992 && $('.col-sidebar .sidebar-label').is(':visible')) {
              $('.sidebar').removeClass('open').slideUp(600);
            }
            else {
              $('.sidebar').css({'display': ''});
            };
          },

          error: function(xhr, text) {
            sneak.hideLoading();
            $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);
            sneak.showModal('.ajax-error-modal');
          }
        });
      },
      
      sidebarMapData: function(data) {
        var currentList = $('.col-main .products-grid');
    
        if (currentList.length == 0) {
          currentList = $('.col-main .product-list');
        };

        var productList = $(data).find('.col-main .products-grid');

        if (productList.length == 0) {
          productList = $(data).find('.col-main .product-list');
        };

        if (productList.length > 0 && productList.hasClass('products-grid')) {
          sneak.initResizeImage(productList.find('img'));
        };
        
        currentList.replaceWith(productList);

        //convert currency
        if (sneak.checkNeedToConvertCurrency()) {
          Currency.convertAll(window.shop_currency, jQuery('#currencies').val(), '.col-main span.money', 'money_format');
        };

        //replace paging
        if ($('.padding').length > 0) {
          $('.padding').replaceWith($(data).find(".padding"));
        }

        else {
          $(".block-row.col-main").append($(data).find('.padding'));
        };

        //replace title & description
        var currentHeader = $('.page-header');
        var dataHeader = $(data).find('.page-header');

        if (currentHeader.find('h2').text() != dataHeader.find('h2').text()) {
          currentHeader.find('h2').replaceWith(dataHeader.find('h2'));

          var currentDes = $('.collection-des');
          var dataDes = $(data).find('.collection-des');

          if (currentDes.find('.rte').length) {
            if (dataDes.find('.rte').length) {
              currentDes.html(dataDes.find('.rte'));
            } else {
              currentDes.find('.rte').hide();
            }
          }
          else {
            currentDes.html(dataDes.find('.rte'));
          };

          var currentImg = $(".collection-img");
          var dataImg = $(data).find(".collection-img");

          if (currentImg.find("p").length) {
            if (dataImg.find("p").length) {
              currentImg.html(dataImg.find("p"));
            } else {
              currentImg.find("p").hide();
            }
          }
          else {
            currentImg.html(dataImg.find("p"));
          }
        };

        //replace refined
        $('.refined-widgets').replaceWith($(data).find('.refined-widgets'));

        //replace tags
        $('.sidebar-block').replaceWith($(data).find('.sidebar-block'));

        // breadcrumb
        $('.breadcrumb .bd-title').replaceWith($(data).find('.breadcrumb .bd-title'));

        sneak.initProductSidebarSlider();

        //product review
        if ($('.shopify-product-reviews-badge').length > 0) {
          return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
        };
      },
      
      translateBlock: function(blockSelector) {
        if (window.multi_lang && translator.isLang2()) {
          translator.doTranslate(blockSelector);
        }
      },
      
      translateText: function(str) {
        if (!window.multi_lang || str.indexOf("|") < 0)
          return str;

        if (window.multi_lang) {
          var textArr = str.split("|");

          if (translator.isLang2())
            return textArr[1];
          return textArr[0];
        };
      },
      
      initProductMoreview: function() {
        if ($('.product .product-img-box').hasClass('horizontal')) {
          if($('.template-product .sidebar').length) {
            sneak.initHorizontallMoreviewHasSidebar($('.product .slider-for'), $('.product .slider-nav'));
          }
          else {
          	sneak.initHorizontallMoreviewNoSidebar($('.product .slider-for'), $('.product .slider-nav'));
          }
          
        }
        else if ($('.product .product-img-box').hasClass('vertical')) {
          sneak.initVerticalMoreview($('.product .slider-for'), $('.product .slider-nav'));
        };
      },
      
      initHorizontallMoreviewHasSidebar: function(sliderFor, sliderNav) {
        if (!sliderFor.hasClass('slick-initialized') && !sliderNav.hasClass('slick-initialized')) {
          sliderFor.slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            fade: true,
            verticalSwiping: false,
            asNavFor: sliderNav
          });

          sliderNav.slick({
            infinite: true,
            slidesToShow: 4,
            slidesToScroll: 1,
            asNavFor: sliderFor,
            verticalSwiping: false,
            dots: false,
            focusOnSelect: true,
            nextArrow: '<button type="button" class="slick-next"><i class="fa fa-angle-right"></i></button>',
            prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-angle-left"></i></button>',
            responsive: [
              {
                breakpoint: 1200,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1
                }
              },
              {

                breakpoint: 768,
                settings: {
                  slidesToShow:4,
                  slidesToScroll: 1
                }
              },

              {
                breakpoint: 480,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1,
                  dots: false
                }
              }
            ]
          });
        };
      },
      
      initHorizontallMoreviewNoSidebar: function(sliderFor, sliderNav) {
        if (!sliderFor.hasClass('slick-initialized') && !sliderNav.hasClass('slick-initialized')) {
          sliderFor.slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            fade: true,
            verticalSwiping: false,
            asNavFor: sliderNav
          });

          sliderNav.slick({
            infinite: true,
            slidesToShow: 5,
            slidesToScroll: 1,
            asNavFor: sliderFor,
            verticalSwiping: false,
            dots: false,
            focusOnSelect: true,
            nextArrow: '<button type="button" class="slick-next"><i class="fa fa-angle-right"></i></button>',
            prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-angle-left"></i></button>',
            responsive: [
              {
                breakpoint: 1200,
                settings: {
                  slidesToShow: 4,
                  slidesToScroll: 1
                }
              },
              {

                breakpoint: 768,
                settings: {
                  slidesToShow:4,
                  slidesToScroll: 1
                }
              },

              {
                breakpoint: 480,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1,
                  dots: false
                }
              }
            ]
          });
        };
      },

      initVerticalMoreview: function(sliderFor, sliderNav) {
        if (!sliderFor.hasClass('slick-initialized') && !sliderNav.hasClass('slick-initialized')) {
          sliderFor.slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            fade: true,
            verticalSwiping: false,
            asNavFor: sliderNav
          });

          sliderNav.slick({
            infinite: true,
            slidesToShow: 4,
            slidesToScroll: 1,
            vertical: true,
            asNavFor: sliderFor,
            verticalSwiping: false,
            dots: false,
            focusOnSelect: true,
            nextArrow: '<button type="button" class="slick-next"><i class="fa fa-angle-right"></i></button>',
            prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-angle-left"></i></button>',
            responsive: [
              {

                breakpoint: 992,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1
                }
              },
              {

                breakpoint: 768,
                settings: {
                  slidesToShow: 4,
                  slidesToScroll: 1
                }
              },

              {

                breakpoint: 480,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1
                }
              },

              {
                breakpoint: 370,
                settings: {
                  slidesToShow: 2,
                  slidesToScroll: 1,
                  dots: false
                }
              }
            ]
          });
        };
      },
      
      initRelatedProductSlider: function() {
        var templatePro = $('.template-product');
        var sidebar = templatePro.find('.sidebar');
        
        if($('.product').hasClass('tab-horizontal')) {
          if(sidebar.length) {
          	sneak.initRelatedProductSliderHasSidebarHorizontalTab();
          }
          else {
            sneak.initFiveItemSliderMb2($('.related-products .products-grid'));
          };
        }
        else {
          if(sidebar.length) {
          	sneak.initRelatedProductSliderHasSidebarVerticalTab();
          }
          else {
            sneak.initRelatedProductSliderNoSidebarVerticalTab();
          };
        }
      },
      
      initRelatedProductSliderHasSidebarHorizontalTab: function() {
        var relatedProduct = $('.related-products');
        var productGrid = relatedProduct.find('.products-grid');

        if(relatedProduct.length) {
          productGrid.slick({
            infinite: false,
            speed: 500,
            slidesToShow: 4,
            slidesToScroll: 1,
            dots: true,
            nextArrow: '<button type="button" class="slick-next"><i class="fa fa-angle-right"></i></button>',
            prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-angle-left"></i></button>',
            responsive: [
              {
                breakpoint: 1200,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 768,
                settings: {
                  slidesToShow: 2,
                  slidesToScroll: 1
                }
              },

              {
                breakpoint: 370,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
              }
            ]
          });
        };
      },
      
      initRelatedProductSliderNoSidebarVerticalTab: function() {
        var relatedProduct = $('.related-products');
        var productGrid = relatedProduct.find('.products-grid');

        if(relatedProduct.length) {
          productGrid.slick({
            infinite: false,
            speed: 500,
            slidesToShow: 3,
            slidesToScroll: 1,
            dots: true,
            nextArrow: '<button type="button" class="slick-next"><i class="fa fa-angle-right"></i></button>',
            prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-angle-left"></i></button>',
            responsive: [
              {
                breakpoint: 1200,
                settings: {
                  slidesToShow: 2,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 992,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 768,
                settings: {
                  slidesToShow: 2,
                  slidesToScroll: 1
                }
              },

              {
                breakpoint: 370,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
              }
            ]
          });
        };
      },
      
      initRelatedProductSliderHasSidebarVerticalTab: function() {
        var relatedProduct = $('.related-products');
        var productGrid = relatedProduct.find('.products-grid');

        if(relatedProduct.length) {
          productGrid.slick({
            infinite: false,
            speed: 500,
            slidesToShow: 2,
            slidesToScroll: 1,
            dots: true,
            nextArrow: '<button type="button" class="slick-next"><i class="fa fa-angle-right"></i></button>',
            prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-angle-left"></i></button>',
            responsive: [
              {
                breakpoint: 1200,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 992,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 768,
                settings: {
                  slidesToShow: 2,
                  slidesToScroll: 1
                }
              },

              {
                breakpoint: 370,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
              }
            ]
          });
        };
      },
      
      initFancyboxProductPage: function() {
        $('[data-fancybox="images"]').fancybox({
          loop : true,
          autoCenter: true,
          openSpeed: 700,
          closeSpeed: 700,
          nextSpeed: 500,
          prevSpeed: 500,
          thumbs: false
        });
      },
      
      initZoom: function() {
        var sliderFor = $('.product-photo-container.slider-for');  
                        
        if ($(window).width() >= 992 && $('.zoomContainer').length === 0 && !('ontouchstart' in document)) {
          if (sliderFor.find('.slick-current img[id|="product-featured-image"]').length) {
            var zoomOptions = {
              zoomType: "inner"
            };
            
            sliderFor.find('.slick-current img[id|="product-featured-image"]').elevateZoom(zoomOptions);
            
            sliderFor.on("beforeChange", function(event, slick, currentSlide, nextSlide) {
              $.removeData(currentSlide, 'elevateZoom');
              $('.zoomContainer').remove();
            });

            sliderFor.on("afterChange", function() {
              sliderFor.find('.slick-current img[id|="product-featured-image"]').elevateZoom(zoomOptions);
            });

            sneak.initFancyboxProductPage();
          }
        }
        else if ($(window).width() < 992 && $('.zoomContainer').length >= 1 && ('ontouchstart' in document)) {    
          var img = sliderFor.find('.slick-current img[id|="product-featured-image"]');
          
          img.off('touchmove');          
          $.removeData(img, 'elevateZoom');
          $('.zoomContainer').remove();
        }

        else if($(window).width() < 992 || ($(window).width() >= 992 && ('ontouchstart' in document))) {
          sneak.initFancyboxProductPage();
        };                 
      },
      
      initProductAddToCart: function() {
        var btnAddToCartSlt = '#product-add-to-cart';
        var btnAddToCart = $(btnAddToCartSlt);

        if(btnAddToCart.length) {
          body.off('click.addToCartProduct', btnAddToCartSlt).on('click.addToCartProduct', btnAddToCartSlt, function(e) {
            e.preventDefault();
            e.stopPropagation();

            if($(this).attr('disabled') != 'disabled') {
              if(!window.ajax_cart) {
                $(this).closest('form').submit();
              }

              else {
                var variant_id = $('#add-to-cart-form select[name=id]').val();
                
                if(!variant_id) {
                  variant_id = $('#add-to-cart-form input[name=id]').val();
                }

                var quantity = $('#add-to-cart-form input[name=quantity]').val();
                
                if(!quantity) {
                  quantity = 1;
                }

                var title = $('.product-title h2').html();
                
                var vendor = $(this).closest('form').data('vendor');

                var image = $('.slick-current img[id|="product-featured-image"]').attr('src') || $('.product img[id|="product-featured-image"]').attr('src');

                sneak.doAjaxAddToCart(variant_id, quantity, title, vendor, image);
              }
            }

            return false;

          });
        }
      },
      
      doAjaxAddToCart: function(variant_id, quantity, title, vendor, image) {
        $.ajax({
          type: "post",
          url: "/cart/add.js",
          data: 'quantity=' + quantity + '&id=' + variant_id,
          dataType: 'json',

          beforeSend: function() {
            sneak.showLoading();
          },

          success: function(msg) {
            sneak.hideLoading();

            $('.ajax-success-modal').find('.ajax-product-title').html(sneak.translateText(title));
            $('.ajax-success-modal').find('.ajax-product-vendor').html(vendor);
            $('.ajax-success-modal').find('.ajax-product-image').attr('src', image);
            $('.ajax-success-modal').find('.message-added-cart').show();

            sneak.showModal('.ajax-success-modal');
            sneak.updateDropdownCart();
          },

          error: function(xhr, text) {
            sneak.hideLoading();

            $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);

            sneak.showModal('.ajax-error-modal');
          }
        });
      },
      
      updateDropdownCart: function() {
        Shopify.getCart(function(cart) {
          sneak.doUpdateDropdownCart(cart);
        });
      },
      
      doUpdateDropdownCart: function(cart) {
        var template = '<li class="item" id="cart-item-{ID}"><a href="{URL}" title="{TITLE}" class="product-image"><img src="{IMAGE}" alt="{TITLE}"></a><div class="product-details"><a href="javascript:void(0)" title="Remove This Item" class="btn-remove"><svg viewBox="0 0 24 24" class="icon-close" width="100%" height="100%"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path></svg></a><p class="product-name"><a href="{URL}">{TITLE}</a></p><div class="cart-collateral"><span class="qtt">{QUANTITY} X</span><span class="price">{PRICE}</span></div></div></li>';

        $('#cartCount').text(cart.item_count);

        dropdownCart.find('.summary .price').html(Shopify.formatMoney(cart.total_price, window.money_format));

        miniProductList.html('');

        if (cart.item_count > 0) {
          for (var i = 0; i < cart.items.length; i++) {
            var item = template;

            item = item.replace(/\{ID\}/g, cart.items[i].id);
            item = item.replace(/\{URL\}/g, cart.items[i].url);
            item = item.replace(/\{TITLE\}/g, sneak.translateText(cart.items[i].product_title));
            item = item.replace(/\{QUANTITY\}/g, cart.items[i].quantity);
            item = item.replace(/\{IMAGE\}/g, Shopify.resizeImage(cart.items[i].image, '64x'));
            item = item.replace(/\{PRICE\}/g, Shopify.formatMoney(cart.items[i].price, window.money_format));

            miniProductList.append(item);
          }

          sneak.removeItemDropdownCart(cart);

          if (sneak.checkNeedToConvertCurrency()) {
            Currency.convertAll(window.shop_currency, $('#currencies').val(), '#dropdown-cart span.money', 'money_format');
          }
        }

        sneak.checkItemsInDropdownCart();
      },
      
      removeItemDropdownCart: function(cart) {
        var btnRemove = dropdownCart.find('.btn-remove');

        btnRemove.off('click.removeCartItem').on('click.removeCartItem', function(e) {
          e.preventDefault();
          e.stopPropagation();

          var productId = $(this).parents('.item').attr('id');
          productId = productId.match(/\d+/g);

          Shopify.removeItem(productId, function(cart) {
            sneak.doUpdateDropdownCart(cart);
          });
        });
      },
      
      checkItemsInDropdownCart: function() {
        if(miniProductList.children().length) {
          cartHasItems.show();
          cartNoItems.hide();
        }
        else {
          cartHasItems.hide();
          cartNoItems.show();
        }
      },
      
      initAddToCart: function() {
        var btnAddToCartSlt = '.add-to-cart-btn';
        var btnAddToCart = $(btnAddToCartSlt);

        if(btnAddToCart.length) {
          body.off('click.addToCart', btnAddToCartSlt).on('click.addToCart', btnAddToCartSlt, function(e) {
            e.preventDefault();
            e.stopPropagation();

            if($(this).attr('disabled') != 'disabled') {
              var productItem = $(this).parents('.product-item');
              var productId = $(productItem).attr('id');
              var form = productItem.find('form[data-id|="product-actions"]');
              
              productId = productId.match(/\d+/g);

              if(!window.ajax_cart) {
                form.submit();
              }

              else {
                var variant_id = form.find('select[name=id]').val();
                if(!variant_id) {
                  variant_id = form.find('input[name=id]').val();
                }

                var quantity = form.find('input[name=quantity]').val();
                
                if(!quantity) {
                  quantity = 1;
                }

                var title = $(productItem).find('.product-title').html();
                
                var vendor = form.data('vendor');

                var image = $(productItem).find('.product-grid-image img').attr('src');

                sneak.doAjaxAddToCart(variant_id, quantity, title, vendor, image);
              }
            }

            return false;

          });
        }
      },
      
      initCartQty: function() {
        var button = $('.cart-list .quantity .button');

        button.off('click.changeQuantity').on('click.changeQuantity', function(e) {
          e.preventDefault();
          e.stopPropagation();

          var oldValue = $(this).siblings('input.qty').val(),
              newVal = 1;

          if($(this).hasClass('inc')) {
            newVal = parseInt(oldValue) + 1;
          }
          else if(oldValue > 1) {
            newVal = parseInt(oldValue) - 1;
          }

          $(this).siblings('input.qty').val(newVal);
        });
      },
      
      initQuickView: function() {
        body.off('click.initQuickView', '.quickview-button a').on('click.initQuickView', '.quickview-button a', function(e) {
          e.preventDefault();
          e.stopPropagation();

          var product_handle = $(this).attr('id');

          Shopify.getProduct(product_handle, function(product) {
            var template = $('#quickview-template').html();          
            $('.quick-view').html(template);          
            var quickview = $('.quick-view');
            
            //  ------ vendorLink
            if (quickview.find('.product-vendor').length) {
              quickview.find('.product-vendor span').text(product.vendor);
            };

            // -----  product-title
            var productTitleElm = quickview.find('.product-title a');
            
            productTitleElm.html(sneak.translateText(product.title));

            productTitleElm.attr('href', product.url);

            productTitleElm.attr('title', sneak.translateText(product.title));

            // -----------product invetory
            if (quickview.find('.product-inventory').length) {
              var variant = product.variants[0];
              var inventoryInfo = quickview.find('.product-inventory span');

              if (variant.available) {
                if (variant.inventory_management != null) {
                  inventoryInfo.text(window.inventory_text.in_stock);
                }
                else {
                  inventoryInfo.text(window.inventory_text.many_in_stock);
                }
              }

              else {
                inventoryInfo.text(window.inventory_text.out_of_stock);
              }
            };
            
            // ----------  product SKU 
            if (quickview.find('.sku-product').length) {
              quickview.find('.sku-product span').text(variant.sku);
            };

            // ----------  product Vendor 
            if (quickview.find('.vendor-product').length) {
              quickview.find('.vendor-product span').text(product.vendor);
            };
            
            // -----------product type
            if (quickview.find('.product-type').length) {
              quickview.find('.product-type span').text(product.type);
            };

            //countdown for quickview
            if (product.description.indexOf("[countdown]")) {
              var countdownTime = product.description.match(/\[countdown\](.*)\[\/countdown\]/);

              if (countdownTime && countdownTime.length > 0) {
                quickview.find(".countdown").show();

                quickview.find(".quickview-clock").countdown(countdownTime[1], function(event) {
                  $(this).html(event.strftime('%Dd %H:%M:%S'));
                });
              }
            };

            // -----------product description
            if (quickview.find('.short-description').length) {
              var description = product.description.replace(/(<([^>]+)>)/ig, "");
              var description = description.replace(/\[countdown\](.*)\[\/countdown\]/g, "");

              if (window.multi_lang) {
                if (description.indexOf("[lang2]") > 0) {
                  var descList = description.split("[lang2]");

                  if (jQuery.cookie("language") != null) {
                    description = descList[translator.current_lang - 1];
                  }
                  else {
                    description = descList[0];
                  }
                }
              };

              description = description.split(" ").splice(0, 20).join(" ") + "...";
              quickview.find('.short-description').text(description);
            }

            else {
              quickview.find('.short-description').remove();
            };

            // -------product price
            var quickViewPriceElm = quickview.find('.price');
            var productPrice = product.price;

            if (window.money_format.indexOf('{{amount_no_decimals}}') >= 0) {
              productPrice *= 100;
            }

            quickViewPriceElm.html(Shopify.formatMoney(productPrice, window.money_format));

            // -----------if has compare price
            var quickViewComparePriceElm = quickview.find('.compare-price');
            var comparePrice = product.compare_at_price_max;
            var priceSaving = quickview.find('.price-saving');

            if (product.compare_at_price > product.price) {
              if (window.money_format.indexOf('{{amount_no_decimals}}') >= 0) {
                comparePrice *= 100;
              }

              quickViewComparePriceElm.html(Shopify.formatMoney(comparePrice, window.money_format)).show();

              quickViewPriceElm.addClass('on-sale');
              
              priceSaving.find('.price-save').html(Shopify.formatMoney(variant.compare_at_price - variant.price, window.money_format));
              priceSaving.show();
            }

            else {
              quickViewComparePriceElm.html('').hide();
              quickViewPriceElm.removeClass('on-sale');
              priceSaving.hide();
            }

            // -----------id product 
            quickview.find('.product-item').attr('id', 'product-' + product.id);
            quickview.find('.variants').attr('data-id', 'product-actions-' + product.id);
            quickview.find('.variants').attr('data-vendor', product.vendor);
            quickview.find('.variants select').attr('id', 'product-select-' + product.id);
            
            var label = $('#product-'+ product.id +' .product-label').html();
            quickview.find('.product-label').html(label);

            //out of stock
            if (!product.available) {
              quickview.find("select, input, .total-price, .des, .inc, .variants label").remove();
              quickview.find(".add-to-cart-btn").text(window.inventory_text.unavailable).addClass('disabled').attr("disabled", "disabled");;
            }

            else {
              var quickViewTotalPriceElm = quickview.find('.total-price .total-money');
              var productPrice = product.price;

              if(window.money_format.indexOf('{{amount_no_decimals}}') >= 0) {
                productPrice *= 100;
              }

              quickViewTotalPriceElm.html(Shopify.formatMoney(productPrice, window.money_format));

              // ------------swatch
              if (window.use_color_swatch) {
                sneak.createQuickViewVariantsSwatch(product, quickview);
              }
              else {
                sneak.createQuickViewVariants(product, quickview);
              }
            };

            //quantity
            quickview.find('.button').off('click.changeQtt').on('click.changeQtt', function(e) {
              e.preventDefault();
              e.stopPropagation();

              var oldValue = quickview.find(".quantity").val(),
                  newVal = 1;

              if($(this).hasClass('inc')) {
                newVal = parseInt(oldValue) + 1;
              }
              else if(oldValue > 1) {
                newVal = parseInt(oldValue) - 1;
              }

              quickview.find('.quantity').val(newVal);

              if (quickview.find('.total-price').length) {
                sneak.updatePricingQuickview();
              }
            });

            if (window.show_multiple_currencies) {
              Currency.convertAll(window.shop_currency, $('#currencies').val(), 'span.money', 'money_format');
            }

            sneak.loadQuickViewSlider(product, quickview);
            sneak.initQuickviewAddToCart();
            sneak.translateBlock('.quick-view');                    

            $('.quick-view').fadeIn(500);

            if ($('.quick-view .total-price').length > 0) {
              $('.quick-view input[name=quantity]').on('change', sneak.updatePricingQuickview);
            }
          });

          return false;

        });

        doc.off('click.closeQuickView').on('click.closeQuickView', '.quick-view .overlay, .close-window', function() {
          sneak.closeQuickViewPopup();
          return false;
        });
      },
      
      convertToSlug: function(text) {
        return text
        .toLowerCase()
        .replace(/[^a-z0-9 -]/g, '') // remove invalid chars
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-');
      },

      createQuickViewVariantsSwatch: function(product, quickviewTemplate) {
        //multiple variants	
        if (product.variants.length > 1) {
          for (var i = 0; i < product.variants.length; i++) {
            var variant = product.variants[i];
            var option = '<option value="' + variant.id + '">' + variant.title + '</option>';
            
            quickviewTemplate.find('form.variants > select').append(option);
          };

          new Shopify.OptionSelectors("product-select-" + product.id, {
            product: product,
            onVariantSelected: selectCallbackQuickview
          });

          //start of quickview variant;
          var filePath = window.file_url.substring(0, window.file_url.lastIndexOf('?'));
          var assetUrl = window.asset_url.substring(0, window.asset_url.lastIndexOf('?'));
          var options = "";

          for (var i = 0; i < product.options.length; i++) {
            options += '<div class="swatch clearfix" data-option-index="' + i + '">';
            options += '<div class="header">' + product.options[i].name + '</div>';

            var is_color = false;

            if (/Color|Colour/i.test(product.options[i].name)) {
              is_color = true;
            };

            var optionValues = new Array();

            for (var j = 0; j < product.variants.length; j++) {
              var variant = product.variants[j];
              var value = variant.options[i];
              var valueHandle = sneak.convertToSlug(value) || value;
              var forText = 'quick-view-swatch-' + i + '-' + valueHandle;

              if (optionValues.indexOf(value) < 0) {
                //not yet inserted
                options += '<div data-value="' + value + '" class="swatch-element ' + (is_color ? "color" : "") + valueHandle + (variant.available ? ' available ' : ' soldout ') + '">';

                if (is_color) {
                  options += '<div class="tooltip">' + value + '</div>';
                }
                options += '<input id="' + forText + '" type="radio" name="option-' + i + '" value="' + value + '" ' + (j == 0 ? ' checked ' : '') + (variant.available ? '' : ' disabled') + ' />';

                if (is_color) {
                  options += '<label for="' + forText + '" style="background-color: ' + valueHandle + '; background-image: url(' + filePath + valueHandle + '.png)"><span class="crossed-out"></span></label>';
                }
                else {
                  options += '<label for="' + forText + '">' + value + '<span class="crossed-out"></span></label>';
                }
                options += '</div>';
                if (variant.available) {
                  $('.quick-view .swatch[data-option-index="' + i + '"] .' + valueHandle).removeClass('soldout').addClass('available').find(':radio').removeAttr('disabled');
                }
                optionValues.push(value);
              };
            };
            options += '</div>';
          };

          quickviewTemplate.find('form.variants > select').after(options);

          changeSwatch(quickviewTemplate.find('.swatch :radio'));

          if (product.available) {
            Shopify.quickViewOptionsMap = {};
            Shopify.linkOptionSelectors(product, '.quick-view');
          };
        }

        //single variant
        else {
          quickviewTemplate.find('form.variants > select').remove();
          var variant_field = '<input type="hidden" name="id" value="' + product.variants[0].id + '">';
          quickviewTemplate.find('form.variants').append(variant_field);
        };
      },

      createQuickViewVariants: function(product, quickviewTemplate) {
        //multiple variants
        if (product.variants.length > 1) { 
          for (var i = 0; i < product.variants.length; i++) {
            var variant = product.variants[i];
            var option = '<option value="' + variant.id + '">' + variant.title + '</option>';

            quickviewTemplate.find('form.variants > select').append(option);
          }

          new Shopify.OptionSelectors("product-select-" + product.id, {
            product: product,
            onVariantSelected: selectCallbackQuickview
          });

          if (product.options.length == 1) {
            $('.selector-wrapper:eq(0)').prepend('<label>' + product.options[0].name + '</label>');

            for (var text = product.variants, r = 0; r < text.length; r++ ) {
              var s = text[r];

              if (!s.available) {
                $('.single-option-selector option').filter(function() {
                  return $(this).html() === s.title 
                }).remove();
              }
            };
          }
          else if(product.options.length > 1) {
          	$('.selector-wrapper').append('<span class="icon-dropdown"><i class="fa fa-angle-down"></i></span>'); 
          };

          $('.quick-view .selectize-input input').attr("disabled", "disabled");

          quickviewTemplate.find('form.variants .selector-wrapper label').each(function(i,v) {
            $(this).html(product.options[i].name);
          });
        }

        //single variant
        else { 
          quickviewTemplate.find('form.variants > select').remove();

          var variant_field = '<input type="hidden" name="id" value="' + product.variants[0].id + '">';

          quickviewTemplate.find('form.variants').append(variant_field);
        };
      },

      updatePricingQuickview: function() {
        var regex = /([0-9]+[.|,][0-9]+[.|,][0-9]+)/g;
        var unitPriceTextMatch = $('.quick-view .price').text().match(regex);

        if (!unitPriceTextMatch) {
          regex = /([0-9]+[.|,][0-9]+)/g;
          unitPriceTextMatch = $('.quick-view .price').text().match(regex);
        }

        if (unitPriceTextMatch) {
          var unitPriceText = unitPriceTextMatch[0];
          var unitPrice = unitPriceText.replace(/[.|,]/g, '');
          var quantity = parseInt($('.quick-view input[name=quantity]').val());
          var totalPrice = unitPrice * quantity;

          var totalPriceText = Shopify.formatMoney(totalPrice, window.money_format);
          regex = /([0-9]+[.|,][0-9]+[.|,][0-9]+)/g;     
          if (!totalPriceText.match(regex)) {
            regex = /([0-9]+[.|,][0-9]+)/g;
          } 
          totalPriceText = totalPriceText.match(regex)[0];

          var regInput = new RegExp(unitPriceText, "g");
          var totalPriceHtml = $('.quick-view .price').html().replace(regInput, totalPriceText);

          $('.quick-view .total-price span').html(totalPriceHtml);
        };       
      },

      loadQuickViewSlider: function(product, quickviewTemplate) {
        var quickViewSliderFor = quickviewTemplate.find('.quickview-featured-image');
        var count = 0;

        for (i in product.images) {
          if (count < product.images.length) {
            var featuredImage = Shopify.resizeImage(product.images[i], '1024x1024');
            var thumb = '<div class="thumb"><a href="' + product.url + '" title="' + product.title + '"><img src="' + featuredImage + '"  /></a></div>'

            quickViewSliderFor.append(thumb);
            count = count + 1;
          }
        };

        var quickViewsliderNav = quickviewTemplate.find('.slider-nav');
        var count_2 = 0;

        for (i in product.images) {
          if (count_2 < product.images.length) {
            var original = Shopify.resizeImage(product.images[i], '1024x1024');
            var compact = Shopify.resizeImage(product.images[i], '70x70');
            var item = '<div class="item"><a href="javascript:void(0)" data-image="' + original + '"><img src="' + compact + '"  /></a></div>'

            quickViewsliderNav.append(item);
            count_2 = count_2 + 1;
          }
        };

        clearTimeout(sneak.sneakTimeout);

        var counter = 0;
        var imgTags = quickviewTemplate.find('.quickview-featured-image img, .slider-nav img');

        imgTags.on('load', function() {
          counter++;

          if (counter === imgTags.length) {

            sneak.sneakTimeout = setTimeout(function() {
              sneak.initHorizontallMoreviewHasSidebar(quickViewSliderFor, quickViewsliderNav);
            }, 300);

          }
        });
      },

      initQuickviewAddToCart: function() {
        if ($('.quick-view .add-to-cart-btn').length) {
          $('.quick-view .add-to-cart-btn').off('click.quickViewAddToCart').on('click.quickViewAddToCart', function(e) {
            e.preventDefault();
            e.stopPropagation();

            var variant_id = $('.quick-view select[name=id]').val();

            if (!variant_id) {
              variant_id = $('.quick-view input[name=id]').val();
            };

            var quantity = $('.quick-view input[name=quantity]').val();
            if (!quantity) {
              quantity = 1;
            };

            var title = $('.quick-view .product-title a').html();
            var image = $('.quick-view .quickview-featured-image .slick-current img').attr('src') || $('.quick-view .quickview-featured-image img').attr('src');
            var vendor = $('.quick-view form.variants').data('vendor');

            sneak.doAjaxAddToCart(variant_id, quantity, title, vendor, image);
            sneak.closeQuickViewPopup();
          });
        };
      },
      
      closeQuickViewPopup: function() {
        $('.quick-view').fadeOut(500);
      },
      
      initMegaSliderStyle3: function() {
      	var cateSlider = $('.mega-featured-categories .cate-slider');
        
        cateSlider.each(function() {
          var self = $(this);
          
          if(self.length && !self.hasClass('slick-initialized')) {
            self.slick({
              infinite: true,
              slidesToShow: 2,
              slidesToScroll: 1,
              verticalSwiping: false,
              dots: false,
              speed: 500,
              nextArrow: '<button type="button" class="slick-next"><i class="fa fa-angle-right"></i></button>',
              prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-angle-left"></i></button>',
              responsive: [
                {
                  breakpoint: 1600,
                  settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                  }
                }                    
              ]
            });
          }
        });
      },
      
      initPoliCySlider: function() {
        var policySlider = $('.policys-block .policy-slider');
        
        policySlider.each(function() {
          var self = $(this);
          
          if(self.length && !self.hasClass('slick-initialized')) {
            self.slick({
              infinite: true,
              slidesToShow: 4,
              slidesToScroll: 1,
              verticalSwiping: false,
              autoplay: true,
              autoplaySpeed: 2000,
              dots: false,
              speed: 500,
              arrows: false,
              responsive: [
                {
                  breakpoint: 1200,
                  settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1
                  }
                },
                {
                  breakpoint: 992,
                  settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                  }
                },
                {
                  breakpoint: 540,
                  settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                  }
                }
              ]
            });
          }
        });
      },
      
      initDropdownFooterMenu: function() {
      	var footerTitle = $('.footer-middel .foot-title');
        
        if(window.innerWidth < 768) {
          if(footerTitle.length) {
            footerTitle.off('click.slideToggle').on('click.slideToggle', function() {
              $(this).next().slideToggle();
            });
          }
        }
        else {
          $('.footer-middel .foot-title ~ ul').css({"display": ""});
        }
      },
      
    };
})(jQuery);