(function($) {
  var body = $('body');
  var doc = $(document);  

  var iconNav = $('#showLeftPush');
  var iconCart = $('#cartToggle');

  var dropdownCart = $('#dropdown-cart');
  var navCustomer = $('.nav-customer');
  var wrapperCart = $('.wrapper-top-cart');
  var cartNoItems = dropdownCart.find('.no-items');
  var cartHasItems = dropdownCart.find('.has-items');
  var miniProductList = dropdownCart.find('.mini-products-list');

  if ($('.collection-sidebar').length) {
    History.Adapter.bind(window, 'statechange', function() {
      var State = History.getState();

      if (!bicycle.isSidebarAjaxClick) {
        bicycle.sidebarParams();

        var newurl = bicycle.sidebarCreateUrl();

        bicycle.sidebarGetContent(newurl);
      }

      bicycle.isSidebarAjaxClick = false;
    });
  };

  var changeSwatch = function(swatch) {
    swatch.change(function() {
      var optionIndex = $(this).closest('.swatch').attr('data-option-index');
      var optionValue = $(this).val();

      $(this)
      .closest('form')
      .find('.single-option-selector')
      .eq(optionIndex)
      .val(optionValue)
      .trigger('change');
    });
  };

  if (window.use_color_swatch) {

    changeSwatch($('.swatch :radio'));

    Shopify.productOptionsMap = {};
    Shopify.quickViewOptionsMap = {};

    Shopify.updateOptionsInSelector = function(selectorIndex, wrapperSlt) {

      Shopify.optionsMap = wrapperSlt === '.product' ? Shopify.productOptionsMap : Shopify.quickViewOptionsMap;

      switch (selectorIndex) {
        case 0:
          var key = 'root';
          var selector = $(wrapperSlt + '.single-option-selector:eq(0)');
          break;
        case 1:
          var key = $(wrapperSlt + ' .single-option-selector:eq(0)').val();
          var selector = $(wrapperSlt + ' .single-option-selector:eq(1)');
          break;
        case 2:
          var key = $(wrapperSlt + ' .single-option-selector:eq(0)').val();
          key += ' / ' + $(wrapperSlt + ' .single-option-selector:eq(1)').val();
          var selector = $(wrapperSlt + ' .single-option-selector:eq(2)');
      }

      var initialValue = selector.val();

      selector.empty();

      var availableOptions = Shopify.optionsMap[key];

      if (availableOptions && availableOptions.length) {
        for (var i = 0; i < availableOptions.length; i++) {
          var option = availableOptions[i];

          var newOption = $('<option></option>').val(option).html(option);

          selector.append(newOption);
        }

        $(wrapperSlt + ' .swatch[data-option-index="' + selectorIndex + '"] .swatch-element').each(function() {
          if ($.inArray($(this).attr('data-value'), availableOptions) !== -1) {
            $(this).removeClass('soldout').find(':radio').removeAttr('disabled', 'disabled').removeAttr('checked');
          }
          else {
            $(this).addClass('soldout').find(':radio').removeAttr('checked').attr('disabled', 'disabled');
          }
        });

        if ($.inArray(initialValue, availableOptions) !== -1) {
          selector.val(initialValue);
        }

        selector.trigger('change');
      };
    };

    Shopify.linkOptionSelectors = function(product, wrapperSlt) {
      // Building our mapping object.
      Shopify.optionsMap = wrapperSlt === '.product' ? Shopify.productOptionsMap : Shopify.quickViewOptionsMap;

      for (var i = 0; i < product.variants.length; i++) {
        var variant = product.variants[i];

        if (variant.available) {
          // Gathering values for the 1st drop-down.
          Shopify.optionsMap['root'] = Shopify.optionsMap['root'] || [];

          Shopify.optionsMap['root'].push(variant.option1);
          Shopify.optionsMap['root'] = Shopify.uniq(Shopify.optionsMap['root']);

          // Gathering values for the 2nd drop-down.
          if (product.options.length > 1) {
            var key = variant.option1;
            Shopify.optionsMap[key] = Shopify.optionsMap[key] || [];
            Shopify.optionsMap[key].push(variant.option2);
            Shopify.optionsMap[key] = Shopify.uniq(Shopify.optionsMap[key]);
          }

          // Gathering values for the 3rd drop-down.
          if (product.options.length === 3) {
            var key = variant.option1 + ' / ' + variant.option2;
            Shopify.optionsMap[key] = Shopify.optionsMap[key] || [];
            Shopify.optionsMap[key].push(variant.option3);
            Shopify.optionsMap[key] = Shopify.uniq(Shopify.optionsMap[key]);
          }
        }
      };

      // Update options right away.
      Shopify.updateOptionsInSelector(0, wrapperSlt);

      if (product.options.length > 1) Shopify.updateOptionsInSelector(1, wrapperSlt);
      if (product.options.length === 3) Shopify.updateOptionsInSelector(2, wrapperSlt);

      // When there is an update in the first dropdown.
      $(wrapperSlt + " .single-option-selector:eq(0)").change(function() {
        Shopify.updateOptionsInSelector(1, wrapperSlt);
        if (product.options.length === 3) Shopify.updateOptionsInSelector(2, wrapperSlt);
        return true;
      });

      // When there is an update in the second dropdown.
      $(wrapperSlt + " .single-option-selector:eq(1)").change(function() {
        if (product.options.length === 3) Shopify.updateOptionsInSelector(2, wrapperSlt);
        return true;
      });

    };
  };

  $(document).ready(function() {
    bicycle.init();
    $(document)    
    .on( 'shopify:section:load', bicycle.initRelatedProductSlider )
    .on( 'shopify:section:unload', bicycle.initRelatedProductSlider)

    .on( 'shopify:section:load', bicycle.initProductSidebarSlider )
    .on( 'shopify:section:unload', bicycle.initProductSidebarSlider)

    .on( 'shopify:section:load', bicycle.initProductMoreview )
    .on( 'shopify:section:unload', bicycle.initProductMoreview)

    .on( 'shopify:section:load', bicycle.Page_brands )
    .on( 'shopify:section:unload', bicycle.Page_brands)


    .on( 'shopify:section:load', bicycle.initMobileMenu )
    .on( 'shopify:section:unload', bicycle.initMobileMenu)

    .on( 'shopify:section:load', bicycle.SlicksliderHP )
    .on( 'shopify:section:unload', bicycle.SlicksliderHP)
    
    
    .on( 'shopify:section:load', bicycle.initQuickView )
    .on( 'shopify:section:unload', bicycle.initQuickView)


    .on( 'shopify:section:load', bicycle.initslideshow )
    .on( 'shopify:section:unload', bicycle.initslideshow);

    $(document).on('click touchstart', function(e) {
      var lookbook_modal = $('.lookbook-modal');
      var hd_option = $('.hd-option');

      if (!lookbook_modal.is(e.target) && lookbook_modal.has(e.target).length === 0 && !hd_option.is(e.target) && hd_option.has(e.target).length === 0 && window.innerWidth > 1024){
        bicycle.closeLookBookPopup();
      }
    });
  });

  $(window).off('resize.mobileMenu').on('resize.mobileMenu', function() {
    bicycle.initMobileMenu();
  });


  $(window).off('resize.initDropdownFooter').on('resize.initDropdownFooter', function() {
    bicycle.initDropdownFooterMenu();
  });

  $(document).keyup(function(e) {
    if (e.keyCode == 27) {
      bicycle.closeLookBookPopup();
      clearTimeout(bicycle.bicycleTimeout);
      if ($('.modal').is(':visible')) {
        $('.modal').fadeOut(500);
      }
    }
  });

  if($('.template-collection').length || $('.template-product').length || $('.template-blog').length || $('.template-article').length) {
    var currentWinWidth = $(window).width();
    var resizeTimeout;

    $(window).off('resize.sidebarInitToggle').on('resize.sidebarInitToggle', function() {
      clearTimeout(resizeTimeout);

      resizeTimeout = setTimeout(function() {
        if (currentWinWidth !== $(window).width()){
          currentWinWidth = $(window).width();
        }
      }, 50);
    });
  };

  var bicycle = {
    bicycleTimeout: null,
    isSidebarAjaxClick: false,
    init: function() {
      this.closeHeaderTop(); /// Roi
      this.cookie_popup(); /// Roi
      this.closeproductcms();//roi
      this.initSearchToggle();// roi
      this.initMobileMenu(); //roi
      this.MultiOption();//roi
      this.initDropdownLogin();//roi
      this.initLookBookProduct();//roi
      this.ProductTabs();//roi

      this.initDropdownCart();//roi
      this.closeDropdown();//roi
      this.initColorSwatchGrid();//roi
      this.initScrollTop();//roi

      this.closeModal();//roi
      this.initAddToCart();//roi

      this.initQuickView();//roi

      this.initFixedTopMenu();//rôi
      this.initDropdownFooterMenu();// roi
      
      this.checkbox_checkout();

      if($('.wishlist-content').length > 0){
      	this.initWishListPage();
      }
      if( $('.addwishlist').length ){
        this.initWishList();
      }

      this.SlicksliderHP();// roi

      if($('.template-index').length) {
        this.initToDay();//roi
      };

      if($('.template-index').length || $('.lookbook-content').length) {
        this.initslideshow();//roi
      };

      if($('.template-collection').length || $('.template-product').length || $('.template-blog').length || $('.template-article').length) {
        this.initProductSidebarSlider();// roi
        this.sidebarInitToggle();// roi
        this.sidebarCategoryInitToggle();
      };

      if($('.template-collection').length) {
        this.initSidebar();//roi
        this.initToolbar();//roi
        this.sidebarMapPaging();//roi
        this.initInfiniteScrolling();//roi
      };

      if($('.template-product').length) {
        this.initProductMoreview(); //rooi
        this.initProductAddToCart();//rooi
        this.initZoom();//rooi
        this.initEventPopupNextPrevProduct();//rooi
        this.initStickyAddtoCart();
        this.productRecomendation();
      };

      if($('.template-cart').length) {
        this.initCartQty();//rooi
      };

      if($('.template-search').length) {
        this.sidebarMapPaging();//roi
        this.sidebarParams();//roi
        this.initInfiniteScrolling();//roi
      };

      if($('.brands-page').length) {
        this.Page_brands();//rooi
      };
    },

    cookie_popup: function() {
      $('#accept-cookies').show();
      if ($.cookie('cookieMessage') == 'closed') {
        $('#accept-cookies').remove();
      }

      $('#accept-cookies .btn').bind('click',function(){
        $('#accept-cookies').remove();
        $.cookie('cookieMessage', 'closed', {expires:1, path:'/'});
      });

      $('#accept-cookies .close').bind('click',function(){
        $('#accept-cookies').remove();
      });
    },

    closeHeaderTop: function() {
      if ($.cookie('headerTop') == 'closed') {
        $('.header-top').remove();
      }
      $('.header-top a.close').bind('click',function(){
        $('.header-top').remove();
        $.cookie('headerTop', 'closed', {expires:1, path:'/'});
      });
    },

    closeproductcms: function() {
      if ($.cookie('closeproductcms') == 'closed') {
        $('.product-cms-custom').remove();
      }
      $('.product-cms-custom a.close_cms').bind('click',function(){
        $('.product-cms-custom').remove();
        $.cookie('closeproductcms', 'closed', {expires:1, path:'/'});
      });
    },

    initSearchToggle: function() {
      var mbSearch = $('.menu-mobile .searchToggle');
      var navSearch = $('.site-header .header-bottom .column-middle');

      if(mbSearch.length) {
        mbSearch.off('click.initSearchToggle').on('click.initSearchToggle', function(e) {
          e.preventDefault();
          e.stopPropagation();
          navSearch.toggle();
          $('html').toggleClass("open-search");
          $('.header-bottom .menu-mobile').toggleClass("search-open");
          if (wrapperCart.hasClass('is-open')) {
            wrapperCart.removeClass('is-open');
          };

          if(navCustomer.hasClass('is-open')) {
            navCustomer.removeClass('is-open');
          };
          if($("html").hasClass("menu-open")){
            $("html").css({'overflow': ''});
            $("html").removeClass('menu-open');
            $(".header-bottom .menu-mobile").removeClass('open_menu');
            $(".site-nav-dropdown").removeClass('open-menu');
            $(".site-nav .dropdow-lv2").removeClass('open-menu');
          }
        });

      }
    },

    initMobileMenu:function() {

      if(window.innerWidth > 1025) {
        $(".wrapper-navigation .wrapper-left .categories-title").off('click').on("click",function(){
          
          $(this).parent().toggleClass("is-open");
          $(this).parent().find(".nav-bar").toggleClass("show");
          
          if($('.fix-top').length) {
            $(this).parents().find(".column-left").toggleClass("is-open");
          };
          
          if(!$('.wrapper-navigation .nav-bar').hasClass('show')){
            $('.wrapper-left').removeClass('is-open');
            $('.column-left').removeClass('is-open');
          }
          
        });

        if($('html').hasClass('menu-open')) {
          $('html').css({ "overflow": ""});
        }
        $('.ft-multi-cur').prependTo($('.lang-currency-groups')); 
      }else{

        if(iconNav.is(':visible')) {
          var heightHeader = $('.site-header').outerHeight();
          body.off('click.toggleNav', '#showLeftPush').on('click.toggleNav', '#showLeftPush', function(e) {
            e.preventDefault();
            e.stopPropagation();
            if($('.search-results').is(':visible')) {
              $('.search-results').hide();
            };

            if($('html').hasClass('open-search')) {
              $('html').removeClass('open-search');
              $('.header-bottom .menu-mobile').removeClass('search-open');
              $('.header-bottom .column-middle').hide();
            }

            if (wrapperCart.hasClass('is-open')) {
              wrapperCart.removeClass('is-open');
            };

            if(navCustomer.hasClass('is-open')) {
              navCustomer.removeClass('is-open');
            };

            iconNav.toggleClass('open');


            $(".header-bottom .menu-mobile").toggleClass('open_menu');
            $('html').toggleClass('menu-open');

            if($('html').hasClass('menu-open')) {
              $('html').css({ "overflow": "hidden"});
            }
            else {
              $('html').css({ "overflow": ""});
              $('.navigation .site-nav .site-nav-dropdown.open-menu, .navigation .site-nav .site-nav-dropdown .inner ul.dropdow-lv2.open-menu').removeClass('open-menu').css({ "overflow": ""});
              $('.navigation .site-nav .icon-dropdown').removeClass('mobile-toggle-open');
            }

            $('.wrap-overlay, .wrapper-left .close-menu').on('click', function(){ 
              $(".header-bottom .menu-mobile").removeClass('open_menu');
              $("#showLeftPush").removeClass('open');
              $(".site-nav-dropdown").removeClass('open-menu');
              $(".dropdow-lv2").removeClass('open-menu');
              $('html').removeClass('menu-open');
              $('html').css({ "overflow": ""});
              $('.navigation .site-nav .site-nav-dropdown.open-menu, .navigation .site-nav .site-nav-dropdown .inner ul.dropdow-lv2.open-menu').removeClass('open-menu').css({ "overflow": ""});
              $('.navigation .site-nav .icon-dropdown').removeClass('mobile-toggle-open');
            });

          });                
          bicycle.initDropdownMenuMobile();
        }; 
        $('.ft-multi-cur').prependTo($('.wrapper-navigation .hd-option'));  
      }
    },

    initDropdownMenuMobile: function() {
      if(window.innerWidth < 1025) {
        var menuMobile = $('.site-nav .dropdown, .site-nav .inner-wrap'),
            menuMbTitle = $('.site-nav .menu-mb-title'),
            icondropdown = $('.site-nav .dropdown a .icon-dropdown');
        icondropdown.off('click.current').on('click.current', function(e) {
          e.preventDefault();
          e.stopPropagation();
          $(this).parent().next('.site-nav-dropdown, .dropdow-lv2').addClass('open-menu');
        });
        menuMobile.off('click.current').on('click.current', function(e) {
          e.preventDefault();
          e.stopPropagation();
          $(this).children('.site-nav-dropdown, .dropdow-lv2').addClass('open-menu');
        });
        menuMobile.find('a').on('click', function(e) {
          e.stopPropagation();
        });
        menuMbTitle.off('click.closeMenu').on('click.closeMenu', function(e) {
          e.preventDefault();
          e.stopPropagation();
          $(this).parent().removeClass('open-menu');
        });
      }


    },

    initFixedTopMenu: function() {
      if($('.fix-top').length) {
        $('.header-bottom').on('sticky-start', function() { 
          $('body').addClass('fixed_top');
          
          if($('.template-index').length){
          	$('.nav-bar').removeClass('show');
            $(".column-left").removeClass('is-open');
          }
          
        });

        $('.header-bottom').on('sticky-end', function() { 
          $('body').removeClass('fixed_top');
          if($('.template-index').length){
          	$('.nav-bar').addClass('show');
          }
        });
        $(".header-bottom").sticky({topSpacing:0});

        $(".header-bottom .icon-menu").click(function(){
          $(".wrapper-navigation .wrapper-left .categories-title").click();
        });

      };        
    },

    doOpenDropdown: function(icon, parentSlt) {
      icon.off('click.toogleDropdown').on('click.toogleDropdown', function(e) {
        e.preventDefault();
        e.stopPropagation();

        if($('.search-results').is(':visible')) {
          $('.search-results').hide();
        };

        if($('html').hasClass('open-search')) {
          $('html').removeClass('open-search')
          $('.header-bottom .menu-mobile').removeClass('search-open');
          $('.site-header .header-bottom .column-middle').hide();
        }

        if($("html").hasClass("menu-open")){
          $("html").removeClass('menu-open');
          $("html").css({ "overflow": ""});
          $(".header-bottom .menu-mobile").removeClass('open_menu');
          $(".site-nav-dropdown").removeClass('open-menu');
          $(".site-nav .dropdow-lv2").removeClass('open-menu');
        }

        if(parentSlt == '.nav-customer') {
          if (wrapperCart.hasClass('is-open')) {
            wrapperCart.removeClass('is-open');
          }
        }
        else if(parentSlt == '.wrapper-top-cart') {
          if(navCustomer.hasClass('is-open')) {
            navCustomer.removeClass('is-open');
          };
        };

        $(parentSlt).toggleClass('is-open');
      });
    },

    closeDropdown:function() {
      var dropdownCustomerSlt = '#dropdown-customer';
      var dropdownCartSlt = '#dropdown-cart';

      doc.off('click.closeDropdown').on('click.closeDropdown', function(e) {   
        if ((!$(e.target).closest(dropdownCustomerSlt).length && !$(e.target).closest('.nav-customer').length && navCustomer.hasClass('is-open')) || (!$(e.target).closest(dropdownCartSlt).length && !$(e.target).closest('.wrapper-top-cart').length && wrapperCart.hasClass('is-open'))) {
          wrapperCart.removeClass('is-open');
          navCustomer.removeClass('is-open');
        }
      });
    },

    initDropdownLogin: function() {
      bicycle.doOpenDropdown($('.header-bottom .userToggle'), '.nav-customer');        
    },

    MultiOption: function(){

      var sortbyTextLang =$('.lang-currency-groups .lang-switcher').find('.active').text().trim();

      $(".lang-currency-groups .hd_lang").text(sortbyTextLang);


      var sortbyText = $('.lang-currency-groups #currencies').find('.active').text().trim();

      $(".lang-currency-groups .hd_currency").text(sortbyText);

      var icon_img = $('.lang-currency-groups .lang-switcher').find('.active img').attr('data-src');

      $('.lang-currency-groups .lang-switcher .icon-lang img').attr({ src: icon_img });

      $('.lang-currency-groups #currencies li').on('click', function(){
        var sortbyText = $('.lang-currency-groups #currencies').find('.active').text();

        $(".lang-currency-groups .hd_currency").text(sortbyText);
      });

      $(document).click(function(e){
        var mult = $(".lang-currency-groups .ft-multi-cur .lang-switcher");
        if (!mult.is(e.target) && mult.has(e.target).length === 0 ){
          $('.lang-currency-groups .lang-switcher .language').slideUp(300);
        }
      });

      $('.lang-currency-groups .ft-multi-cur .lang-switcher').on('click', function(){
        $('.lang-currency-groups .lang-switcher .language').slideToggle(300);

      }); 


      $(document).click(function(e){
        var mulc = $(".ft-multi-cur .currency-groups");
        if (!mulc.is(e.target) && mulc.has(e.target).length === 0 ){
          $('.lang-currency-groups .currency-groups #currencies').slideUp(300);
        }
      });

      $('.lang-currency-groups .ft-multi-cur .currency-groups').on('click', function(){
        $('.lang-currency-groups .currency-groups #currencies').slideToggle(300);

      });
    },    

    initslideshow: function(slideshow, autoplay , autoplaySpeed, fade) {   
      $('.slideslick').each(function(){
        var slideshow =  $(this),
            autoplay=  $(this).data('auto'), 
            autoplaySpeed=  $(this).data('speed'),
            fade=  $(this).data('transition');
        bicycle.slideshow(slideshow, autoplay , autoplaySpeed, fade);

      });
    },

    slideshow: function(slideshow, autoplay , autoplaySpeed, fade){
      if(slideshow.length){
        slideshow.not('.slick-initialized').slick({
          slidesToShow: 1,
          slidesToScroll: 1,
          autoplay: autoplay, 
          autoplaySpeed: autoplaySpeed,
          fade: fade,
          adaptiveHeight: true,
          arrows: true,
          nextArrow: '<button type="button" class="slick-next"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 17 33" xml:space="preserve"><g id="e4eb89a6-f885-43b8-9259-0d6b1516fab0"><g id="_x38_e584754-6657-46f1-a9d8-2cfd6623b552"><g><polygon points="14.9,14.5 0,0 0,3.7 11.1,14.5 13.2,16.5 11.1,18.5 0,29.3 0,33 14.9,18.5 17,16.5 "/></g></g></g></svg></button>',
          prevArrow: '<button type="button" class="slick-prev"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 33"><g id="7f9a1925-e8c7-4614-8787-3c6095a9f6e1" data-name="Layer 2"><g id="c9b7920a-81fa-4bfe-ad13-4da717c6854b" data-name="Layer 1"><g id="c2d982ff-0cf6-4220-b365-47f30d708fea" data-name="e4eb89a6-f885-43b8-9259-0d6b1516fab0"><g id="f51d455e-6b9c-4c4e-96db-a5004582beda" data-name="8e584754-6657-46f1-a9d8-2cfd6623b552"><polygon points="0 16.5 2.1 18.5 17 33 17 29.3 5.9 18.5 3.8 16.5 5.9 14.5 17 3.7 17 0 2.1 14.5 0 16.5"/></g></g></g></g></svg></button>',
          speed : 1000,
          dots: true,
          responsive: [
            {
              breakpoint: 1024,
              settings: {
                arrows:false,
              }
            }
          ]
          
        });
        $(slideshow).on('afterChange', function(event, slick, currentSlide){
           bicycle.closeLookBookPopup();
        });
      }
    },



    closeLookBookPopup: function(){
      $('.lookbook-modal').fadeOut(100);
    },

    initLookBookProduct: function(){
      $(document).on('click','.lookbook-item .pr-lb', function(e){
        var handle = $(this).data('handle'),
            position = $(this);

        bicycle.doAjaxLookBook(handle, position);

        $('.lookbook-modal .close-modal').on('click',function(){
          bicycle.closeLookBookPopup();
        });        
      });
    },

    doAjaxLookBook: function(handle, position){
      if(window.innerWidth > 1024){
        var offSet = $(position).offset(),
            top= offSet.top,
            left = offSet.left,
            content = position.closest('.lazy-images-contain').innerWidth(),
            newtop = top - 200 + "px",
            newleft = left - 300 + "px";



        if(left < 350) {
          newleft = (left - 300) + 350 + "px";
        }
      }
      else{
        var offSet = $(position).offset(),
            top= offSet.top,
            left = offSet.left,
            newtop = top,
            newleft = left + 20 + "px";
      }

      $.ajax({
        url: window.router + '/products/'+handle+'?view=json',
        success: function(data) {
          $('.lookbook-modal').fadeIn(300).css({'left': newleft, 'top': newtop });;
          $('.lookbook-content').html(data);
          bicycle.translateBlock('.lookbook-content');
          if (window.show_multiple_currencies) {
            Currency.convertAll(window.shop_currency, $('#currencies .active').attr('data-currency'), 'span.money', 'money_format');
          }
          if ($('.spr-badge').length > 0) {
            return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
          }
        },
        error: function(xhr, text) {
          $('.lookbook-modal').fadeOut(100);
          $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);
          bicycle.showModalError('.ajax-error-modal');
        }
      });
    },

    Slickslider: function(dataslick, row, rowtb, rowtblg, rowbm, arrows, dots, auto, fade, arrowsmb, dotsmb){
      dataslick.not('.slick-initialized').slick({
        infinite: false,
        slidesToShow: row,
        slidesToScroll: 1,
        arrows: arrows,
        dots: dots,
        fade: fade,
        autoplay:auto,
        autoplaySpeed: 5000,
        nextArrow: '<button type="button" class="slick-next"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 17 33" xml:space="preserve"><g id="e4eb89a6-f885-43b8-9259-0d6b1516fab0"><g id="_x38_e584754-6657-46f1-a9d8-2cfd6623b552"><g><polygon points="14.9,14.5 0,0 0,3.7 11.1,14.5 13.2,16.5 11.1,18.5 0,29.3 0,33 14.9,18.5 17,16.5 "/></g></g></g></svg></button>',
        prevArrow: '<button type="button" class="slick-prev"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 33"><g id="7f9a1925-e8c7-4614-8787-3c6095a9f6e1" data-name="Layer 2"><g id="c9b7920a-81fa-4bfe-ad13-4da717c6854b" data-name="Layer 1"><g id="c2d982ff-0cf6-4220-b365-47f30d708fea" data-name="e4eb89a6-f885-43b8-9259-0d6b1516fab0"><g id="f51d455e-6b9c-4c4e-96db-a5004582beda" data-name="8e584754-6657-46f1-a9d8-2cfd6623b552"><polygon points="0 16.5 2.1 18.5 17 33 17 29.3 5.9 18.5 3.8 16.5 5.9 14.5 17 3.7 17 0 2.1 14.5 0 16.5"/></g></g></g></g></svg></button>',        
        speed : 500,  
        responsive: [
          {
            breakpoint: 1025,
            settings: {
              slidesToShow: rowtb,
              slidesToScroll: 1,
              dots: dots,
              arrows: arrows,
              autoplay:auto,
            }
          },
          {
            breakpoint: 992,
            settings: {
              slidesToShow: rowtblg,
              slidesToScroll: 1,
              dots: dotsmb,
              arrows: arrowsmb,
              autoplay:auto,
            }
          },
          {
            breakpoint: 767,
            settings: {
              slidesToShow: rowbm,
              slidesToScroll: 1,
              dots: dotsmb,
              arrows: arrowsmb,
              autoplay:auto,
            }
          },
          {
            breakpoint: 370,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
              dots: dotsmb,
              arrows:arrowsmb,
              autoplay:auto,
            }
          }
        ]
      });
    },

    SlicksliderHP: function() {
      $('.has-slick').each(function(){
        var slick = $(this),
            row = $(this).data('row'),
            rowtb = $(this).data('rowtb'),
            rowtblg = $(this).data('rowtblg'),
            rowbm = $(this).data('rowbm');

        if($(this).hasClass('not-arrows')){
          var arrows = false,
              dots = true,
              auto = true,
              fade = $(this).data('fade');
        }
        else{
          var arrows = true,
              dots = false,
              auto = false,
              fade = false;
        }

        if($(this).hasClass('has-arrows')){

          var arrowsmb = true,
              dotsmb= false;
        } else{
          var arrowsmb= false,
              dotsmb= true;
        }

        bicycle.Slickslider(slick, row, rowtb, rowtblg, rowbm, arrows, dots, auto, fade, arrowsmb, dotsmb);
      });
    },

    ProductTabs: function(){

      $('.home-product-tab').each(function(){
        var sectionID = $(this).data('id'),
            dataUrl = $(this).find('.tab-active').data('href'),
            dataProducts = $(this).find('.tab-content .active .product-grids'),
            row = $(this).find('.tab-content .active').data('row'),
            rowtb = $(this).find('.tab-content .active').data('rowtb'),
            rowtblg = $(this).find('.tab-content .active').data('rowtblg'),
            rowbm = $(this).find('.tab-content .active').data('rowbm'),
            arrows = true,
            dots = false,
            auto = false,
            fade = false,
            arrowsmb= false,
            dotsmb= true;

        $.ajax({
          url: dataUrl,
          type:'GET',
          success: function(data){
            if(dataUrl == '/collections/?view=json'){
              $('.product-tab-bottom .loading').text('Please link to collctions');
            }
            $(dataProducts).html($(data).find('.grid-items').html());            
            bicycle.Slickslider(dataProducts, row, rowtb, rowtblg, rowbm, arrows, dots, auto, fade, arrowsmb, dotsmb);
            bicycle.initColorSwatchGrid();

            if (window.show_multiple_currencies) {
              Currency.convertAll(window.shop_currency, $('#currencies .active').attr('data-currency'), 'span.money', 'money_format');
            }

            bicycle.translateBlock(".home-product-tab");
            
            if($(".wishlist-btn").length > 0){
              bicycle.initWishList();
            }
          },
          error: function (msg) {
            $('.product-tab-bottom .loading').text('Please link to collctions');
          },
        });

      });

      var selected = $('.home-product-tab .nav-tabs li a:not(.tab-active)');

      $(selected).on('click', function(event){
        var dataUrl = $(this).data('href');
        var dataID =  $(this).attr('href');
        var dataPR = $(dataID).find('.product-grids');
        var row = $(dataID).data('row'),
            rowtb = $(dataID).data('rowtb'),
            rowtblg =  $(dataID).data('rowtblg'),
            rowbm = $(dataID).data('rowbm'),
            arrows = true,
            dots = false,
            auto = false,
            fade = false,
            arrowsmb= false,
            dotsmb= true;
        if($(dataPR).hasClass('slick-initialized')){
          event.preventDefault();
        }

        else{
          $.ajax({
            url: dataUrl,
            type:'GET',
            success: function(data){
              if(dataUrl == '/collections/?view=json'){
                $(dataPR).find('.loading').text('Sorry, there are no products in this collection');
              }
              $(dataPR).html($(data).find('.grid-items').html());
              bicycle.Slickslider(dataPR, row, rowtb, rowtblg, rowbm, arrows, dots, auto, fade, arrowsmb, dotsmb);
              bicycle.initColorSwatchGrid();
			  bicycle.translateBlock(".home-product-tab");
              if($(".wishlist-btn").length > 0){
                console.log('a')
                bicycle.initWishList();
              }
              
              if (window.show_multiple_currencies) {
                Currency.convertAll(window.shop_currency, $('#currencies .active').attr('data-currency'), 'span.money', 'money_format');
              }
              if ($('.spr-badge').length > 0) {
                return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
              }
              
            },
            error: function (msg) {
              $('.product-tab-bottom .loading').text('Sorry, there are no products in this collection');
            },
          });
        }
      });
    },

    clickDropdownCart:function() {
      bicycle.doOpenDropdown($('.header-bottom .cartToggle'), '.wrapper-top-cart');        
    },

    initDropdownCart:function() {
      bicycle.clickDropdownCart();
      bicycle.checkItemsInDropdownCart();
      bicycle.removeItemDropdownCart();
    },

    initColorSwatchGrid: function() {
      var windowWidth = $(window).width();

      $(document).on('click', '.item-swatch li label', function(){
        $(".item-swatch li label").removeClass("active");
        $(this).addClass("active");
        var newImage = $(this).data('img');
        $(this).parents('.product-item').find('.product-grid-image img.images-one').attr({ src: newImage }); 
        return false;
      });
    },

    initScrollTop: function() {
      $(window).scroll(function() {
        if ($(this).scrollTop() > 220) {
          $('#back-top').fadeIn(400);
        }

        else {
          $('#back-top').fadeOut(400);
        }
      });

      $('#back-top').off('click.scrollTop').on('click.scrollTop', function(e) {
        e.preventDefault();
        e.stopPropagation();

        $('html, body').animate({scrollTop: 0}, 400);
        return false;
      });
    },

    initProductSidebarSlider: function() {
      var widgetFeaturedProduct = $('.sidebar .widget-featured-product');

      widgetFeaturedProduct.each(function() {
        var productGrid = $(this).find('.products-grid');

        if(productGrid.length && !productGrid.hasClass('slick-initialized')) {
          productGrid.slick({
            dots: false,
            slidesToScroll: 1,
            slidesToShow: 1,
            verticalSwiping: false,
            nextArrow: '<button type="button" class="slick-next"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 17 33" xml:space="preserve"><g id="e4eb89a6-f885-43b8-9259-0d6b1516fab0"><g id="_x38_e584754-6657-46f1-a9d8-2cfd6623b552"><g><polygon points="14.9,14.5 0,0 0,3.7 11.1,14.5 13.2,16.5 11.1,18.5 0,29.3 0,33 14.9,18.5 17,16.5 "/></g></g></g></svg></button>',
            prevArrow: '<button type="button" class="slick-prev"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 33"><g id="7f9a1925-e8c7-4614-8787-3c6095a9f6e1" data-name="Layer 2"><g id="c9b7920a-81fa-4bfe-ad13-4da717c6854b" data-name="Layer 1"><g id="c2d982ff-0cf6-4220-b365-47f30d708fea" data-name="e4eb89a6-f885-43b8-9259-0d6b1516fab0"><g id="f51d455e-6b9c-4c4e-96db-a5004582beda" data-name="8e584754-6657-46f1-a9d8-2cfd6623b552"><polygon points="0 16.5 2.1 18.5 17 33 17 29.3 5.9 18.5 3.8 16.5 5.9 14.5 17 3.7 17 0 2.1 14.5 0 16.5"/></g></g></g></g></svg></button>',
          });
        };           
      });
    },

    sidebarParams: function() {
      Shopify.queryParams = {};

      //get after ?...=> Object {q: "Acme"} 

      if (location.search.length) {
        for (var aKeyValue, i = 0, aCouples = location.search.substr(1).split('&'); i < aCouples.length; i++) {
          aKeyValue = aCouples[i].split('=');

          if (aKeyValue.length > 1) {
            Shopify.queryParams[decodeURIComponent(aKeyValue[0])] = decodeURIComponent(aKeyValue[1]);
          }
        }
      };
    },

    showLoading: function() {
      $('.loading-modal').show();
    },

    hideLoading: function() {
      $('.loading-modal').hide();
    },

    showModal: function(selector) {
      $(selector).fadeIn(500);
      bicycle.bicycleTimeout = setTimeout(function() {
        $(selector).fadeOut(500);
      }, 5000);
    },

    closeModal: function() {
      $('.continue-shopping').click(function() {
        clearTimeout(bicycle.ellaTimeout);
        $('.ajax-success-modal').fadeOut(500);
      });
      $('.close-modal').click(function(e) {
        e.preventDefault();
        e.stopPropagation();
        clearTimeout(bicycle.bicycleTimeout);
        $('.ajax-success-modal').fadeOut(500);
      });

    },

    checkNeedToConvertCurrency: function() {
      return (window.show_multiple_currencies && Currency.currentCurrency != shopCurrency) || window.show_auto_currency;
    },

    sidebarMapEvents: function() {
      bicycle.sidebarMapCategories();
      bicycle.sidebarMapTagEvents();
    },

    toolbarMapEvents:function() {
      bicycle.sidebarParams();
      bicycle.sidebarMapView();
      bicycle.sidebarMapSorting();
    },

    initSidebar: function() {
      if ($('.collection-sidebar').length) {
        bicycle.sidebarParams();
        bicycle.sidebarMapEvents();          
        bicycle.sidebarMapClear();
        bicycle.sidebarMapClearAll();
      };
    },

    initToolbar: function() {
      bicycle.initDropdownFilterSortby();
      bicycle.toolbarMapEvents();
    },

    sidebarMapPaging: function() {
      var paginationSlt = '.pagination-page a';

      body.off('click.initMapPaging', paginationSlt).on('click.initMapPaging', paginationSlt, function(e) {
        var tiler = $('head title').text();
        e.preventDefault();
        e.stopPropagation();

        var page = $(this).attr('href').match(/page=\d+/g);

        if (page) {
          Shopify.queryParams.page = parseInt(page[0].match(/\d+/g));

          if (Shopify.queryParams.page) {
            var newurl = bicycle.sidebarCreateUrl();

            bicycle.isSidebarAjaxClick = true;

            History.pushState({
              param: Shopify.queryParams
            }, newurl, newurl);
            var tiler = $('head title').text(tiler);
            bicycle.sidebarGetContent(newurl);

            var top = $('.template-collection .row-bt, .search-page').offset().top;

            $('body,html').animate({
              scrollTop: top
            }, 600);
          };
        };

      });
    },

    initInfiniteScrolling: function() {
      var infiniteScrolling = $('.infinite-scrolling');
      var infiniteScrollingLinkSlt = '.infinite-scrolling a';

      if(infiniteScrolling.length) {
        body.off('click.initInfiniteScrolling', infiniteScrollingLinkSlt).on('click.initInfiniteScrolling', infiniteScrollingLinkSlt, function(e) {
          e.preventDefault();
          e.stopPropagation();

          if (!$(this).hasClass('disabled')) {
            bicycle.doInfiniteScrolling();
          };
        });

        if(window.infinity_scroll_feature) {
          window.infinitPos = 0;

          $(window).scroll(function() {
            var pos = infiniteScrolling.offset().top;

            if ($(this).scrollTop() > (pos - 600) && $(this).scrollTop() - window.infinitPos > 1000) {
              window.infinitPos = $(this).scrollTop();

              $(infiniteScrollingLinkSlt).trigger("click");
            }
          });
        }
      };
    },

    doInfiniteScrolling: function() {
      var currentList = $('.block-row .products-grid');

      if (!currentList.length) {
        currentList = $('.block-row .product-list');
      };

      if (currentList) {
        var showMoreButton = $('.infinite-scrolling a');

        $.ajax({
          type: 'GET',
          url: showMoreButton.attr('href'),

          beforeSend: function() {
            bicycle.showLoading();
          },

          success: function(data) {
            bicycle.hideLoading();

            var products = $(data).find('.block-row .products-grid');

            if (!products.length) {
              products = $(data).find('.block-row .product-list');
            };

            if (products.length) {
              currentList.append(products.children());
              bicycle.translateBlock('.main-content');

              //get link of Show more
              if ($(data).find('.infinite-scrolling').length > 0) {
                showMoreButton.attr('href', $(data).find('.infinite-scrolling a').attr('href'));
              }
              else {
                //no more products
                var noMoreText = window.inventory_text.no_more_product;
                if(window.multi_lang){
                  if(translator.isLang2()){
                    noMoreText = window.lang2.collections.general.no_more_product;
                  }
                }
                

                showMoreButton.html(noMoreText).addClass('disabled');
              };
              
              if($(".wishlist-btn").length > 0){
                bicycle.initWishList();
              }


              //currency
              if (bicycle.checkNeedToConvertCurrency()) {
                Currency.convertAll(window.shop_currency, $('#currencies .active').attr('data-currency'), 'span.money', 'money_format');
              };

              //product review
              if ($(".spr-badge").length > 0) {
                return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
              };
            }
          },

          error: function(xhr, text) {
            bicycle.hideLoading();
            $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);
            bicycle.showModal('.ajax-error-modal');
          },
          dataType: "html"
        });
      }
    },

    sidebarMapCategories: function() {
      var sidebarLinkSlt = '.sidebar-links a';
      var sidebarLink = $(sidebarLinkSlt);

      body.off('click.activeCategory', sidebarLinkSlt).on('click.activeCategory', sidebarLinkSlt, function(e) {
        if($(this).attr('href') !== '/') {
          e.preventDefault();
          e.stopPropagation();

          var self = $(this);
          var parent = self.parent();

          if(!$(this).hasClass('active')) {
            delete Shopify.queryParams.q;
            delete Shopify.queryParams.constraint;
            bicycle.sidebarAjaxClick($(this).attr('href'));
          };

          sidebarLink.not(self).removeClass('active');
          $(this).addClass('active'); 

          if (parent.hasClass('dropdown') && !parent.hasClass('open')) {
            $('.dropdown.open').removeClass('open');
            sidebarLink.siblings('.dropdown-cat').hide();
            self.siblings('.dropdown-cat').show();
            parent.addClass('open');                  	  
          };
        };
      });
    },

    sidebarMapTagEvents: function() {
      var sidebarTag = $('.sidebar-tag a:not(".clear"), .sidebar-tag label, .refined .selected-tag');

      sidebarTag.off('click.checkedTag').on('click.checkedTag', function(e) {
        e.preventDefault();
        e.stopPropagation();

        var currentTags = [];

        if (Shopify.queryParams.constraint) {
          currentTags = Shopify.queryParams.constraint.split('+'); //Array
        };

        //one selection or multi selection
        if (!window.enable_sidebar_multiple_choice && !$(this).prev().is(':checked')) {
          //remove other selection first
          var otherTag = $(this).closest('.sidebar-tag, .refined-widgets').find('input:checked');

          if (otherTag.length) {
            var tagName = otherTag.val();
            if (tagName) {
              var tagPos = currentTags.indexOf(tagName);
              if (tagPos >= 0) {
                //remove tag
                currentTags.splice(tagPos, 1);
              }
            }
          };
        };

        var tagName = $(this).prev().val();

        if (tagName) {
          var tagPos = currentTags.indexOf(tagName);

          if (tagPos >= 0) {
            //tag already existed, remove tag
            currentTags.splice(tagPos, 1);
          }
          else {
            //tag not existed
            currentTags.push(tagName);
          }
        };

        if (currentTags.length) {
          Shopify.queryParams.constraint = currentTags.join('+');
        }
        else {
          delete Shopify.queryParams.constraint;
        };

        bicycle.sidebarAjaxClick();
      });
    },

    sidebarMapClear: function() {
      var sidebarTag = $('.sidebar-tag');

      sidebarTag.each(function() {
        var sidebarTag = $(this);

        if (sidebarTag.find('input:checked').length) {
          //has active tag
          sidebarTag.find('.clear').show().click(function(e) {
            e.preventDefault();
            e.stopPropagation();

            var currentTags = [];

            if (Shopify.queryParams.constraint) {
              currentTags = Shopify.queryParams.constraint.split('+');
            };

            sidebarTag.find("input:checked").each(function() {
              var selectedTag = $(this);
              var tagName = selectedTag.val();

              if (tagName) {
                var tagPos = currentTags.indexOf(tagName);
                if (tagPos >= 0) {
                  //remove tag
                  currentTags.splice(tagPos, 1);
                };
              };
            });

            if (currentTags.length) {
              Shopify.queryParams.constraint = currentTags.join('+');
            }
            else {
              delete Shopify.queryParams.constraint;
            };

            bicycle.sidebarAjaxClick();

          });
        }
      });
    },

    sidebarMapClearAll: function() {
      var clearAllSlt = '.refined-widgets a.clear-all';
      var clearAllElm = $(clearAllSlt);

      body.off('click.clearAllTags', clearAllSlt).on('click.clearAllTags', clearAllSlt, function(e) {
        e.preventDefault();
        e.stopPropagation();

        delete Shopify.queryParams.constraint;
        delete Shopify.queryParams.q;

        bicycle.sidebarAjaxClick();
      });
    },

    sidebarMapView: function() {
      var viewAsSlt = '.toolbar .view-mode .view-as';
      var viewAs = $(viewAsSlt);

      body.off('click.mapView', viewAsSlt).on('click.mapView', viewAsSlt, function(e) {
        e.preventDefault();
        e.stopPropagation();

        if (!$(this).hasClass('active')) {

          if ($(this).hasClass('list')) {
            Shopify.queryParams.view = 'list';
          }
          else {
            Shopify.queryParams.view = '';
          }

          bicycle.sidebarAjaxClick();

          $('.view-mode .view-as.active').removeClass('active');
          $(this).addClass('active');
        }
      });
    },

    initDropdownFilterSortby:function() {
      var labelSlt = '.filter-sortby .label-tab';
      var dropdownMenuSlt = '.filter-sortby .dropdown-menu';

      body.off('click.dropdownFilterSortby', labelSlt).on('click.dropdownFilterSortby', labelSlt, function(e) {
        e.preventDefault();
        e.stopPropagation();

        $(this).toggleClass('active').next('.dropdown-menu').toggle();
      });

      doc.off('click.hideFilterSortby').on('click.hideFilterSortby', function(e) {
        if (!$(e.target).closest(dropdownMenuSlt).length && $(labelSlt).hasClass('active')) {
          $(labelSlt).removeClass('active').next('.dropdown-menu').hide();
        }
      });
    },

    sidebarMapSorting: function() {
      var sortbyFilterSlt = '.filter-sortby li span';
      var sortbyFilter = $(sortbyFilterSlt);

      body.off('click.sortBy', sortbyFilterSlt).on('click.sortBy', sortbyFilterSlt, function(e) {
        e.preventDefault();
        e.stopPropagation();

        var self = $(this);
        var parent = self.parent();
        var sortbyText = self.text();
        var label = $('.filter-sortby .label-tab .label-text');

        if(!parent.hasClass('active')) {
          Shopify.queryParams.sort_by = $(this).attr('data-href');
          bicycle.sidebarAjaxClick();
          label.text(sortbyText);
        }

        sortbyFilter.not(self).parent().removeClass('active');
        self.parent().addClass('active');

        $('.filter-sortby .label-tab').removeClass('active').next('.dropdown-menu').hide();
      });

      if (Shopify.queryParams.sort_by) {
        var sortby = Shopify.queryParams.sort_by;
        var sortbyText = $(".filter-sortby span[data-href='" + sortby + "']").text();

        $('.filter-sortby .label-tab .label-text').text(sortbyText);
        $('.filter-sortby li.active').removeClass('active');
        $(".filter-sortby span[data-href='" + sortby + "']").parent().addClass("active");
      }

      else {
        var sortbyText = $('.filter-sortby .dropdown-menu .active').text();

        $('.filter-sortby .label-tab .label-text').text(sortbyText);
      }
    },

    sidebarAjaxClick: function(baseLink) {
      var tiler = $('head title').text();
      delete Shopify.queryParams.page;
      var newurl = bicycle.sidebarCreateUrl(baseLink);

      bicycle.isSidebarAjaxClick = true;

      History.pushState({
        param: Shopify.queryParams
      }, newurl, newurl);
      $('head title').text(tiler);
      bicycle.sidebarGetContent(newurl);

    },

    sidebarCreateUrl: function(baseLink) {
      var newQuery = $.param(Shopify.queryParams).replace(/%2B/g, '+');

      if (baseLink) {
        if (newQuery != "")
          return baseLink + "?" + newQuery;
        else
          return baseLink;
      }

      return location.pathname + "?" + newQuery;
    },

    sidebarInitToggle: function() {
      var sidebarLabelSlt = '.sidebar-label';
      var sidebarLabel = $(sidebarLabelSlt);
      $(sidebarLabelSlt).click(function(){
        $('.col-sidebar').toggleClass('open');
        $('html').toggleClass('open-sidebar');
        $('.wrap-overlay, .close-sidebar').click(function(){
          $('html').removeClass('open-sidebar'); 
          $('.col-sidebar').removeClass('open');
        });
      });

      var widgetTitleSlt = '.sidebar .widget-header';
      var widgetTitle = $(widgetTitleSlt);

      if(window.innerWidth < 992) {
        widgetTitle.addClass('open'); 
      }
      else {
        widgetTitle.removeClass('open'); 
      }

      body.off('click.slideToogle', widgetTitleSlt).on('click.slideToogle', widgetTitleSlt, function(e) {
        clearTimeout(bicycle.bicycleTimeout);

        bicycle.bicycleTimeout = setTimeout(function() {
          $('.widget-product .products-grid').slick('unslick');    
          $('.widget-product .products-grid').find('.slick-list').removeAttr('style');

          bicycle.initProductSidebarSlider();
        }, 50);

        $(this).toggleClass('open');
        $(this).next().slideToggle();
      });
    },
    
    sidebarCategoryInitToggle: function(){
    	var icon = $('.sidebar-links .icon-dropdown');
      icon.off('click').on('click', function(){
      	$(this).next().slideToggle();
        $(this).parent().toggleClass('expand');
      })
    },

    sidebarGetContent: function(newurl) {
      $.ajax({
        type: 'get',
        url: newurl,

        beforeSend: function() {
          bicycle.showLoading();
        },

        success: function(data) {

          bicycle.sidebarMapData(data);
          bicycle.translateBlock('.main-content');
          bicycle.initColorSwatchGrid();
          bicycle.sidebarMapTagEvents();
          bicycle.sidebarMapClear();
          bicycle.hideLoading();
          
          if($(".wishlist-btn").length > 0){
            bicycle.initWishList();
          }


          if(window.innerWidth < 992 && $('.col-sidebar .sidebar-label').is(':visible')) {
            $('.sidebar').removeClass('open').slideUp(600);
          }
          else {
            $('.sidebar').css({'display': ''});
          };
        },

        error: function(xhr, text) {
          bicycle.hideLoading();
          $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);
          bicycle.showModal('.ajax-error-modal');
        }
      });
    },

    sidebarMapData: function(data) {

      var currentList = $('.col-main .products-grid');

      if (currentList.length == 0) {
        currentList = $('.col-main .product-list');
      };

      var productList = $(data).find('.col-main .products-grid');

      if (productList.length == 0) {
        productList = $(data).find('.col-main .product-list');
      };

      if (productList.length > 0 && productList.hasClass('products-grid')) {
        //         bicycle.initResizeImage(productList.find('img'));
      };

      currentList.replaceWith(productList);

      //convert currency
      if (bicycle.checkNeedToConvertCurrency()) {
        Currency.convertAll(window.shop_currency, $('#currencies .active').attr('data-currency'), 'span.money', 'money_format');
      };

      //replace paging
      if ($('.toolbar .padding').length > 0) {
        $('.toolbar .padding').replaceWith($(data).find(".toolbar .padding"));
      }
      else {
        $(".toolbar-right").append($(data).find('.toolbar-right .padding'));
      };

      if ($('.collection-padding').length > 0) {
        $('.collection-padding').replaceWith($(data).find(".collection-padding"));
      }
      else {
        $(".collections-content-product").append($(data).find('.collection-padding'));
      };
      if ($('.template-search').length > 0) {
        $('.padding').replaceWith($(data).find(".padding"));
      }

      //replace refined
      $('.refined-widgets').replaceWith($(data).find('.refined-widgets'));

      //replace tags
      $('.sidebar-block').replaceWith($(data).find('.sidebar-block'));

      // breadcrumb
      $('.breadcrumb .bd-title').replaceWith($(data).find('.breadcrumb .bd-title'));

      $(".cat-content").replaceWith($(data).find(".cat-content"));

      $(".page-header h2").replaceWith($(data).find(".page-header h2"));

      $('head title').text(($(data).filter('title').text()));

      bicycle.initProductSidebarSlider();

      //product review
      if ($('.spr-badge').length > 0) {
        return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
      };
    },

    translateBlock: function(blockSelector) {
      if (window.multi_lang && translator.isLang2()) {
        translator.doTranslate(blockSelector);
      }
    },

    translateText: function(str) {
      if (!window.multi_lang || str.indexOf("|") < 0)
        return str;

      if (window.multi_lang) {
        var textArr = str.split("|");

        if (translator.isLang2())
          return textArr[1];
        return textArr[0];
      };
    },

    initProductMoreview: function() {
      var sliderFor = $('.product .slider-for'),
          sliderNav = $('.product .slider-nav');
      if ($('.product .product-img-box').hasClass('horizontal')) {
        var dataVertical = false;
      }
      else if ($('.product .product-img-box').hasClass('vertical')) {
        var dataVertical = true;
      };
      if($('.template-product .sidebar').length) {
        var dataRow = 4;
      }
      else {
        var dataRow= 5;
      };
      if (!sliderFor.hasClass('slick-initialized') && !sliderNav.hasClass('slick-initialized')) {
        sliderFor.slick({
          slidesToShow: 1,
          slidesToScroll: 1,
          arrows: false,
          fade: true,
          verticalSwiping: false,
          asNavFor: sliderNav
        });

        sliderNav.slick({
          infinite: true,
          slidesToShow: dataRow,
          slidesToScroll: 1,
          vertical: dataVertical,
          asNavFor: sliderFor,
          verticalSwiping: false,
          dots: false,
          focusOnSelect: true,
          nextArrow: '<button type="button" class="slick-next"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 17 33" xml:space="preserve"><g id="e4eb89a6-f885-43b8-9259-0d6b1516fab0"><g id="_x38_e584754-6657-46f1-a9d8-2cfd6623b552"><g><polygon points="14.9,14.5 0,0 0,3.7 11.1,14.5 13.2,16.5 11.1,18.5 0,29.3 0,33 14.9,18.5 17,16.5 "/></g></g></g></svg></button>',
          prevArrow: '<button type="button" class="slick-prev"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 33"><g id="7f9a1925-e8c7-4614-8787-3c6095a9f6e1" data-name="Layer 2"><g id="c9b7920a-81fa-4bfe-ad13-4da717c6854b" data-name="Layer 1"><g id="c2d982ff-0cf6-4220-b365-47f30d708fea" data-name="e4eb89a6-f885-43b8-9259-0d6b1516fab0"><g id="f51d455e-6b9c-4c4e-96db-a5004582beda" data-name="8e584754-6657-46f1-a9d8-2cfd6623b552"><polygon points="0 16.5 2.1 18.5 17 33 17 29.3 5.9 18.5 3.8 16.5 5.9 14.5 17 3.7 17 0 2.1 14.5 0 16.5"/></g></g></g></g></svg></button>',
          responsive: [
            {
              breakpoint: 1200,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 1
              }
            },
            {

              breakpoint: 768,
              settings: {
                vertical: false,
                slidesToShow:4,
                dots: true,
                arrows:false,
                slidesToScroll: 1
              }
            },

            {
              breakpoint: 480,
              settings: {
                vertical: false,
                slidesToShow: 3,
                slidesToScroll: 1,
                dots: true,
              }
            }
          ]
        });
      };
    },

    initRelatedProductSlider: function() {
      var templatePro = $('.template-product');
      var sidebar = templatePro.find('.sidebar');
      if(sidebar.length) {
        var sidebarRow = 4 ;
      }
      else {
        var sidebarRow = 5;
      };
      var relatedProduct = $('.related-products');
      var productGrid = relatedProduct.find('.products-grid');
      if(relatedProduct.length) {
        productGrid.slick({
          infinite: false,
          speed: 500,
          slidesToShow: sidebarRow,
          slidesToScroll: 1,
          dots: false,
          nextArrow: '<button type="button" class="slick-next"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 17 33" xml:space="preserve"><g id="e4eb89a6-f885-43b8-9259-0d6b1516fab0"><g id="_x38_e584754-6657-46f1-a9d8-2cfd6623b552"><g><polygon points="14.9,14.5 0,0 0,3.7 11.1,14.5 13.2,16.5 11.1,18.5 0,29.3 0,33 14.9,18.5 17,16.5 "/></g></g></g></svg></button>',
          prevArrow: '<button type="button" class="slick-prev"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 33"><g id="7f9a1925-e8c7-4614-8787-3c6095a9f6e1" data-name="Layer 2"><g id="c9b7920a-81fa-4bfe-ad13-4da717c6854b" data-name="Layer 1"><g id="c2d982ff-0cf6-4220-b365-47f30d708fea" data-name="e4eb89a6-f885-43b8-9259-0d6b1516fab0"><g id="f51d455e-6b9c-4c4e-96db-a5004582beda" data-name="8e584754-6657-46f1-a9d8-2cfd6623b552"><polygon points="0 16.5 2.1 18.5 17 33 17 29.3 5.9 18.5 3.8 16.5 5.9 14.5 17 3.7 17 0 2.1 14.5 0 16.5"/></g></g></g></g></svg></button>',
          responsive: [
            {
              breakpoint: 1200,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 1
              }
            },
            {
              breakpoint: 1025,
              settings: {
                slidesToShow: 4,
                slidesToScroll: 1
              }
            },
            {
              breakpoint: 992,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 1
              }
            },
            {
              breakpoint: 768,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                dots: true,
                arrows: false
              }
            },

            {
              breakpoint: 370,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: true,
                arrows: false
              }
            }
          ]
        });
      };
    },

    initZoom: function() {
      if ($(window).width() >= 1025 ) {
        $('.product-photo-container .fancybox').zoom();
      }
      else {    
        $('.product-photo-container .fancybox').trigger('zoom.destroy');
      }                     
    },

    initToDay: function() {
      $(document).on('click', '.add-to-day', function(e) {
        e.preventDefault();
        if($(this).attr('disabled') != 'disabled') {
          var productTD = $('.todays-deal').attr('id');
          productTD = productTD.match(/\d+/g);
          if(!window.ajax_cart) {
            $(this).closest('form').submit();
          }

          else {
            var variant_id = $('#td-' + productTD + '  select[name=id]').val();

            if(!variant_id) {
              variant_id = $('#td-' + productTD + ' input[name=id]').val();
            }

            var quantity = $('#td-' + productTD + ' form input[name=quantity]').val();

            if(!quantity) {
              quantity = 1;
            }

            var title = $('.todays-deal .product-title').html();

            var vendor = $(this).closest('form').data('vendor');

            var image = $('.todays-deal .pro-img-home .item-img img').attr('src');

            bicycle.doAjaxAddToCart(variant_id, quantity, title, vendor, image);
          }
        }
        return false;
      }); 
    },

    initAddToCart: function() {
      if ($('.add-to-cart-btn').length > 0) {
        $(document).on('click', '.add-to-cart-btn', function(e) {
          e.preventDefault();
          var self = $(this),
              data = self.closest('form').serialize();
          if ($(this).attr('disabled') != 'disabled') {
            var productItem = $(this).parents('.product-item');
            var productId = $(productItem).attr('id');          
            var handle = $(productItem).find('.product-grid-image').data('handle');
            productId = productId.match(/\d+/g);
            if (!window.ajax_cart) {
              $(this).closest('form').submit();
            } 
            else {
//               var variant_id = $('#product-actions-' + productId + ' select[name=id]').val();
//               if (!variant_id) {
//                 variant_id = $('#product-actions-' + productId + ' input[name=id]').val();
//               }
//               var quantity = $('#product-actions-' + productId + ' input[name=quantity]').val();

//               if (!quantity) {
//                 quantity = 1;
//               }

              var title = $(productItem).find('.product-title').html();
              var vendor = $(this).closest('form').data('vendor');
              var image = $(productItem).find('.product-grid-image img').attr('src');
              bicycle.doAjaxAddToCart(data, title, vendor, image);
            }
          }

          return false;

        });              

      }
    },

    initProductAddToCart: function() {
      var btnAddToCartSlt = '#product-add-to-cart';
      var btnAddToCart = $(btnAddToCartSlt);

      if(btnAddToCart.length) {
        body.off('click.addToCartProduct', btnAddToCartSlt).on('click.addToCartProduct', btnAddToCartSlt, function(e) {
          e.preventDefault();
          e.stopPropagation();
          
          var self = $(this),
              data = self.closest('form').serialize();

          if($(this).attr('disabled') != 'disabled') {
            if(!window.ajax_cart) {
              $(this).closest('form').submit();
            }

            else {
//               var variant_id = $('#add-to-cart-form select[name=id]').val();

//               if(!variant_id) {
//                 variant_id = $('#add-to-cart-form input[name=id]').val();
//               }

//               var quantity = $('#add-to-cart-form input[name=quantity]').val();

//               if(!quantity) {
//                 quantity = 1;
//               }

              var title = $('.product-title h2').html();

              var vendor = $(this).closest('form').data('vendor');

              var image = $('.slick-current img[id|="product-featured-image"]').attr('src') || $('.product img[id|="product-featured-image"]').attr('src');

              bicycle.doAjaxAddToCart(data, title, vendor, image);
            }
          }

          return false;

        });
      }
    },

    doAjaxAddToCart: function(data, title, vendor, image) {
      $.ajax({
        type: "post",
        url: "/cart/add.js",
        data: data,
        dataType: 'json',

        beforeSend: function() {
          bicycle.showLoading();
        },

        success: function(msg) {
          bicycle.hideLoading();
          $('.ajax-success-modal').find('.ajax-product-title').html(bicycle.translateText(title));
          $('.ajax-success-modal').find('.ajax-product-image').attr('src', image);
          $('.ajax-success-modal').find('.message-added-cart').show();
          bicycle.showModal('.ajax-success-modal');
          bicycle.updateDropdownCart();
        },

        error: function(xhr, text) {
          bicycle.hideLoading();

          $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);

          bicycle.showModal('.ajax-error-modal');
        }
      });
    },

    updateDropdownCart: function() {
      Shopify.getCart(function(cart) {
        bicycle.doUpdateDropdownCart(cart);
      });
    },

    doUpdateDropdownCart: function(cart) {
      var template = '<li class="item" id="cart-item-{ID}"><a href="{URL}" title="{TITLE}" class="product-image"><img src="{IMAGE}" alt="{TITLE}"></a><div class="product-details"><a href="javascript:void(0)" title="Remove This Item" class="btn-remove"><svg class="icon-close" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="357px" height="357px" viewBox="0 0 357 357" style="enable-background:new 0 0 357 357;" xml:space="preserve"><g><g><polygon points="357,35.7 321.3,0 178.5,142.8 35.7,0 0,35.7 142.8,178.5 0,321.3 35.7,357 178.5,214.2 321.3,357 357,321.3 214.2,178.5"></polygon></g></g></svg></a><p class="product-name"><a href="{URL}">{TITLE}</a></p><div class="cart-collateral"><span class="qtt">{QUANTITY} X</span><span class="price">{PRICE}</span></div></div></li>';

      $('.cartCount').text(cart.item_count);

      dropdownCart.find('.summary .price').html(Shopify.formatMoney(cart.total_price, window.money_format));

      miniProductList.html('');

      if (cart.item_count > 0) {
        for (var i = 0; i < cart.items.length; i++) {
          var item = template;

          item = item.replace(/\{ID\}/g, cart.items[i].id);
          item = item.replace(/\{URL\}/g, cart.items[i].url);
          item = item.replace(/\{TITLE\}/g, bicycle.translateText(cart.items[i].product_title));
          item = item.replace(/\{QUANTITY\}/g, cart.items[i].quantity);
          item = item.replace(/\{IMAGE\}/g, Shopify.resizeImage(cart.items[i].image, '64x'));
          item = item.replace(/\{PRICE\}/g, Shopify.formatMoney(cart.items[i].price, window.money_format));

          miniProductList.append(item);
        }

        bicycle.removeItemDropdownCart(cart);

        if (bicycle.checkNeedToConvertCurrency()) {
          Currency.convertAll(window.shop_currency, $('#currencies .active').attr('data-currency'), 'span.money', 'money_format');
        }
      }

      bicycle.checkItemsInDropdownCart();
    },

    removeItemDropdownCart: function(cart) {
      var btnRemove = dropdownCart.find('.btn-remove');

      btnRemove.off('click.removeCartItem').on('click.removeCartItem', function(e) {
        e.preventDefault();
        e.stopPropagation();

        var productId = $(this).parents('.item').attr('id');
        productId = productId.match(/\d+/g);

        Shopify.removeItem(productId, function(cart) {
          bicycle.doUpdateDropdownCart(cart);
        });
      });
    },

    checkItemsInDropdownCart: function() {
      if(miniProductList.children().length) {
        cartHasItems.show();
        cartNoItems.hide();
      }
      else {
        cartHasItems.hide();
        cartNoItems.show();
      }
    },

    initCartQty: function() {
      var button = $('.cart-list .quantity .button');

      button.off('click.changeQuantity').on('click.changeQuantity', function(e) {
        e.preventDefault();
        e.stopPropagation();

        var oldValue = $(this).siblings('input.qty').val(),
            newVal = 1;

        if($(this).hasClass('inc')) {
          newVal = parseInt(oldValue) + 1;
        }
        else if(oldValue > 1) {
          newVal = parseInt(oldValue) - 1;
        }

        $(this).siblings('input.qty').val(newVal);
      });
    },

    initQuickView: function() {
      var selectCallbackQuickview = function(variant, selector) {
        var productItem = $('.quick-view .product-item'),
            btnAddToCart = productItem.find('.add-to-cart-btn'),
            productPrice = productItem.find('.price'),
            comparePrice = productItem.find('.compare-price'),
            totalPrice = productItem.find('.total-price .total-money'),
            priceSaving = productItem.find('.price-saving .price-save');

        if(variant) {
          if(variant.available) {
            btnAddToCart.removeClass('disabled').removeAttr('disabled').text(window.inventory_text.add_to_cart);
          }
          else {
            btnAddToCart.addClass('disabled').attr('disabled', 'disabled').text(window.inventory_text.sold_out);
          };

          $('.quick-view #product_regular_price').val(variant.price);
          productPrice.html(Shopify.formatMoney(variant.price, window.money_format));
          if(variant.compare_at_price > variant.price) {
            comparePrice.html(Shopify.formatMoney(variant.compare_at_price, window.money_format)).show();
            productPrice.addClass('on-sale');
            var roundqv = Math.floor((1- ( variant.price/variant.compare_at_price))*100);
            priceSaving.html('-'+roundqv+"%");
            priceSaving.show();
          }
          else {
            comparePrice.hide();
            productPrice.removeClass('on-sale');
            priceSaving.hide();
          };

          if (window.use_color_swatch) {
            var form = $('#' + selector.domIdPrefix).closest('form');
            for (var i=0,length=variant.options.length; i<length; i++) {
              var radioButton = form.find('.swatch[data-option-index="' + i + '"] :radio[value="' + variant.options[i] +'"]');
              if (radioButton.size()) {
                radioButton.get(0).checked = true;
              }
            }
          };

          if(window.display_quickview_availability) {
            var inventoryInfo = productItem.find('.product-inventory span');

            if (variant.available) {
              if (variant.inventory_management != null) {
                inventoryInfo.text(window.inventory_text.in_stock);
              }
              else {
                inventoryInfo.text(window.inventory_text.many_in_stock);
              }
            }
            else {
              inventoryInfo.text(window.inventory_text.out_of_stock);
            }
          };

          if(window.display_quickview_sku) {
            var sku = productItem.find('.sku-product span');
            if(variant) {
              sku.text(variant.sku);
            }
            else {
              sku.empty();
            };
          };

          bicycle.updatePricingQuickview();

          if (variant && variant.featured_image) {
            var originalImage = $('.quick-view .quickview-featured-image img');
            var newImage = variant.featured_image;
            var element = originalImage[0];
            Shopify.Image.switchImage(newImage, element, function (newImageSizedSrc, newImage, element) {
              newImageSizedSrc = newImageSizedSrc.replace(/\?(.*)/,"");
              $('.quick-view .slider-nav img').each(function() {
                var grandSize = $(this).attr('src');
                grandSize = grandSize.replace('70x70','1024x1024');
                grandSize = grandSize.split('?')[0];
                newImageSizedSrc = newImageSizedSrc.split('?')[0];
                if (grandSize == newImageSizedSrc) {
                  $(this).parent().trigger('click'); 
                  return false;
                };
              });
            });        
          };
        }

        else {
          btnAddToCart.text(window.inventory_text.unavailable).addClass('disabled').attr('disabled', 'disabled');
        };
      }
      var qvButton = '.quickview-button a',
          quickview = $('#quickview-template');
      body.off('click.initQuickView', qvButton).on('click.initQuickView', qvButton, function(e) {
        e.preventDefault();
        e.stopPropagation();

        var productUrl = $(this).attr('data-href'),
            dataUrl = productUrl + '?view=quickview',
            product_handle = $(this).attr('id');;

        $.ajax({
          	type: "get",
            url: window.router + '/products/' + product_handle + '?view=quickview',
            success: function(data) {

              quickview.find('.content').html($(data));

              Shopify.getProduct(product_handle, function(product) {
                // ------------swatch
                if(product.available && product.variants.length > 1){

                  new Shopify.OptionSelectors("product-select-" + product.id, {
                    product: product,
                    onVariantSelected: selectCallbackQuickview
                  });

                  if (window.use_color_swatch) {

                    changeSwatch(quickview.find('.swatch :radio'));
                    Shopify.linkOptionSelectors(product, '#quickview-template');
                  }
                  quickview.find('form.variants .selector-wrapper label').each(function(i,v) {
                    $(this).html('<span class="required">*</span>' + product.options[i].name);
                  });


                }

                bicycle.translateBlock('#quickview-template');   
                quickview.fadeIn(500);  
                bicycle.intslick();
                bicycle.initQuickviewAddToCart();
                bicycle.initZoom();
                //quantity
                if(quickview.find('.qty-group').length > 0){
                  quickview.find('.button').off('click.changeQtt').on('click.changeQtt', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    var oldValue = quickview.find(".quantity").val(),
                        newVal = 1;
                    if($(this).hasClass('inc')) {
                      newVal = parseInt(oldValue) + 1;
                    }
                    else if(oldValue > 1) {
                      newVal = parseInt(oldValue) - 1;
                    }
                    quickview.find('.quantity').val(newVal);
                    bicycle.updatePricingQuickview();
                  });
                }


                if (bicycle.checkNeedToConvertCurrency()) {
                  Currency.convertAll(window.shop_currency, $('#currencies .active').attr('data-currency'), 'span.money', 'money_format');
                };

              });
            },
            error: function() {
              $('#notification-bar').text('An error occurred');
            }
          }
        );
      });
      
      doc.off('click.closeQuickView').on('click.closeQuickView', '.quick-view .overlay, .close-window', function() {
        bicycle.closeQuickViewPopup();
        return false;
      });
    },

    updatePricingQuickview: function() {


      var quantity = parseInt($('.quick-view input[name=quantity]').val());
      var p = $('.quick-view #product_regular_price').val();
      var totalPrice1 = p * quantity;
      var g = Shopify.formatMoney(totalPrice1, window.money_format);
      $('.quick-view .total-price span').html(g);

      if (bicycle.checkNeedToConvertCurrency()) {
        Currency.convertAll(window.shop_currency, $('#currencies .active').attr('data-currency'), 'span.money', 'money_format');
      };
      
      // var regex = /([0-9]+[.|,][0-9]+[.|,][0-9]+)/g;
      // var unitPriceTextMatch = $('.quick-view .price').text().match(regex);

      // if (!unitPriceTextMatch) {
      //   regex = /([0-9]+[.|,][0-9]+)/g;
      //   unitPriceTextMatch = $('.quick-view .price').text().match(regex);
      // }

      // if (unitPriceTextMatch) {
      //   var unitPriceText = unitPriceTextMatch[0];
      //   var unitPrice = unitPriceText.replace(/[.|,]/g, '');
      //   var quantity = parseInt($('.quick-view input[name=quantity]').val());
      //   var totalPrice = unitPrice * quantity;

      //   var totalPriceText = Shopify.formatMoney(totalPrice, window.money_format);
      //   regex = /([0-9]+[.|,][0-9]+[.|,][0-9]+)/g;     
      //   if (!totalPriceText.match(regex)) {
      //     regex = /([0-9]+[.|,][0-9]+)/g;
      //   } 
      //   totalPriceText = totalPriceText.match(regex)[0];

      //   var regInput = new RegExp(unitPriceText, "g");
      //   var totalPriceHtml = $('.quick-view .price').html().replace(regInput, totalPriceText);
      //   $('.quick-view .total-price span').html(totalPriceHtml);
      //   $('.quick-view .total-price .total-money').html(totalPriceHtml);
      // };       
    },

    intslick:  function() {
      var sliderForqv = $('.quick-view .slider-for'),
          sliderNavqv =  $('.quick-view .slider-nav');
      if (!sliderForqv.hasClass('slick-initialized') && !sliderNavqv.hasClass('slick-initialized')) {
        sliderForqv.slick({
          slidesToShow: 1,
          slidesToScroll: 1,
          arrows: false,
          fade: true,
          verticalSwiping: false,
          asNavFor: sliderNavqv
        });

        sliderNavqv.slick({
          infinite: true,
          slidesToShow: 4,
          slidesToScroll: 1,
          asNavFor: sliderForqv,
          verticalSwiping: false,
          dots: false,
          focusOnSelect: true,
          nextArrow: '<button type="button" class="slick-next"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 17 33" xml:space="preserve"><g id="e4eb89a6-f885-43b8-9259-0d6b1516fab0"><g id="_x38_e584754-6657-46f1-a9d8-2cfd6623b552"><g><polygon points="14.9,14.5 0,0 0,3.7 11.1,14.5 13.2,16.5 11.1,18.5 0,29.3 0,33 14.9,18.5 17,16.5 "/></g></g></g></svg></button>',
          prevArrow: '<button type="button" class="slick-prev"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 33"><g id="7f9a1925-e8c7-4614-8787-3c6095a9f6e1" data-name="Layer 2"><g id="c9b7920a-81fa-4bfe-ad13-4da717c6854b" data-name="Layer 1"><g id="c2d982ff-0cf6-4220-b365-47f30d708fea" data-name="e4eb89a6-f885-43b8-9259-0d6b1516fab0"><g id="f51d455e-6b9c-4c4e-96db-a5004582beda" data-name="8e584754-6657-46f1-a9d8-2cfd6623b552"><polygon points="0 16.5 2.1 18.5 17 33 17 29.3 5.9 18.5 3.8 16.5 5.9 14.5 17 3.7 17 0 2.1 14.5 0 16.5"/></g></g></g></g></svg></button>',

        });
      };
    },

    initQuickviewAddToCart: function() {
      if ($('.quick-view .add-to-cart-btn').length) {
        $('.quick-view .add-to-cart-btn').off('click.quickViewAddToCart').on('click.quickViewAddToCart', function(e) {
          e.preventDefault();
          e.stopPropagation();

          var self = $(this),
              data = self.closest('form').serialize();
	
          if(!window.ajax_cart) {
            $(this).closest('form').submit();
          } else{


//             var variant_id = $('.quick-view select[name=id]').val();

//             if (!variant_id) {
//               variant_id = $('.quick-view input[name=id]').val();
//             };

//             var quantity = $('.quick-view input[name=quantity]').val();
//             if (!quantity) {
//               quantity = 1;
//             };

            var title = $('.quick-view .product-title a').html();
            var image = $('.quick-view .quickview-featured-image .slick-current img').attr('src') || $('.quick-view .quickview-featured-image img').attr('src');
            var vendor = $('.quick-view form.variants').data('vendor');

            bicycle.doAjaxAddToCart(data, title, vendor, image);
            bicycle.closeQuickViewPopup();
          }
        });
      };
    },

    closeQuickViewPopup: function() {
      $('.quick-view').fadeOut(500);
    },

    initDropdownFooterMenu: function() {
      var footerTitle = $('.footer-top .foot-title');

      if(window.innerWidth < 768) {
        if(footerTitle.length) {
          footerTitle.off('click.slideToggle').on('click.slideToggle', function() {
            $(this).toggleClass('show');
            $(this).next().slideToggle();
          });
        }
      }
      else {
        $('.footer-top .foot-title ~ ul').css({"display": ""});
      }
    },

    initWishListPage :function(){

      var ListWishList = $('.wishlist-content'),
          itemsArray = localStorage.getItem('items') ? JSON.parse(localStorage.getItem('items')) : [];
      var currentpage = 1;
      var pagecount = 0;

      // Load product in wishlist function and set pagination
      var dataWishlist = function(ProductHandle) {
        jQuery.getJSON(window.router + '/products/'+ProductHandle+'.js', function(product) {
          var productHTML = '';
          var price_min = Shopify.formatMoney(product.price_min, window.money_format);

          productHTML += '<div class="grid-item"  data-product-handle="'+product.handle+'" data-id="'+ product.id +'">';
          productHTML += '<div class="row2">';
          productHTML += '<div class="product-image col-md-2"><a href="'+product.url +'"><image src="'+product.featured_image +'" /></a></div>';
          productHTML += '<div class="product-bottom col-md-4">';
          productHTML += '<a class="product-title" href="'+product.url +'">'+product.title+'</a>';
          productHTML += '</div>';
          productHTML += '<div class="price-box col-md-2">'+ price_min +'</div>';
          productHTML += '<div class="btn-remove col-md-2"><a class="btn-active btn-remove-wishlist" href="#" data-id="'+ product.id +'"><svg class="closemnu" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="357px" height="357px" viewBox="0 0 357 357" style="enable-background:new 0 0 357 357;" xml:space="preserve"><g><g><polygon points="357,35.7 321.3,0 178.5,142.8 35.7,0 0,35.7 142.8,178.5 0,321.3 35.7,357 178.5,214.2 321.3,357 357,321.3 214.2,178.5"></polygon></g></g></svg></a></div>';
          productHTML += '<div class="col-md-2 wishlist-action"><form action="/cart/add" method="post" class="variants" enctype="multipart/form-data">';
          productHTML += '<input type="hidden" name="id" value="'+ product.variants[0].id +'" />  ';

          if (product.available) {
            if (product.variants.length == 1) {
              productHTML += '<input class="btn add-to-cart-btn1" type="submit" value="'+window.inventory_text.add_to_cart+'"/>'; 
            } 
            if (product.variants.length > 1){
              productHTML += '<a class="btn add-to-cart-btn1" href="'+product.url +'">'+window.inventory_text.select_options+'</a>';
            }
          } else {
            productHTML += '<input class="btn add-to-cart-btn1" disabled="disabled" type="submit" value="'+window.inventory_text.unavailable+'"/>';
          }
          productHTML += '</form></div>';


          productHTML += '</div></div>';
          productHTML.textContent = product; 
          ListWishList.append(productHTML).html();

          var regex = /(<([^>]+)>)/ig;
          var href = $('.wishlist-page a.share').attr("href");
          href += encodeURIComponent( product.title + '\nPrice: ' + price_min.replace(regex, "") + '\nLink: ' + window.location.protocol + '//' + window.location.hostname + product.url +'\n\n');
          $('.wishlist-page a.share').attr("href", href );




        });
      };

      // Display wishlist item per page
      function showpage(page) {
        $('.wishlist-page .grid-item').hide();
        $('.wishlist-page .grid-item').eq((page-1)*3).show().next().show().next().show();
        $('#pagin').find('a').removeClass('current').eq(page).addClass('current');
      }

      // Display pagination bar
      function showPaginationBar(){
        var pagecount = Math.floor(($('.wishlist-page .grid-item').size()) / 3);
        if (($('.wishlist-page .grid-item').size()) % 3 > 0) {
          pagecount++;
        }

        $('.wishlist-page #pagin').html('<li><a>previous</a></li>');
        if(pagecount > 1){
          for (var i = 1; i <= pagecount; i++) {
            if(i == currentpage){
            $('#pagin').append('<li><a class="current">' + i + '</a></li>');
            }else{
            $('#pagin').append('<li><a>' + i + '</a></li>');
            }
          }

          $('.wishlist-page #pagin').append('<li><a>next</a></li>');
          $('#pagin').show();
        }
        else
        {
          $('#pagin').hide();
        }

        $(".wishlist-page #pagin").on("click", "a", function(event){

          event.preventDefault();

          if($(this).html() == "next") {
            currentpage++;
          }
          else if($(this).html() == "previous") {
            currentpage--;
          }
          else {
            currentpage = $(this).html();
          }

          if(currentpage < 1) {currentpage = 1;}

          if(currentpage > pagecount) {currentpage = pagecount;}
          showpage(currentpage);
        });
      };        
      // Call load product function to load product frome localStorage
      itemsArray.forEach(function(item) {
        dataWishlist(item);
      });

      // product load completed
      $(document).ajaxStop(function() {
        showPaginationBar();
        showpage(1);
        bicycle.translateBlock(".wishlist-page");      
        // Removed item function
        $('.wishlist-content .grid-item .btn-remove-wishlist').click(function(e){
     
          var thisItem = $(this).parents('.grid-item');
          e.preventDefault();
          var itemIndex = thisItem.index();

         
          if(itemIndex % 3 == 0 && itemIndex == $('.wishlist-content .grid-item').length - 1){
            var newpage = currentpage - 1;
            currentpage = newpage;
          }else{
            var newpage = currentpage;

          }
          
          
          thisItem.remove();
           showpage(newpage);  
           showPaginationBar();
          bicycle.removeFromWishlist($(this))

        })
      });
    },
    addToWishlist : function (self) {
      var itemsArray = localStorage.getItem('items') ? JSON.parse(localStorage.getItem('items')) : [];
        var ProductHandle = self.attr('data-product-handle');

          itemsArray.push(ProductHandle);

          //remove duplicate items
          var uniqueItems = [];
          $.each(itemsArray, function(i, el){
            if($.inArray(el, uniqueItems) === -1) uniqueItems.push(el);
          });
          itemsArray = uniqueItems;

          localStorage.setItem('items', JSON.stringify(itemsArray));


      },
    removeFromWishlist : function(self){
      var itemsArray = localStorage.getItem('items') ? JSON.parse(localStorage.getItem('items')) : [];
      var ProductHandle = self.attr('data-product-handle'),
          removeIndex = itemsArray.indexOf(ProductHandle);
      itemsArray.splice(removeIndex, 1);
      localStorage.setItem('items', JSON.stringify(itemsArray));
    },
    initWishList : function(e){   
      var button = $('.wishlist-btn'),
          itemsArray = localStorage.getItem('items') ? JSON.parse(localStorage.getItem('items')) : [];


      $(document).off('click.wishlistClick','.wishlist-btn:not(.btn-active)').on('click.wishlistClick', '.wishlist-btn:not(.btn-active)', function(e){

        e.preventDefault();
        $(this).addClass('btn-active');
        $(this).find(".wishlist_text").text(window.inventory_text.remove_wishlist);
        bicycle.addToWishlist($(this));
      }); 

      $(document).on('click', '.btn-active', function(e){
        $(this).find(".wishlist_text").text(window.inventory_text.add_wishlist);
        e.preventDefault();	
		bicycle.removeFromWishlist($(this));
        $(this).removeClass('btn-active');

      }); 
	// active added products
      
      itemsArray.forEach(function (item) {
		var activeButton = $('.addwishlist .wishlist-btn[data-product-handle="'+item+'"]')
  
          activeButton.addClass('btn-active');
          activeButton.find('.wishlist_text').text(window.inventory_text.remove_wishlist);
       
      });

    },

    Page_brands: function(){
      $(".brands-list .brand").each(function(){
        var chi = $(this).find(".azbrands-title h3").text().trim();
        var ch = $(this).find("ul.brandgrid li:eq(0)").text().charAt(0);
        $('.azbrandstable').children().each(function(){
          if( $(this).find('a').text().trim() == chi){
            if( !$(this).find('a').hasClass('readonly') )
              $(this).find('a').addClass('readonly');
            return;
          }
        });
        if($(this).find(".azbrands-title").length == 0){
          $(this).find("ul.brandgrid").children().appendTo('.brand-' + ch + " ul.brandgrid");
          $(this).remove();
        }
      });

      $('.azbrandstable .vendor-letter a.readonly').click(function(){
        var v = $(this).text();
        $('.brands-list .brand').hide().filter(function(e){
          var n =  $(this).find('h3').text();
          return n == v;
        }).show();
        $('.azbrandstable .all-brand a').click(function(){
          $(".brands-list .brand").show();
        });
      });
      $('.azbrandstable a.readonly').click(function(){
        $('.azbrandstable a').removeClass('active');
        var $this = $(this);
        if (!$this.hasClass('active')) {
          $this.addClass('active');
        }
        var topbrand = $('.wrapper-header').outerHeight();
        $('html, body').animate({scrollTop: topbrand}, 400);
      });

    },

    initEventPopupNextPrevProduct: function() {
      var nextPrevBlock = $('.next-prev-product');
      var iconNextPrev = nextPrevBlock.find('.popup-pro');
      var currentEl;
      if(iconNextPrev.length && iconNextPrev.is(':visible')) {
        if(!('ontouchstart' in document)) {
          iconNextPrev.hover(function() {            
            $(this).find('.modal-pro').toggle();                                      
          });

          iconNextPrev.mouseleave(function() {
            if ($(this).find('.modal-pro').is(':visible')) {
              $(this).find('.modal-pro').hide();
            };
          });
        }
        else {
          iconNextPrev.off('click').on('click', function(e) {
            if (currentEl != this) {
            e.preventDefault();
            e.stopPropagation();
              currentEl = this;
            }
            var modalSibling = $(this).siblings('.popup-pro').find('.modal-pro');

            if(modalSibling.is(':visible')) {
              modalSibling.hide();
            }

            $(this).find('.modal-pro').toggle();  
          });

          $(document).on('click', function(e) {
            if(!$(e.target).closest('.modal-pro').length && iconNextPrev.children('.modal-pro').is(':visible')) {
              iconNextPrev.children('.modal-pro').hide();
            }
          });
        };      	
      }
    },

    initStickyAddtoCart: function(){

      var p = $('#product-selectors option:selected').val();
      var t = $('.sticky_form .pr-swatch[data-value="'+p+'"]').text();
      $('.pr-selectors .pr-active').text(t);
      $('.sticky_form .pr-swatch[data-value="'+p+'"]').addClass('active');


      $( ".swatch .swatch-element" ).each(function(e) {
        var dav = $(this).data("value");
        $('.swatch input.text[data-value="'+dav+'"]').appendTo($(this))
      });


      $( ".selector-wrapper" ).change(function() {
        var n =$("#product-selectors").val();
        $( ".sticky_form .pr-selectors li" ).each(function( e ) {
          var t =$(this).find('a').data('value');
          if(t == n){
            $(this).find('a').addClass('active')
          } else{
            $(this).find('a').removeClass('active')
          }
        });
        $( "#product-selectors" ).change(function() {
          var str = "";
          $( "#product-selectors option:selected" ).each(function() {
            str += $( this ).data('imge');
          });
          $('.sticky_form .pr-img img').attr("src",str );
        }).trigger( "change" );

        if($('.sticky_form .pr-swatch').hasClass('active')){
          var h = $('.sticky_form .pr-swatch.active').text();
          $('.sticky_form .action input[type=hidden]').val(n);
          $('.sticky_form .pr-active').text(h);
          $('.sticky_form .pr-active').attr('data-value', n);
        }

      });

      $(document).click(function(e){
        var container = $(".sticky_form .pr-active");
        if (!container.is(e.target) && container.has(e.target).length === 0){
          $('.sticky_form').removeClass('open-sticky');
        }
      });

      $('.sticky_form .pr-active').on('click', function(){
        $('.sticky_form').toggleClass('open-sticky');
      });

      $('.sticky_form .pr-swatch').on('click', function(e){        
        $('.sticky_form .pr-swatch').removeClass('active');
        $(this).addClass('active');


        $('.sticky_form').toggleClass('open-sticky');


        var text = $(this).text(),
            value = $(this).data('value');

        $('.sticky_form .action input[type=hidden]').val(value);
        $('.sticky_form .pr-active').attr('data-value', value);
        $('.sticky_form .pr-active').text(text);
        $( '.swatch input.text[data-v="'+value+'"]' ).parent().find('.tric').click();

        if($(this).hasClass('sold-out')){
          $('.sticky-add-to-cart').val(window.inventory_text.sold_out).addClass('disabled').attr('disabled', 'disabled');
        }
        else{
          $('.sticky-add-to-cart').removeClass('disabled').removeAttr('disabled').val(window.inventory_text.add_to_cart);
        }

        var newImage = $(this).data('img');
        $('.pr-img img').attr({ src: newImage }); 
        return false;

      });

      $(document).on('click', '.sticky-add-to-cart', function(event) {
        event.preventDefault();
        if ($('#grouped-add-to-cart').length){
          $('#grouped-add-to-cart').click();
        }else{
          $('#product-add-to-cart').click();
        }
        return false;
      });

      var height = $('.product').outerHeight();

      $(window).scroll(function () {
        var scrollTop = $(this).scrollTop();
        if (scrollTop > height) {
          $('body').addClass('show_sticky');
        }
        else {
          $('body').removeClass('show_sticky');
        }
      });    
    },
    productRecomendation: function() {
      var $container = $('.js-product-recomendation');
      var productId = $container.data('productId');
      var template = $container.data('template');
      var sectionId = $container.data('sectionId');
      var limit = $container.data('limit');
      var productRecommendationsUrlAndContainerClass =
          window.router + '/recommendations/products?&section_id='+ sectionId +'&limit=' + limit + '&product_id=' + productId + ' .product-recommendations';
      $container.parent().load(productRecommendationsUrlAndContainerClass, function(){
        bicycle.translateBlock('#product-recommendations');
        bicycle.initRelatedProductSlider();
        if (bicycle.checkNeedToConvertCurrency()) {
          Currency.convertAll(window.shop_currency, jQuery('.currencies').val(), '.col-main span.money', 'money_format');
        }
      } );
      
    },
    checkbox_checkout: function(){
      var inputWrapper = $('.checkbox-group label');  

      var checkBox = $('.checkbox-group input[type="checkbox"]');

      setTimeout(function(){
        checkBox.each(function(){
          if ($(this).is(':checked')) {
            $(this).parent().parent().find('.btn-checkout').removeClass('show');
          } else {
            $(this).parent().parent().find('.btn-checkout').addClass('show');
          }
        });
      },300);

      inputWrapper.off('click').on('click', function (e) {
        var inputTrigger= $(this).parent().find('.conditions'),
            divAddClassbtn = $(this).parent().parent().find('.btn-checkout');

        if (!inputTrigger.is(':checked')) {
          divAddClassbtn.removeClass('show');
          inputTrigger.prop('checked', true);
        } else {
          divAddClassbtn.addClass('show');
          inputTrigger.prop('checked', false);
        }

      });
    }

  };
})(jQuery);