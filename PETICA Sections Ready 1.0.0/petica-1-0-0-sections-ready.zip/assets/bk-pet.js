(function($) {

  // General Element
  var doc         = $(document),
      body        = $('body'),
      w 		  = window.innerWidth,
      langToggle    = $('.lang-toggle'),
      langDrop      = $('.lang-dropdown'),
      currencyToggle  = $('.currency-toggle'),
      dropdownCart    = $('#dropdown-cart'),
      currencyDrop    = $('.currency-dropdown'),
      cartNoItems     = dropdownCart.find('.no-items'),
      cartHasItems    = dropdownCart.find('.has-items'),
      miniProductList   = dropdownCart.find('.mini-products-list'),
      headerLangDrop = $('.header-top .lang-list ');

  //Petica Object
  var pet = {

    petTimeout: null,
    isSidebarAjaxClick: false,
    init: function(){
      //header function
      this.langSwitch();
      this.currencySwitch();
      this.initDropdownCart();
      this.closeDropdownClickOut();
      this.countdown();
      if(window.newsletterPopup){
      	this.newsletterPopup();
      }
      if($('#accept-cookies').length > 0){
      	this.acceptCookiePopup();
      }
      if( w < 768){
        this.footerCollapse();
      }
      if( w < 1025){
        this.headerMobile();
      }
      if(w > 1024 && window.fixtop_menu){
        this.fixedTopMenu();
      }
      if($('.template-index').length > 0){
        if($('.home-slideshow').length > 0){
          this.slideshow($('.home-slideshow'));
        }
        this.productTab();
        if($('.homepage-brand-slider').length > 0){
          this.brandSlider();
        }
        this.testimonial();
        this.closeModal();
        this.initAddToCart();
        this.initQuickView();
      }

      if($('.template-collection').length || $('.template-product').length || $('.template-blog').length || $('.template-article').length) {
        this.initProductSidebarSlider();
        this.dropDownSubCategory();
        this.sidebarInitToggle();
        this.closeModal();
      };

      if($('.template-collection').length) {
        this.initSidebar();
        this.initToolbar();
        this.collectionMapPaging();
        this.initInfiniteScrolling();
        this.initAddToCart();
        this.initQuickView();
      };

      if($('.template-product').length) {
        this.sidebarInitToggle();
        this.initProductImageGalery($('.pro-page'));
        this.productZoom();
        this.initProductAddToCart();
        this.initAddToCart();
        this.initQuickView();
        this.initStickyAddtoCart();
        if($('.qty-group').length > 0){
          this.qtyChanger($('.template-product'));
        }
        if(window.related_product){
          this.initRelatedProductSlider();
        }
      }

      if($('.template-cart').length) {
        if($('.qty-group').length > 0){
          this.qtyChanger($('.cart-list'));
        }
      };
      if($('.brands-page').length > 0){
        this.pageBrand();
      }
      if($('.lookbook_page').length > 0){
        this.addEventLookbookModal();
        this.slideshow($('.lookbook_page'));
      }

    },//end pet init 
    langSwitch: function(){

    var currentLang = $.cookie("language") != null ? $.cookie("language") : 1,
        currentLangText = langDrop.find('li[data-lang=' + currentLang + ']').first().text();
    //  console.log(currentLang);
    //function  
    //Change lang toggle to cookie language when pageload
    doc.ready(function(){
      langToggle.text(currentLangText);
      langToggle.attr('data-lang',currentLang);
      langDrop.find('li[data-lang=' + currentLang + ']').addClass('selected');
    });

    //toggle 
      pet.Toggle(langToggle);
      //hide after select
      pet.CloseDropdownItSelf(headerLangDrop);

      //select lang item then change language
      langDrop.find('li.item').on('click',function(){
        var langIndex = $(this).data('lang');
        if($(this).hasClass('selected')){
          return false;
        }else{
          $(this).addClass('selected');
          jQuery.cookie('language', langIndex , {expires:10, path:'/'});
          location.reload();
        }
      });
    },
    Toggle: function(target){
      target.off('click touchstart').on('click touchstart', function(){
        $(this).next().toggle();
      })
    },
    CloseDropdownItSelf: function(drop){
      drop.off('click touchstart').on('click touchstart',function(){
        $(this).hide();
      })
    }

    
  }//end pet Object

  if ($('.collection-sidebar').length) {
    History.Adapter.bind(window, 'statechange', function() {
      var State = History.getState();

      if (!pet.isSidebarAjaxClick) {
        pet.sidebarParams();

        var newurl = pet.sidebarCreateUrl();

        pet.sidebarGetContent(newurl);
      }

      pet.isSidebarAjaxClick = false;
    });
  };


  //Shopify function
  var changeSwatch = function(swatch) {

    swatch.change(function() {
      var optionIndex = $(this).closest('.swatch').attr('data-option-index');
      var optionValue = $(this).val();

      $(this)
      .closest('form')
      .find('.single-option-selector')
      .eq(optionIndex)
      .val(optionValue)
      .trigger('change');
    });
  };


  // Color swatch

  if (window.use_color_swatch) {

    changeSwatch($('.swatch :radio'));

    Shopify.productOptionsMap = {};
    Shopify.quickViewOptionsMap = {};

    Shopify.updateOptionsInSelector = function(selectorIndex, wrapperSlt) {

      Shopify.optionsMap = wrapperSlt === '.product' ? Shopify.productOptionsMap : Shopify.quickViewOptionsMap;

      switch (selectorIndex) {
        case 0:
          var key = 'root';
          var selector = $(wrapperSlt + '.single-option-selector:eq(0)');
          break;
        case 1:
          var key = $(wrapperSlt + ' .single-option-selector:eq(0)').val();
          var selector = $(wrapperSlt + ' .single-option-selector:eq(1)');
          break;
        case 2:
          var key = $(wrapperSlt + ' .single-option-selector:eq(0)').val();
          key += ' / ' + $(wrapperSlt + ' .single-option-selector:eq(1)').val();
          var selector = $(wrapperSlt + ' .single-option-selector:eq(2)');
      }

      var initialValue = selector.val();

      selector.empty();

      var availableOptions = Shopify.optionsMap[key];

      if (availableOptions && availableOptions.length) {
        for (var i = 0; i < availableOptions.length; i++) {
          var option = availableOptions[i];

          var newOption = $('<option></option>').val(option).html(option);

          selector.append(newOption);
        }

        $(wrapperSlt + ' .swatch[data-option-index="' + selectorIndex + '"] .swatch-element').each(function() {
          if ($.inArray($(this).attr('data-value'), availableOptions) !== -1) {
            $(this).removeClass('soldout').find(':radio').removeAttr('disabled', 'disabled').removeAttr('checked');
          }
          else {
            $(this).addClass('soldout').find(':radio').removeAttr('checked').attr('disabled', 'disabled');
          }
        });

        if ($.inArray(initialValue, availableOptions) !== -1) {
          selector.val(initialValue);
        }

        selector.trigger('change');
      };
    };

    Shopify.linkOptionSelectors = function(product, wrapperSlt) {
      // Building our mapping object.
      Shopify.optionsMap = wrapperSlt === '.product' ? Shopify.productOptionsMap : Shopify.quickViewOptionsMap;

      for (var i = 0; i < product.variants.length; i++) {
        var variant = product.variants[i];

        if (variant.available) {
          // Gathering values for the 1st drop-down.
          Shopify.optionsMap['root'] = Shopify.optionsMap['root'] || [];

          Shopify.optionsMap['root'].push(variant.option1);
          Shopify.optionsMap['root'] = Shopify.uniq(Shopify.optionsMap['root']);

          // Gathering values for the 2nd drop-down.
          if (product.options.length > 1) {
            var key = variant.option1;
            Shopify.optionsMap[key] = Shopify.optionsMap[key] || [];
            Shopify.optionsMap[key].push(variant.option2);
            Shopify.optionsMap[key] = Shopify.uniq(Shopify.optionsMap[key]);
          }

          // Gathering values for the 3rd drop-down.
          if (product.options.length === 3) {
            var key = variant.option1 + ' / ' + variant.option2;
            Shopify.optionsMap[key] = Shopify.optionsMap[key] || [];
            Shopify.optionsMap[key].push(variant.option3);
            Shopify.optionsMap[key] = Shopify.uniq(Shopify.optionsMap[key]);
          }
        }
      };

      // Update options right away.
      Shopify.updateOptionsInSelector(0, wrapperSlt);

      if (product.options.length > 1) Shopify.updateOptionsInSelector(1, wrapperSlt);
      if (product.options.length === 3) Shopify.updateOptionsInSelector(2, wrapperSlt);

      // When there is an update in the first dropdown.
      $(wrapperSlt + " .single-option-selector:eq(0)").change(function() {
        Shopify.updateOptionsInSelector(1, wrapperSlt);
        if (product.options.length === 3) Shopify.updateOptionsInSelector(2, wrapperSlt);
        return true;
      });

      // When there is an update in the second dropdown.
      $(wrapperSlt + " .single-option-selector:eq(1)").change(function() {
        if (product.options.length === 3) Shopify.updateOptionsInSelector(2, wrapperSlt);
        return true;
      });

    };
  };


  //Run pet function
  $(document).ready(function() {
    pet.init();
  });


  /* window resize */

  //Optimize resize function

  var resizeTimeout = false;

  $(window).off('resize').on('resize', function() {

    var currentWinWidth = $(window).width();

    if(resizeTimeout) clearTimeout(resizeTimeout);

    resizeTimeout = setTimeout(function() {
      if (currentWinWidth !== $(window).width()){
        //sidebar
        if($('.template-collection').length || $('.template-product').length || $('.template-blog').length || $('.template-article').length) {
          pet.sidebarInitToggle();
        };

        //menu
        pet.initMobileMenu();
        pet.initDropdownMenuMobile();

        //footer
        pet.initDropdownFooterMenu();

        //Product zoom
        if($('.template-product').length) {
          pet.initZoom();
        };

        // re-get window width
        currentWinWidth = $(window).width();
      }
    }, 100);
  });




  // ==============================
  //Begin pet function
  //===============================

  pet.translateBlock = function(blockSelector) {
    if (window.multi_lang && translator.isLang2()) {
      translator.doTranslate(blockSelector);
    }
  }//translateBlock

  pet.translateText = function(str) {
    if (!window.multi_lang || str.indexOf("|") < 0)
      return str;

    if (window.multi_lang) {
      var textArr = str.split("|");

      if (translator.isLang2())
        return textArr[1];
      return textArr[0];
    };
  }//translateBlock

  pet.showModal = function(selector) {
    $(selector).fadeIn(500);

    pet.petTimeout = setTimeout(function() {
      $(selector).fadeOut(500);
    }, 5000);
  }//showModal

  pet.closeModal = function() {
    $('.close-modal, .overlay').click(function(e) {
      e.preventDefault();
      e.stopPropagation();

      clearTimeout(pet.petTimeout);

      $('.ajax-success-modal').fadeOut(500);
    });
  };//closeModal

  pet.convertToSlug = function(text) {
    return text
    .toLowerCase()
    .replace(/[^a-z0-9 -]/g, '') // remove invalid chars
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
  }//convertToSlug
  //===================================
  //   HEADER FUNCTION


  pet.Toggle = function(target){
    target.off('click touchstart').on('click touchstart', function(){
      $(this).next().toggle();
    })
  };

  pet.CloseDropdownItSelf = function(drop){
    drop.off('click touchstart').on('click touchstart',function(){
      $(this).hide();
    })
  };
  pet.closeDropdownClickOut = function(){
    var langContainer = $('.header-top .lang-block '),
        currencyContainer = $('.currency '),
        dropdownCartContainer = dropdownCart.parent(),
        filterSortby = $('.filter-sortby'),
        dropdownSortBy = filterSortby.find('.dropdown-menu'),
        searchMobile = $('.header-bottom .dt-search'),
        searchIcon = $('#mobile-search-toggle'),
        lookbookProduct = $('.ajax-lookbook-modal'),
        lookbookIcon = $('.lookbook-item');


    doc.off('click.closeDropdown').on('click.closeDropdown', function(e) {
      if(langDrop.is(':visible') && !langContainer.is(e.target) && langContainer.has(e.target).length === 0){
        headerLangDrop.hide();
      }
      if(currencyDrop.is(':visible') && !currencyContainer.is(e.target) && currencyContainer.has(e.target).length === 0){
        currencyDrop.hide();
      }
      if(dropdownCart.is(':visible') && !dropdownCartContainer.is(e.target) && dropdownCartContainer.has(e.target).length === 0){
        dropdownCart.hide();
      }
      if(dropdownSortBy.is(':visible') && !filterSortby.is(e.target) && filterSortby.has(e.target).length === 0){
        dropdownSortBy.hide();
      }
      if(searchMobile.is(':visible') && !searchIcon.is(e.target) && searchIcon.has(e.target).length === 0){
        searchMobile.removeClass('show');
        searchIcon.removeClass('close')
      }

      if(lookbookProduct.is(':visible') && !lookbookIcon.is(e.target) && !lookbookProduct.is(e.target) && lookbookIcon.has(e.target).length === 0 && lookbookProduct.has(e.target).length === 0){
        lookbookProduct.fadeOut(500);
      }

    });
  };
  pet.langSwitch = function(){

    var currentLang = $.cookie("language") != null ? $.cookie("language") : 1,
        currentLangText = langDrop.find('li[data-lang=' + currentLang + ']').first().text();
    //  console.log(currentLang);
    //function  
    //Change lang toggle to cookie language when pageload
    doc.ready(function(){
      langToggle.text(currentLangText);
      langToggle.attr('data-lang',currentLang);
      langDrop.find('li[data-lang=' + currentLang + ']').addClass('selected');
    });

    //toggle 
    pet.Toggle(langToggle);
    //hide after select
    pet.CloseDropdownItSelf(headerLangDrop);

    //select lang item then change language
    langDrop.find('li.item').on('click',function(){
      var langIndex = $(this).data('lang');
      if($(this).hasClass('selected')){
        return false;
      }else{
        $(this).addClass('selected');
        jQuery.cookie('language', langIndex , {expires:10, path:'/'});
        location.reload();
      }
    });
  };

  pet.currencySwitch = function(){


    //toggle 
    pet.Toggle(currencyToggle);
    //select lang item
    pet.CloseDropdownItSelf(currencyDrop);
  };//currencySwitch

  pet.initDropdownCart = function() {

    var cartToggle = $('.top-cart');
    if(window.dropdowncart_type == 'click') {
      pet.Toggle(cartToggle);
    }
    else {
      if(!('ontouchstart' in document)) {
        pet.cartToggle.hover(function() {
          $(this).next().toggle();                                       
        });

      }
      //for Mobile
      else {
        pet.clickDropdownCart();
      };
    };

    pet.checkItemsInDropdownCart();
    pet.removeItemDropdownCart();
  };//initDropdownCart


  pet.footerCollapse = function(){
    var  footerTitle = $('.col-footer .foot-title');

    footerTitle.off('click.footerCollapse').on('click.footerCollapse', function(e){
      e.stopPropagation();
      $(this).next().slideToggle();
    })

  }//footerCollapse


  pet.checkItemsInDropdownCart = function() {
    if(miniProductList.children().length) {
      cartHasItems.show();
      cartNoItems.hide();
    }
    else {
      cartHasItems.hide();
      cartNoItems.show();
    }
  };//checkItemsInDropdownCart

  pet.removeItemDropdownCart =  function(cart) {
    var btnRemove = dropdownCart.find('.btn-remove');

    btnRemove.off('click.removeCartItem').on('click.removeCartItem', function(e) {
      e.preventDefault();
      e.stopPropagation();

      var productId = $(this).parents('.item').attr('id');
      productId = productId.match(/\d+/g);

      Shopify.removeItem(productId, function(cart) {
        pet.doUpdateDropdownCart(cart);
      });
    });
  };//removeItemDropdownCart

  pet.updateDropdownCart = function() {
    Shopify.getCart(function(cart) {
      pet.doUpdateDropdownCart(cart);
    });
  };//updateDropdownCart

  pet.doUpdateDropdownCart = function(cart) {
    var template = '<li class="item" id="cart-item-{ID}">';
    template += '<a href="{URL}" title="{TITLE}" class="product-image">';
    template += '<img src="{IMAGE}" alt="{TITLE}"></a>';
    template += '<div class="product-details">';
    template += '<a href="javascript:void(0)" title="Remove This Item" class="btn-remove">';
    template += '<svg viewBox="0 0 24 24" class="icon-close" width="100%" height="100%"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path></svg></a>';
    template += '<p class="product-name"><a href="{URL}">{TITLE}</a></p>';
    template += '<div class="option"><span>- {VARIANT_TITLE}</span></div>';
    template += '<div class="cart-collateral"><span class="qtt">{QUANTITY} x </span><span class="price">{PRICE}</span></div>';
    template += '</div>';
    template += '</li>';

    $('.cartCount').text(cart.item_count);

    dropdownCart.find('.summary .price').html(Shopify.formatMoney(cart.total_price, window.money_format));

    //Update total price at header-cart
    $('.header-cart .cart-text .price').html(Shopify.formatMoney(cart.total_price, window.money_format));

    miniProductList.html('');

    if (cart.item_count > 0) {
      for (var i = 0; i < cart.items.length; i++) {
        var item = template;

        item = item.replace(/\{ID\}/g, cart.items[i].id);
        item = item.replace(/\{URL\}/g, cart.items[i].url);
        item = item.replace(/\{TITLE\}/g, pet.translateText(cart.items[i].product_title));
        if(cart.items[i].variant_title == null){
          item = item.replace(/\{VARIANT_TITLE\}/g, '');
        }else{
          item = item.replace(/\{VARIANT_TITLE\}/g, cart.items[i].variant_title);
        }
        item = item.replace(/\{QUANTITY\}/g, cart.items[i].quantity);
        item = item.replace(/\{IMAGE\}/g, Shopify.resizeImage(cart.items[i].image, '64x'));
        item = item.replace(/\{PRICE\}/g, Shopify.formatMoney(cart.items[i].price, window.money_format));

        miniProductList.append(item);
      }

      pet.removeItemDropdownCart(cart);

      if (pet.checkNeedToConvertCurrency()) {
        Currency.convertAll(window.shop_currency, $('.currency-toggle').first().text(), '#dropdown-cart span.money', 'money_format');
      }
    }

    pet.checkItemsInDropdownCart();
  };//doUpdateDropdownCart

  pet.removeItemDropdownCart = function(cart) {
    var btnRemove = dropdownCart.find('.btn-remove');

    btnRemove.off('click.removeCartItem').on('click.removeCartItem', function(e) {
      e.preventDefault();
      e.stopPropagation();

      var productId = $(this).parents('.item').attr('id');
      productId = productId.match(/\d+/g);

      Shopify.removeItem(productId, function(cart) {
        pet.doUpdateDropdownCart(cart);
      });
    });
  };//removeItemDropdownCart

  pet.checkItemsInDropdownCart = function() {
    if(miniProductList.children().length) {
      cartHasItems.show();
      cartNoItems.hide();
    }
    else {
      cartHasItems.hide();
      cartNoItems.show();
    }
  };//checkItemsInDropdownCart



  pet.fixedTopMenu = function(){
    var menu = $('.wrapper-navigation'),
        menuHeight = menu.outerHeight(),
        menuPos = menu.offset().top,
        searchPop = menu.find('.search-pop');

    $(window).on('scroll.fixedTopMenu',function(){
      var sroll = $(this).scrollTop();

      if(sroll > menuPos){
        menu.addClass('fixed-top');
        body.addClass('fixed-menu');
        $('.main-content').css('padding-top',menuHeight);
      }else{
        menu.removeClass('fixed-top');
        body.removeClass('fixed-menu');
        $('.main-content').css('padding-top',0);
      }
    })


    $('#search-fix').off('click.showSearchPop').on('click.showSearchPop', function(){
      searchPop.fadeIn(300);
    })

    $('#close-search-pop').off('click.showSearchPop').on('click.showSearchPop', function(){
      searchPop.fadeOut(300);
    });
  }//fixedTopMenu


  pet.carousel = function(target){
    var carousel = target.find('.hl-carousel');
    var item = carousel.data('items');
    var breakpointItem = [item,4,3,2,1];
    if(target.hasClass('homepage-testimonial')){
      var breakpointItem = [item,4,3,1,1];
    }
    if(window.related_product){
      var breakpointItem = [item,3,3,2,1];
    }
    for(var i = 1; i < breakpointItem.length ; i++){
      breakpointItem[i] = breakpointItem[i] >= item ? item : breakpointItem[i];
    }
    var arg = {
      infinite: false,
      slidesToShow: item,
      slidesToScroll: 1,
      verticalSwiping: false,
      dots: false,
      arrows:true,
      speed: 500,
      nextArrow: '<button type="button" class="slick-next"><span></span></button>',
      prevArrow: '<button type="button" class="slick-prev"><span></span></button>',
      responsive: [
        {
          breakpoint: 1200,
          settings: {
            slidesToShow: breakpointItem[1],
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 992,
          settings: {
            dots: true,
            slidesToShow: breakpointItem[2],
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 768,
          settings: {
            dots: true,
            slidesToShow: breakpointItem[3],
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 350,
          settings: {
            dots: true,
            slidesToShow: breakpointItem[4],
            slidesToScroll: 1
          }
        }                    
      ],
    }

    if(carousel.length && !carousel.hasClass('slick-initialized')) {
      carousel.slick(arg);
    }  

  }//productCarousel

  pet.headerMobile = function(){
    pet.openMenu();
    pet.showChidMenu();
    pet.backChidMenu();
    pet.searchToggle();
    pet.openUser();
    pet.openDropdownCart();
    pet.homepageCatMenuToggle();

    body.off('click.closeMenu', '.wrapper-overlay , .close-mm' ).on('click.closeMenu', '.wrapper-overlay, .close-mm' , function(e) {
      e.preventDefault();
      e.stopPropagation();
      pet.closeMenu();
    });

  };//headerMobile

  pet.openMenu = function(){
    var menuToggle = $('#showLeftPush');
    var menuToggleSlt = '#showLeftPush';
    var searchMobile = $('.header-bottom .dt-search'),
        searchIcon = $('#mobile-search-toggle'),
        menuMobile = $('.wrapper-navigation');
    body.off('click.openMenu', menuToggleSlt).on('click.openMenu', menuToggleSlt, function(e) {
      e.preventDefault();
      e.stopPropagation();
      body.removeClass('show-mu show-dc').toggleClass('show-mm');
      searchMobile.removeClass('show');
      searchIcon.removeClass('close');
      if(!$('.wrapper-navigation .top-link-area').length > 0){
        $('.header-top .top-link').appendTo('.wrapper-navigation .quicklink-menu');
      }
      menuMobile.find('lang-list').off('click touchstart');
    });



  }//openMenu

  pet.closeMenu = function(){
    body.removeClass('show-mm show-mu show-dc');
  };//closeMenu

  pet.showChidMenu = function(){
    var childMenu = $('.site-nav .dropdown-mm'),
        iconDropdown = childMenu.find('.icon-dropdown');

    childMenu.off('click.childMenu').on('click.childMenu' , function(e) {
      e.stopPropagation();
      $(this).children('.site-nav-dropdown').addClass('open');

    });

    iconDropdown.off('click.childMenu').on('click.childMenu' , function(e) {
      e.stopPropagation();
      e.preventDefault();
      $(this).parents('.dropdown-mm').children('.site-nav-dropdown').addClass('open');

    });
  };//showChidMenu

  pet.backChidMenu = function(){
    var backChidMenu = $('.site-nav .submenu-title');

    backChidMenu.off('click.backChidMenu').on('click.backChidMenu' , function(e) {
      e.stopPropagation();
      $(this).parent('.site-nav-dropdown').removeClass('open');

    });
  };//backChidMenu

  pet.searchToggle = function(){
    var searchToggle = $('#mobile-search-toggle');

    searchToggle.off('click.searchToggle').on('click.searchToggle', function(){

      $(this).toggleClass('close');
      $('.search-pop').fadeToggle();
    })
  };


  pet.openUser = function(){
    var iconUser = $('#icon-user-mb');


    iconUser.off('click.openUser').on('click.openUser', function(){
      body.removeClass('show-mm show-dc').toggleClass('show-mu');
    })
  };


  pet.openDropdownCart = function(){
    var iconCart = $('#cartToggle-mb');

    iconCart.off('click.openDropdownCart').on('click.openDropdownCartopenUser', function(){
      body.removeClass('show-mm show-mu').toggleClass('show-dc');
    })
  };//openDropdownCart

  pet.homepageCatMenuToggle = function(){
    var catMenuToggle = $('.homepage-cat-toggle');
    catMenuToggle.off('click.homepageCatMenuToggle').on('click.homepageCatMenuToggle',function(){
      $(this).next().slideToggle();
    });
  };//homepageCatMenuToggle
  
  pet.slideshow = function(selector){
    var fade = selector.data('fade'),
        auto = selector.data('auto'),
        speed = selector.data('speed');

    selector.each(function(){
      $(this).find('.slideshow').slick({
        dots: true,
        slidesToScroll: 1,
        verticalSwiping: false,
        fade: fade,
        cssEase: "ease",
        speed: 500,
        autoplay: auto,
        autoplaySpeed: speed,
        adaptiveHeight: true,
        nextArrow: '<button type="button" class="slick-next"><i class="fa fa-angle-right"></i></button>',
        prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-angle-left"></i></button>'
      })
    })

  }//slideshow
  
  
  pet.productTab = function(){
    var productTab = $('.widget-trending-product');
    if(productTab.length > 0){
      productTab.each(function(){
        var tabContent = $(this).find('.tab-pane');

        pet.carousel(tabContent.first());
      });

      var collectionNav = productTab.find('.nav-tabs .nav-link');
      collectionNav.off('click').on('click', function(){
        var $this = $(this),
            thisTab = $this.attr('href'),
            productContainer = $(thisTab).find('.products-grid '),
            itemLoad = $this.data('item-load'),
            ajaxUrl = $this.data('ajax'),
            loading = $(thisTab).find('.loading') ;
        if(!$(this).hasClass('loaded')){
          $.ajax({
            ajaxUrl,
            success: function(data) {
              $this.addClass('loaded');
              var dataProduct = $(data).find('.products-grid .grid-item:lt('+ itemLoad +')');

              loading.remove();
              dataProduct.appendTo(productContainer);
              pet.carousel($(thisTab));

            },
            error: function(err) {
              console.log(err);
            }
          })
        }
      });
    }
  };

  pet.brandSlider = function(){
    var brandSlider = $('.homepage-brand-slider').find('.hl-carousel');
    var items = brandSlider.data('items');

    if(brandSlider.length > 0){
      brandSlider.each(function(){
        $('.slide_brand').slick({
          infinite: true,
          slidesToShow: items,
          slidesToScroll: 1,
          variableWidth: true,
          prevArrow: '<button class="slick-prev"><span></span></button>',
          nextArrow: '<button class="slick-next"><span></span></button>'
//           responsive: [
//             {
//               breakpoint: 1025,
//               settings: {
//                 slidesToShow: 3,
//                 slidesToScroll: 1
//               }
//             },
//             {
//               breakpoint: 768,
//               settings: {
//                 slidesToShow: 2,
//                 slidesToScroll: 1
//               }
//             },
//             {
//               breakpoint: 480,
//               settings: {
//                 slidesToShow: 1,
//                 slidesToScroll: 1
//               }
//             } 

//           ]
        });
      });
    }
  }//brandSlider


  pet.testimonial = function(){
    var testimonial = $('.homepage-testimonial');

    testimonial.each(function(){
      pet.carousel($(this));
    })
  }//testimonial


  pet.initProductSidebarSlider = function(){
    var sideProduct = $('#sidebar-product-block');

    pet.carousel(sideProduct);

  }//initProductSidebarSlider

  pet.countdown = function(){
    var widget = $('.widget-countdown-product');
    var timer = $('.countdown .counter');

    widget.each(function(){

      var nowDate = new Date(),
          eventDate = new Date($(this).data('time')),
          nowTime = nowDate.getTime(),
          eventTime = eventDate.getTime(),
          remTime = eventTime - nowTime,
          s = Math.floor(remTime/1000),
          m = Math.floor(s/60),
          h = Math.floor(m/60),
          d = Math.floor(h/24);

      h %= 24;
      m %= 60;
      s %= 60;

      h = h < 10 ? "0" + h : h;
      m = m < 10 ? "0" + m : m;
      s = s < 10 ? "0" + s : s;

      //     console.log(`nowDate = ${nowDate}
      // eventDate = ${eventDate}
      // nowTime= ${nowTime}
      // eventTime = ${eventTime}
      // remTime = ${remTime}
      // d = ${d}
      // s = ${s}
      // m = ${m}
      // h =${h}`);

      timer.html(d+'d ' + h + ':'+m+':'+s);

    });//end each

    setTimeout(pet.countdown,1000)

  }
  //========================================================  
  //   COLLECTION PAGE

  pet.sidebarInitToggle = function() {
    var sidebarLabelSlt = '.col-sidebar .sidebar-label';
    var sidebarLabel = $(sidebarLabelSlt);

    if(sidebarLabel.is(':visible')) {
      body.off('click.showSidebar', sidebarLabelSlt).on('click.showSidebar', sidebarLabelSlt, function(e) {
        $('.sidebar').toggleClass('open').slideToggle();

        var top = $(this).offset().top - 63;

        $('body,html').animate({
          scrollTop: top
        }, 600)
      });
    };

    var widgetTitleSlt = '.sidebar .widget-title';
    var widgetTitle = $(widgetTitleSlt);

    if(window.innerWidth < 992) {
      widgetTitle.addClass('open'); 
      widgetTitle.next().hide();
    }
    else {
      widgetTitle.removeClass('open'); 
      widgetTitle.next().show();
    }

    body.off('click.slideToogle', widgetTitleSlt).on('click.slideToogle', widgetTitleSlt, function(e) {
      clearTimeout(pet.petTimeout);

      pet.petTimeout = setTimeout(function() {
        $('.widget-product .products-grid').slick('unslick');    
        $('.widget-product .products-grid').find('.slick-list').removeAttr('style');

        pet.initProductSidebarSlider();
      }, 50);

      $(this).toggleClass('open');
      $(this).next().slideToggle();
    });
  };//sidebarInitToggle


  pet.dropDownSubCategory = function(){
    var iconDropdownSlt = '.sidebar-links .icon-dropdown';
    var iconDropdown = $(iconDropdownSlt);

    body.off('click.dropDownSubCategory', iconDropdownSlt).on('click.dropDownSubCategory', iconDropdownSlt, function(e) {
      e.preventDefault();
      e.stopPropagation();

      var self = $(this);
      var parent = self.parent();

      if(parent.hasClass('open')) {
        parent.removeClass('open');
        self.next().hide();
      }
      else {
        parent.addClass('open');
        self.next().show();
      }
    });
  };//dropDownSubCategory


  //========================
  //SIDEBAR AJAX FUNCTION


  pet.sidebarAjaxClick = function(baseLink) {

    delete Shopify.queryParams.page;

    var newurl = pet.sidebarCreateUrl(baseLink);

    pet.isSidebarAjaxClick = true;

    History.pushState({
      param: Shopify.queryParams
    }, doc.title , newurl);

    pet.sidebarGetContent(newurl);
  }//sidebarAjaxClick

  pet.sidebarGetContent =  function(newurl) {

    $.ajax({
      type: 'get',
      url: newurl,

      beforeSend: function() {
        pet.showLoading();
      },

      success: function(data) {
        pet.sidebarMapData(data);
        pet.translateBlock('.main-content');
        pet.initColorSwatchGrid();
        pet.sidebarMapTagEvents();
        pet.sidebarMapClear();
        pet.hideLoading();

        if(window.innerWidth < 992 && $('.col-sidebar .sidebar-label').is(':visible')) {
          $('.sidebar').removeClass('open').slideUp(600);
        }
        else {
          $('.sidebar').css({'display': ''});
        };
      },

      error: function(xhr, text) {
        pet.hideLoading();
        $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);
        pet.showModal('.ajax-error-modal');
      }
    });
  }//sidebarGetContent



  pet.sidebarMapData = function(data) {
    var currentList = $('.col-main .products-grid');

    if (currentList.length == 0) {
      currentList = $('.col-main .product-list');
    };

    var productList = $(data).find('.col-main .products-grid');

    if (productList.length == 0) {
      productList = $(data).find('.col-main .product-list');
    };

    currentList.replaceWith(productList);

    //convert currency
    if (pet.checkNeedToConvertCurrency()) {
      Currency.convertAll(window.shop_currency, jQuery('.currency-toggle').first().text(), '.col-main span.money', 'money_format');
    };

    //replace paging
    if ($('.padding').length > 0) {
      $('.padding').replaceWith($(data).find(".padding"));
    }

    else {
      $(".block-row.col-main").append($(data).find('.padding'));
    };

    //replace title & description
    var currenPageTitle = $('.page-title h2');
    var dataPageTitle = $(data).find('.page-title h2');

    if (currenPageTitle.text() != dataPageTitle.text()) {
      currenPageTitle.replaceWith(dataPageTitle);
    }
    var currentDes = $('.collection-des');
    var dataDes = $(data).find('.collection-des');

    if (currentDes.find('.rte').length) {
      if (dataDes.find('.rte').length) {
        currentDes.html(dataDes.find('.rte'));
      } else {
        currentDes.find('.rte').hide();
      }
    }
    else {
      currentDes.html(dataDes.find('.rte'));
    };

    var currentImg = $(".collection-img");
    var dataImg = $(data).find(".collection-img");

    if (currentImg.find("p").length) {
      if (dataImg.find("p").length) {
        currentImg.html(dataImg.find("p"));
      } else {
        currentImg.find("p").hide();
      }
    }
    else {
      currentImg.html(dataImg.find("p"));
    }


    //replace refined
    $('.refined-widgets').replaceWith($(data).find('.refined-widgets'));

    //replace tags
    $('.sidebar-block').replaceWith($(data).find('.sidebar-block'));

    // breadcrumb
    $('.breadcrumb .bd-title').replaceWith($(data).find('.breadcrumb .bd-title'));

    $('head title').text(($(data).filter('title').text()));

    //product review
    if ($('.shopify-product-reviews-badge').length > 0) {
      return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
    };
  }//sidebarMapData

  pet.showLoading = function() {
    $('.loading-modal').show();
  };//showLoading

  pet.hideLoading = function() {
    $('.loading-modal').hide();
  };//hideLoading

  pet.sidebarCreateUrl =  function(baseLink) {
    var newQuery = $.param(Shopify.queryParams).replace(/%2B/g, '+');

    if (baseLink) {
      if (newQuery != "")
        return baseLink + "?" + newQuery;
      else
        return baseLink;
    }
    return location.pathname + "?" + newQuery;
  }//sidebarCreateUrl

  pet.checkNeedToConvertCurrency = function(){
    return window.show_multiple_currencies && Currency.currentCurrency != shopCurrency;
  }//checkNeedToConvertCurrency 




  pet.initSidebar = function() {
    if ($('.collection-sidebar').length) {
      pet.sidebarParams();
      pet.sidebarMapEvents();          
      pet.sidebarMapClear();
      pet.sidebarMapClearAll();
    };
  };//initSidebar

  pet.sidebarParams = function() {
    Shopify.queryParams = {};

    //get after ?...=> Object {q: "Acme"} 

    if (location.search.length) {
      for (var aKeyValue, i = 0, aCouples = location.search.substr(1).split('&'); i < aCouples.length; i++) {
        aKeyValue = aCouples[i].split('=');

        if (aKeyValue.length > 1) {
          Shopify.queryParams[decodeURIComponent(aKeyValue[0])] = decodeURIComponent(aKeyValue[1]);
        }
      }
    };
  }//sidebarParams


  pet.sidebarMapEvents = function() {
    pet.sidebarMapCategories();
    pet.sidebarMapTagEvents();
  };//sidebarMapEvents

  pet.sidebarMapCategories = function() {
    var sidebarLinkSlt = '.sidebar-links-ajax a';
    var sidebarLink = $(sidebarLinkSlt);      

    body.off('click.activeCategory', sidebarLinkSlt).on('click.activeCategory', sidebarLinkSlt, function(e) {

      if($(this).attr('href').indexOf('/collections') > -1) {
        e.preventDefault();
        e.stopPropagation();

        var self = $(this);
        var parent = self.parent();

        if(!$(this).hasClass('active')) {
          delete Shopify.queryParams.q;
          delete Shopify.queryParams.constraint;
          pet.sidebarAjaxClick($(this).attr('href'));
        };

        sidebarLink.not(self).removeClass('active');
        $(this).addClass('active'); 

        if (parent.hasClass('dropdown') && !parent.hasClass('open')) {
          $('.dropdown.open').removeClass('open');
          sidebarLink.siblings('.dropdown-cat').hide();
          self.siblings('.dropdown-cat').show();
          parent.addClass('open');                  	  
        };
      };
    });
  }//sidebarMapCategories

  pet.sidebarMapTagEvents = function() {
    var sidebarTag = $('.sidebar-tag a:not(".clear"), .sidebar-tag label, .refined .selected-tag');

    sidebarTag.off('click.checkedTag').on('click.checkedTag', function(e) {
      e.preventDefault();
      e.stopPropagation();

      var currentTags = [];

      if (Shopify.queryParams.constraint) {
        currentTags = Shopify.queryParams.constraint.split('+'); //Array
      };

      //one selection or multi selection
      if (!window.enable_sidebar_multiple_choice && !$(this).prev().is(':checked')) {
        //remove other selection first
        var otherTag = $(this).closest('.sidebar-tag, .refined-widgets').find('input:checked');

        if (otherTag.length) {
          var tagName = otherTag.val();
          if (tagName) {
            var tagPos = currentTags.indexOf(tagName);
            if (tagPos >= 0) {
              //remove tag
              currentTags.splice(tagPos, 1);
            }
          }
        };
      };

      var tagName = $(this).prev().val();

      if (tagName) {
        var tagPos = currentTags.indexOf(tagName);

        if (tagPos >= 0) {
          //tag already existed, remove tag
          currentTags.splice(tagPos, 1);
        }
        else {
          //tag not existed
          currentTags.push(tagName);
        }
      };

      if (currentTags.length) {
        Shopify.queryParams.constraint = currentTags.join('+');
      }
      else {
        delete Shopify.queryParams.constraint;
      };

      pet.sidebarAjaxClick();
    });
  }//sidebarMapTagEvents


  pet.sidebarMapClear = function() {
    var sidebarTag = $('.sidebar-tag');

    sidebarTag.each(function() {
      var sidebarTag = $(this);

      if (sidebarTag.find('input:checked').length) {
        //has active tag
        sidebarTag.find('.clear').show().click(function(e) {
          e.preventDefault();
          e.stopPropagation();

          var currentTags = [];

          if (Shopify.queryParams.constraint) {
            currentTags = Shopify.queryParams.constraint.split('+');
          };

          sidebarTag.find("input:checked").each(function() {
            var selectedTag = $(this);
            var tagName = selectedTag.val();

            if (tagName) {
              var tagPos = currentTags.indexOf(tagName);
              if (tagPos >= 0) {
                //remove tag
                currentTags.splice(tagPos, 1);
              };
            };
          });

          if (currentTags.length) {
            Shopify.queryParams.constraint = currentTags.join('+');
          }
          else {
            delete Shopify.queryParams.constraint;
          };

          pet.sidebarAjaxClick();

        });
      }
    });
  }//sidebarMapClear

  pet.sidebarMapClearAll = function() {
    var clearAllSlt = '.refined-widgets a.clear-all';
    var clearAllElm = $(clearAllSlt);

    body.off('click.clearAllTags', clearAllSlt).on('click.clearAllTags', clearAllSlt, function(e) {
      e.preventDefault();
      e.stopPropagation();

      delete Shopify.queryParams.constraint;
      delete Shopify.queryParams.q;

      pet.sidebarAjaxClick();
    });
  }//sidebarMapClearAll


  pet.initColorSwatchGrid = function() {
    var itemSwatchSlt = '.item-swatch li label';
    var itemSwatch = $(itemSwatchSlt);

    body.off('click.toggleClass').on('click.toggleClass', itemSwatchSlt, function() {
      var self = $(this);
      var productItemElm = self.closest('.grid-item');

      itemSwatch.removeClass('active');

      self.addClass('active');

      var newImage = self.data('img');

      if(newImage) {
        productItemElm.find('.product-grid-image img').attr({ src: newImage }); 
      }

      return false;
    });
  };//initColorSwatchGrid



  //========================
  //TOOLBAR AJAX FUNCTION


  pet.initToolbar = function() {
    pet.initDropdownFilterSortby();
    pet.toolbarMapEvents();
  };//initToolbar

  pet.initDropdownFilterSortby = function() {
    var labelSlt = '.toolbar .filter-sortby .button-wrapper';
    var dropdownMenuSlt = '.toolbar .filter-sortby .dropdown-menu';


    pet.Toggle($(labelSlt));
    pet.CloseDropdownItSelf($(dropdownMenuSlt));

  }//initDropdownFilterSortby


  pet.toolbarMapEvents = function() {
    pet.sidebarParams();
    pet.toolbarMapView();
    pet.toolbarMapSorting();
  }//toolbarMapEvents

  pet.toolbarMapView = function() {
    var viewAsSlt = '.toolbar .view-mode .view-as';
    var viewAs = $(viewAsSlt);

    body.off('click.mapView', viewAsSlt).on('click.mapView', viewAsSlt, function(e) {
      e.preventDefault();
      e.stopPropagation();

      if (!$(this).hasClass('active')) {

        if ($(this).hasClass('list')) {
          Shopify.queryParams.view = 'list';
        }
        else {
          Shopify.queryParams.view = '';
        }

        pet.sidebarAjaxClick();

        $('.view-mode .view-as.active').removeClass('active');
        $(this).addClass('active');
      }
    });
  }

  pet.toolbarMapSorting = function() {
    var sortbyFilterSlt = '.filter-sortby li span';
    var sortbyFilter = $(sortbyFilterSlt);

    body.off('click.sortBy', sortbyFilterSlt).on('click.sortBy', sortbyFilterSlt, function(e) {
      e.preventDefault();
      e.stopPropagation();

      var self = $(this);
      var parent = self.parent();
      var sortbyText = self.text();
      var label = $('.filter-sortby .button-wrapper .label-text');

      if(!parent.hasClass('active')) {
        Shopify.queryParams.sort_by = $(this).attr('data-href');
        pet.sidebarAjaxClick();
        label.text(sortbyText);
      }

      sortbyFilter.not(self).parent().removeClass('active');
      self.parent().addClass('active');

      $('.filter-sortby .label-tab').removeClass('active').next('.dropdown-menu').hide();
    });

    if (Shopify.queryParams.sort_by) {
      var sortby = Shopify.queryParams.sort_by;
      var sortbyText = $(".filter-sortby span[data-href='" + sortby + "']").text();

      $('.filter-sortby .button-wrapper .label-text').text(sortbyText);
      $('.filter-sortby li.active').removeClass('active');
      $(".filter-sortby span[data-href='" + sortby + "']").parent().addClass("active");
    }

    else {
      var sortbyText = $('.filter-sortby .dropdown-menu .active').text();

      $('.filter-sortby .button-wrapper .label-text').text(sortbyText);
    }
  }//toolbarMapSorting



  pet.collectionMapPaging = function() {
    var paginationSlt = '.pagination-page a';

    body.off('click.initMapPaging', paginationSlt).on('click.initMapPaging', paginationSlt, function(e) {
      e.preventDefault();
      e.stopPropagation();

      var page = $(this).attr('href').match(/page=\d+/g);

      if (page) {
        Shopify.queryParams.page = parseInt(page[0].match(/\d+/g));

        if (Shopify.queryParams.page) {
          var newurl = pet.sidebarCreateUrl();

          pet.isSidebarAjaxClick = true;

          History.pushState({
            param: Shopify.queryParams
          }, doc.title , newurl);

          pet.sidebarGetContent(newurl);

          var top = $('.block-row > div > .toolbar, .search-page').offset().top;

          $('body,html').animate({
            scrollTop: top
          }, 600);
        };
      };

    });
  }//sidebarMapPaging


  pet.initInfiniteScrolling = function() {
    var infiniteScrolling = $('.infinite-scrolling');
    var infiniteScrollingLinkSlt = '.infinite-scrolling a';

    if(infiniteScrolling.length) {
      body.off('click.initInfiniteScrolling', infiniteScrollingLinkSlt).on('click.initInfiniteScrolling', infiniteScrollingLinkSlt, function(e) {
        e.preventDefault();
        e.stopPropagation();

        if (!$(this).hasClass('disabled')) {
          pet.doInfiniteScrolling();
        };
      });

      if(window.infinity_scroll_feature) {


        $(window).scroll(function() {
          var pos = infiniteScrolling.offset().top;
          var scroll = $(this).scrollTop(); 
          var screenHeight = $(window).outerHeight();
          var footerHeight = $('.site-footer').outerHeight();

          if (scroll > (pos - screenHeight + footerHeight - 200 ) && infiniteScrolling.is(':visible')) {

            $(infiniteScrollingLinkSlt).trigger("click");

          }
        });
      }
    };
  };//initInfiniteScrolling

  pet.doInfiniteScrolling = function() {
    var currentList = $('.block-row .products-grid');

    if (!currentList.length) {
      currentList = $('.block-row .product-list');
    };

    if (currentList) {
      var showMoreButton = $('.infinite-scrolling a');

      $.ajax({
        type: 'GET',
        url: showMoreButton.attr('href'),

        beforeSend: function() {
          pet.showLoading();
        },

        success: function(data) {
          pet.hideLoading();

          var products = $(data).find('.block-row .products-grid');

          if (!products.length) {
            products = $(data).find('.block-row .product-list');
          };

          if (products.length) {

            currentList.append(products.children());
            pet.translateBlock('.main-content');

            //get link of Show more
            if ($(data).find('.infinite-scrolling').length > 0) {
              showMoreButton.attr('href', $(data).find('.infinite-scrolling a').attr('href'));
            }
            else {
              //no more products
              var noMoreText = window.inventory_text.no_more_product;

              if (translator.isLang2()) 
                noMoreText = window.lang2.collections.general.no_more_product;

              showMoreButton.html(noMoreText).addClass('disabled');
            };

            //currency
            if (pet.checkNeedToConvertCurrency()) {
              Currency.convertAll(window.shop_currency, jQuery('.currency-toggle').first().text(), 'span.money', 'money_format');
            };

            //product review
            if ($(".shopify-product-reviews-badge").length > 0) {
              return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
            };
          }
        },

        error: function(xhr, text) {
          pet.hideLoading();
          $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);
          pet.showModal('.ajax-error-modal');
        },
        dataType: "html"
      });
    }
  };//doInfiniteScrolling

  //========================
  //QUICKVIEW FUNCTION

  pet.initQuickView = function(){
    var qvButton = '.quickview-button a',
        quickview = $('#quick-view-popup');

    body.off('click.initQuickView', qvButton).on('click.initQuickView', qvButton, function(e) {
      e.preventDefault();
      e.stopPropagation();
      var productUrl = $(this).attr('href'),
          dataUrl = productUrl + '?view=quickview',
          product_handle = $(this).attr('id');;

      $.ajax(
        dataUrl, 
        {
          success: function(data) {

            quickview.find('.content .body').html($(data));

            Shopify.getProduct(product_handle, function(product) {
              // ------------swatch
              if(product.available && product.variants.length > 1){

                new Shopify.OptionSelectors("product-select-" + product.id, {
                  product: product,
                  onVariantSelected: selectCallbackQuickview
                });

                if (window.use_color_swatch) {

                  changeSwatch(quickview.find('.swatch :radio'));

                  Shopify.quickViewOptionsMap = {};
                  Shopify.linkOptionSelectors(product, '#quick-view-popup');
                }
                quickview.find('.selector-wrapper').show();
                quickview.find('form.variants .selector-wrapper label').each(function(i,v) {
                  $(this).html('<span class="required">*</span>' + product.options[i].name);
                  quickview.find('.selector-wrapper label:contains(Color)').parent().hide();
                  quickview.find('.selector-wrapper label:contains(Size)').parent().hide();
                });


              }

              pet.translateBlock('#quick-view-popup');   
              quickview.fadeIn(500);  
              pet.initProductImageGalery($('#quick-view-popup'));
              pet.productZoom();
              //quantity
              if(quickview.find('.qty-group').length > 0){
                pet.qtyChanger(quickview);
              }


              if (window.show_multiple_currencies) {
                Currency.convertAll(window.shop_currency, $('.currency-toggle').first().text(), 'span.money', 'money_format');
              }


            });
          },
          error: function() {
            $('#notification-bar').text('An error occurred');
          }
        }
      );
    });

  }//initQuickView

  pet.updatePricing = function(container){
    var regex = /([0-9]+[.|,][0-9]+[.|,][0-9]+)/g;
    var unitPriceTextMatch = container.find('.price').text().match(regex);

    if (!unitPriceTextMatch) {
      regex = /([0-9]+[.|,][0-9]+)/g;
      unitPriceTextMatch = container.find('.price').text().match(regex);
    }

    if (unitPriceTextMatch) {
      var unitPriceText = unitPriceTextMatch[0];
      var unitPrice = unitPriceText.replace(/[.|,]/g, '');
      var quantity = parseInt(container.find('input[name=quantity]').val());
      var totalPrice = unitPrice * quantity;

      var totalPriceText = Shopify.formatMoney(totalPrice, window.money_format);
      regex = /([0-9]+[.|,][0-9]+[.|,][0-9]+)/g;     
      if (!totalPriceText.match(regex)) {
        regex = /([0-9]+[.|,][0-9]+)/g;
      } 
      totalPriceText = totalPriceText.match(regex)[0];

      var regInput = new RegExp(unitPriceText, "g");
      var totalPriceHtml = container.find('.price').html().replace(regInput, totalPriceText);

      container.find('.total-price span').html(totalPriceHtml);
    }; 
  }//updatePricing

  //========================
  //PRODUCT PAGE FUNCTION

  pet.initProductImageGalery = function(selector) {
    var imgContainer = selector.find('.product-img-box'),
        mainImage = imgContainer.find('.slider-for'),
        navImage = imgContainer.find('.slider-nav'),
        isVertical = imgContainer.hasClass('vertical') ? true : false,
        item = imgContainer.data('item');

    mainImage.slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
      fade: true,
      verticalSwiping: false,
      asNavFor: navImage
    });

    navImage.slick({
      infinite: false,
      slidesToShow: item,
      slidesToScroll: 1,
      vertical: isVertical,
      asNavFor: mainImage,
      verticalSwiping: false,
      focusOnSelect: true,
      nextArrow: '<button type="button" class="slick-next"><i class="fa fa-angle-right"></i></button>',
      prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-angle-left"></i></button>'
    });
  };


  pet.productZoom = function(){

    var imgContainer = $('.product-photo-container'),
        viewer = imgContainer.find('.thumb');

    viewer.mouseenter(function(){
      var zoomImage = $(this).find('img');
      var offset = $(this).offset(),
          productLabel = imgContainer.siblings('.product-label');

      $(this).addClass('zooming');
      $(this).mousemove(function(e){
        var left = e.pageX - offset.left,
            top = e.pageY - offset.top;
        //         console.log('left = ',left);
        //         console.log('top = ',top);
        productLabel.hide();
        zoomImage.css("transform-origin", left + "px " + top +"px");

      }).mouseout(function(){
        productLabel.show();
      })

    })
    .off('mouseout').on('mouseout',function(){
      $(this).removeClass('zooming');
    })

  }//productZoom

  pet.initRelatedProductSlider = function(){
    var relatedProduct = $('.related-products');
    pet.carousel(relatedProduct);
  };

  pet.initAddToCart = function(){
    var btnAddToCartSlt = '.add-to-cart-btn';
    var btnAddToCart = $(btnAddToCartSlt);

    if(btnAddToCart.length) {
      body.off('click.addToCart', btnAddToCartSlt).on('click.addToCart', btnAddToCartSlt, function(e) {
        debugger;
        e.preventDefault();
        e.stopPropagation();

        if($(this).attr('disabled') != 'disabled') {
          var productItem = $(this).parents('.product-item');
          var productId = $(productItem).attr('id');
          var form = productItem.find('form[data-id|="product-actions"]');

          productId = productId.match(/\d+/g);

          if(!window.ajax_cart) {
            form.submit();
          }

          else {

            var variant_id = form.find('select[name=id]').val();
            if(!variant_id) {
              variant_id = form.find('input[name=id]').val();
            }

            var quantity = form.find('input[name=quantity]').val();

            if(!quantity) {
              quantity = 1;
            }

            var title = $(productItem).find('.product-title h2 a').html()|| $(productItem).find('.product-title').html();

            var image = $(productItem).find('.product-grid-image img').attr('src') || $('#more_view .slick-current img').attr('src');

            pet.doAjaxAddToCart(variant_id, quantity, title, image);
          }
        }

        return false;

      });
    }
  }//initAddToCart
  pet.initProductAddToCart = function(){

    var btnAddToCartSlt = '#product-add-to-cart';
    var btnAddToCart = $(btnAddToCartSlt);

    if(btnAddToCart.length) {
      body.off('click.addToCartProduct', btnAddToCartSlt).on('click.addToCartProduct', btnAddToCartSlt, function(e) {
        e.preventDefault();
        e.stopPropagation();

        if($(this).attr('disabled') != 'disabled') {
          if(!window.ajax_cart) {
            $(this).closest('form').submit();
          }

          else {
            var variant_id = $('#add-to-cart-form select[name=id]').val();

            if(!variant_id) {
              variant_id = $('#add-to-cart-form input[name=id]').val();
            }

            var quantity = $('#add-to-cart-form input[name=quantity]').val();

            if(!quantity) {
              quantity = 1;
            }

            var title = $('.product-title h2').html();

            var image = $('.slick-current img[id|="product-featured-image"]').attr('src') || $('.product img[id|="product-featured-image"]').attr('src');

            pet.doAjaxAddToCart(variant_id, quantity, title, image);
          }
        }

        return false;

      });
    }

  };


  pet.doAjaxAddToCart = function(variant_id, quantity, title, image) {
    $.ajax({
      type: "post",
      url: "/cart/add.js",
      data: 'quantity=' + quantity + '&id=' + variant_id,
      dataType: 'json',

      beforeSend: function() {
        pet.showLoading();
      },

      success: function(msg) {
        pet.hideLoading();

        $('.ajax-success-modal').find('.ajax-product-title').html(pet.translateText(title));
        //         $('.ajax-success-modal').find('.ajax-product-vendor').html(vendor);
        $('.ajax-success-modal').find('.ajax-product-image').attr('src', image);
        $('.ajax-success-modal').find('.message-added-cart').show();

        pet.showModal('.ajax-success-modal');
        pet.updateDropdownCart();
      },

      error: function(xhr, text) {
        pet.hideLoading();

        $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);

        pet.showModal('.ajax-error-modal');
      }
    });
  };//doAjaxAddToCart

  pet.qtyChanger = function(container){
    var button = container.find('.qty-group .button');

    button.off('click.changeQuantity').on('click.changeQuantity', function(e) {
      e.preventDefault();
      e.stopPropagation();

      var oldValue = $(this).siblings('input.qty-input').val(),
          newVal = 1;

      if($(this).hasClass('inc')) {
        newVal = parseInt(oldValue) + 1;
      }
      else if(oldValue > 1) {
        newVal = parseInt(oldValue) - 1;
      }

      $(this).siblings('input.qty-input').val(newVal);
      
      if($('.sticky_form').length > 0){
      	$('.sticky_form').find('.qty-input').val(newVal);
        $('.product-shop').find('.qty-input').val(newVal);
      }
      
    });

    container.find('input[name=quantity]').on('change', function(){
      pet.updatePricing(container);
    });

  }//qtyChanger


  pet.pageBrand = function(){
    $(".brands-list .brand").each(function(){
      var chi = $(this).find(".azbrands-title h3").text().trim();
      var ch = $(this).find("ul.brandgrid li:eq(0)").text().charAt(0);
      $('.azbrandstable').children().each(function(){
        if( $(this).find('a').text().trim() == chi){
          if( !$(this).find('a').hasClass('readonly') )
            $(this).find('a').addClass('readonly');
          return;
        }
      });
      if($(this).find(".azbrands-title").length == 0){
        $(this).find("ul.brandgrid").children().appendTo('.brand-' + ch + " ul.brandgrid");
        $(this).remove();
      }
    });

    $('.azbrandstable .vendor-letter a.readonly').click(function(){
      var v = $(this).text();
      $('.brands-list .brand').hide().filter(function(e){
        var n =  $(this).find('h3').text();
        return n == v;
      }).show();
      $('.azbrandstable .all-brand a').click(function(){
        $(".brands-list .brand").show();
      });
    });
    $('.azbrandstable a.readonly').click(function(){
      $('.azbrandstable a').removeClass('active');
      var $this = $(this);
      if (!$this.hasClass('active')) {
        $this.addClass('active');
      }
      //       var topbrand = $('.wrapper-header').outerHeight();
      //       $('html, body').animate({scrollTop: topbrand}, 400);
    });

  }//pageBrand



  var selectCallbackQuickview = function(variant, selector) {

    var productItem = $('#quick-view-popup .product-item'),
        btnAddToCart = productItem.find('.add-to-cart-btn'),
        productPrice = productItem.find('.price'),
        comparePrice = productItem.find('.compare-price'),
        totalPrice = productItem.find('.total-price .total-money'),
        priceSaving = productItem.find('.price-saving');
    if(!variant){
      btnAddToCart.text(window.inventory_text.unavailable).addClass('disabled').attr('disabled', 'disabled');
    } 
    else 
    {
      if(variant.available) {
        btnAddToCart.removeClass('disabled').removeAttr('disabled').text(window.inventory_text.add_to_cart);
      }
      else {
        btnAddToCart.addClass('disabled').attr('disabled', 'disabled').text(window.inventory_text.sold_out);
      };

      // -----    Price
      productPrice.html(Shopify.formatMoney(variant.price, window.shop_money_format ));

      if(variant.compare_at_price > variant.price) {
        comparePrice
        .html(Shopify.formatMoney(variant.compare_at_price, window.shop_money_format ))
        .show();
        productPrice.addClass('on-sale');

        priceSaving.find('.price-save').html(Shopify.formatMoney(variant.compare_at_price - variant.price, window.shop_money_format));
        priceSaving.show();
      }
      else {
        comparePrice.hide();
        productPrice.removeClass('on-sale');
        priceSaving.hide();
      };

      // ------  Color Swatch
      if(window.use_color_swatch) {
        var form = $('#' + selector.domIdPrefix).closest('form');

        for (var i = 0, length = variant.options.length; i < length; i++) {
          var radioButton = form.find('.swatch[data-option-index="' + i + '"] :radio[value="' + variant.options[i] +'"]');

          if (radioButton.size()) {
            radioButton.get(0).checked = true;
          }
        }
      };

      // ------   variant inventory
      if(window.display_quickview_availability) {
        var inventoryInfo = productItem.find('.product-inventory span');

        if (variant.available) {
          if (variant.inventory_management != null) {
            inventoryInfo.text(window.inventory_text.in_stock);
          }
          else {
            inventoryInfo.text(window.inventory_text.many_in_stock);
          }
        }
        else {
          inventoryInfo.text(window.inventory_text.out_of_stock);
        }
      };

      // ------   variant inventory
      if(window.display_quickview_sku) {
        var sku = productItem.find('.sku-product span');

        if(variant) {
          sku.text(variant.sku);
        }
        else {
          sku.empty();
        };
      };


      // ----   price calculation
      var regex = /([0-9]+[.|,][0-9]+[.|,][0-9]+)/g;
      var unitPriceTextMatch = jQuery('.quick-view .price').text().match(regex);

      if (!unitPriceTextMatch) {
        regex = /([0-9]+[.|,][0-9]+)/g;
        unitPriceTextMatch = jQuery('.quick-view .price').text().match(regex);     
      }

      if (unitPriceTextMatch) {
        var unitPriceText = unitPriceTextMatch[0];     
        var unitPrice = unitPriceText.replace(/[.|,]/g,'');
        var quantity = parseInt(jQuery('.quick-view input[name=quantity]').val());
        var totalPrice = unitPrice * quantity;

        var totalPriceText = Shopify.formatMoney(totalPrice, window.money_format);
        regex = /([0-9]+[.|,][0-9]+[.|,][0-9]+)/g;     
        if (!totalPriceText.match(regex)) {
          regex = /([0-9]+[.|,][0-9]+)/g;
        } 
        totalPriceText = totalPriceText.match(regex)[0];

        var regInput = new RegExp(unitPriceText, "g"); 
        var totalPriceHtml = $('.quick-view .price').html().replace(regInput ,totalPriceText);

        $('.quick-view .total-price .total-money').html(totalPriceHtml);
      };

      // ------  Currency
      if(window.show_multiple_currencies) {
        Currency.convertAll(window.shop_currency, $(".currency-toggle").first().text(), 'span.money', 'money_format');
      };

      // -----    variant image
      if (variant && variant.featured_image) {

        var originalImage = $('#quick-view-popup .quickview-featured-image img');
        var newImage = variant.featured_image;
        var element = originalImage[0];


        Shopify.Image.switchImage(newImage, element, function (newImageSizedSrc, newImage, element) {


          $('#quick-view-popup .slider-nav img').each(function() {

            var grandSize = $(this).attr('src');

            grandSize = grandSize.replace('70x70','1024x1024');

            if (grandSize == newImageSizedSrc) {
              $(this).parent().trigger('click'); 
              return false;
            };
          });
        });        
      };
    };
  }//selectCallbackQuickview

  pet.closeLookbookModal =  function() {
    $('.ajax-lookbook-modal').fadeOut(500);
  };

  pet.addEventLookbookModal = function() {
    body.off('click.addEvenLookbookModal touchstart.addEvenLookbookModal', '.lookbook-item').on('click.addEvenLookbookModal touchstart.addEvenLookbookModal', '.lookbook-item', function(e) {
      e.preventDefault();
      e.stopPropagation();
      // 		debugger;
      var handle = $(this).find('span').data('handle'),
          position = $(this);

      pet.doAjaxAddLookbookModal(handle, position);

      doc.off('click.closeLookbookModal').on('click.closeLookbookModal', '[data-close-lookbook-modal], .ajax-lookbook-modal .overlay', function() {
        pet.closeLookbookModal();
        return false;
      });
    });
  };

  pet.doAjaxAddLookbookModal =  function(handle, position) {
    var offSet = $(position).position(),
        top= $(position).offset().top,
        left = offSet.left,
        iconWidth = position.innerWidth(),
        contentWidht = position.closest('.lazy-images-contain').innerWidth(),
        innerLookbookModal = $('.ajax-lookbook-modal').innerWidth(),            
        str1 = contentWidht + "px",
        str2 = left - 2 + "px",
        str3 = iconWidth + "px",
        str4 = innerLookbookModal + "px",
        newtop,
        leftPosition,
        newleft;

    if(window.innerWidth > 767) {
      if((contentWidht - left) < innerLookbookModal) {
        leftPosition = "(100% - " + str1 + ")/2" + " + " + str2 + " - " + str4;        
      }
      else {
        leftPosition = "(100% - " + str1 + ")/2" + " + " + str2 + " + " + str3;
      }

      newleft = "calc(" +  leftPosition + ")";
      newtop = top - (innerLookbookModal/2) + "px";
    }

    else {
      newleft = 0;
      newtop = top - (innerLookbookModal/2) + "px";
    };

    $.ajax({
      type: "get",
      url:'/products/'+handle+'?view=json',

      success: function(data) {
        $('.ajax-lookbook-modal').css({'left': newleft, 'top': newtop });

        $('.ajax-lookbook-modal .lookbook-content').html(data);

        pet.translateBlock('.lookbook-content');
        $('.ajax-lookbook-modal').fadeIn(500);
        pet.initAddToCart();
      },

      error: function(xhr, text) {
        $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);

        pet.showModal('.ajax-error-modal');
      }
    });
  };


  pet.initStickyAddtoCart = function(){

    if ($('#grouped-add-to-cart').length){
      $('.sticky_form .sticky-item.extra').remove();
    }

    var p = $('#product-selectors option:selected').val();
    var t = $('.sticky_form .pr-swatch[data-value="'+p+'"]').text();
    $('.pr-selectors .pr-active').text(t);
    $('.sticky_form .pr-swatch[data-value="'+p+'"]').addClass('active');


    $( ".swatch .swatch-element" ).each(function(e) {
      var dav = $(this).data("value");
      $('.swatch input.text[data-value="'+dav+'"]').appendTo($(this))
    });


    $( ".selector-wrapper" ).change(function() {
      var n =$("#product-selectors").val();
      $( ".sticky_form .pr-selectors li" ).each(function( e ) {
        var t =$(this).find('a').data('value');
        if(t == n){
          $(this).find('a').addClass('active')
        } else{
          $(this).find('a').removeClass('active')
        }
      });
      $( "#product-selectors" ).change(function() {
        var str = "";
        $( "#product-selectors option:selected" ).each(function() {
          str += $( this ).data('imge');
        });
        $('.sticky_form .pr-img img').attr("src",str );
      }).trigger( "change" );

      if($('.sticky_form .pr-swatch').hasClass('active')){
        var h = $('.sticky_form .pr-swatch.active').text();
        $('.sticky_form .action input[type=hidden]').val(n);
        $('.sticky_form .pr-active').text(h);
        $('.sticky_form .pr-active').attr('data-value', n);
      }

    });

    $(document).click(function(e){
      var container = $(".sticky_form .pr-active");
      if (!container.is(e.target) && container.has(e.target).length === 0){
        $('.sticky_form').removeClass('open-sticky');
      }
    });

    $('.sticky_form .pr-active').on('click', function(){
      $('.sticky_form').toggleClass('open-sticky');
    });

    $('.sticky_form .pr-swatch').on('click', function(e){        
      $('.sticky_form .pr-swatch').removeClass('active');
      $(this).addClass('active');


      $('.sticky_form').toggleClass('open-sticky');


      var text = $(this).text(),
          value = $(this).data('value');

      $('.sticky_form .action input[type=hidden]').val(value);
      $('.sticky_form .pr-active').attr('data-value', value);
      $('.sticky_form .pr-active').text(text);
      $( '.swatch input.text[data-v="'+value+'"]' ).parent().find('.tric').click();

      if($(this).hasClass('sold-out')){
        $('.sticky-add-to-cart').val(window.inventory_text.sold_out).addClass('disabled').attr('disabled', 'disabled');
      }
      else{
        $('.sticky-add-to-cart').removeClass('disabled').removeAttr('disabled').val(window.inventory_text.add_to_cart);
      }

      var newImage = $(this).data('img');
      $('.pr-img img').attr({ src: newImage }); 
      return false;

    });

    $(document).on('click', '.sticky-add-to-cart', function(event) {
      event.preventDefault();
      if ($('#grouped-add-to-cart').length){
        $('#grouped-add-to-cart').click();
      }else{
        $('#product-add-to-cart').click();
      }
      return false;
    });

    var height = $('.product').outerHeight();

    $(window).scroll(function () {
      var scrollTop = $(this).scrollTop();
      if (scrollTop > height) {
        $('body').addClass('show_sticky');
      }
      else {
        $('body').removeClass('show_sticky');
      }
    });   

  
  };//initStickyAddtoCart
  
  pet.newsletterPopup = function(){
  	var $modalParent        = $('div.newsletterwrapper'),
        delayTime 			= $modalParent.data('delay'),
        emailModal          = $modalParent.find('#email-modal'),
        modalPageURL        = window.location.pathname; 



    if(jQuery.cookie('emailSubcribeModal') != 'closed') {
      setTimeout(pet.openEmailModalWindow, delayTime);
      
      $('#email-modal .close-window, #email-modal .modal-overlay').click(function(e) {
        e.preventDefault();
        pet.closeEmailModalWindow();
      });
      
      $('body').keydown(function(e) {
        if( e.which == 27) {
          pet.closeEmailModalWindow();
          jQuery('body').unbind('keydown');
        }
      });
      
      emailModal.find('#mc_embed_signup form').submit(function() {
        if ($('#mc_embed_signup .email').val() != '') {
          pet.closeEmailModalWindow();
        }
      });

    };
  }//newsletterPopup
   pet.closeEmailModalWindow = function() {
      $('#email-modal .modal-window').fadeOut(600, function() {
        $('#email-modal .modal-overlay').fadeOut(600, function() {
          $('#email-modal').hide();
          if ($('#email-modal').find('input[name="dismiss"]').prop('checked'))
          	jQuery.cookie('emailSubcribeModal', 'closed', {expires:1, path:'/'});
        });
      })
    }//closeEmailModalWindow
    pet.openEmailModalWindow = function() {
      $('#email-modal').fadeIn(600, function() {
        $('#email-modal .modal-window').fadeIn(600);
      });
    }//openEmailModalWindow
    
    pet.acceptCookiePopup = function(){
      if ($.cookie('cookieMessage') != 'closed') {
        $('#accept-cookies').fadeIn();
      }
      

      $('#accept-cookies .btn').bind('click',function(){
        $('#accept-cookies').fadeOut();
        $.cookie('cookieMessage', 'closed', {expires:1, path:'/'});
      });

      $('#accept-cookies .close').bind('click',function(){
        $('#accept-cookies').fadeOut();
      });
    }
})(jQuery);