(function($) {
  	var body = $('body'),
        doc = $(document),
        html = $('html'),
        win = $(window);
  	var wishListsArr = localStorage.getItem('items') ? JSON.parse(localStorage.getItem('items')) : [];

    localStorage.setItem('items', JSON.stringify(wishListsArr));

    if (wishListsArr.length) {
        wishListsArr = JSON.parse(localStorage.getItem('items'));
    };
  
    if ($(".collection-sidebar")) {
        //work only in collection page
        History.Adapter.bind(window, 'statechange', function() {
            var State = History.getState();
            if (!furnitica.isSidebarAjaxClick) {
                furnitica.sidebarParams();
                var newurl = furnitica.sidebarCreateUrl();
                furnitica.sidebarGetContent(newurl);
                furnitica.reActivateSidebar();
            }
            furnitica.isSidebarAjaxClick = false;
        });
    }
    if (window.use_color_swatch) {
        $('.swatch :radio').change(function() {
            var optionIndex = $(this).closest('.swatch').attr('data-option-index');
            var optionValue = $(this).val();
            $(this)
                .closest('form')
                .find('.single-option-selector')
                .eq(optionIndex)
                .val(optionValue)
                .trigger('change');
        });

        // (c) Copyright 2014 Caroline Schnapp. All Rights Reserved. Contact: mllegeorgesand@gmail.com
        // See http://docs.shopify.com/manual/configuration/store-customization/advanced-navigation/linked-product-options

        Shopify.productOptionsMap = {};
    Shopify.quickViewOptionsMap = {};

    Shopify.updateOptionsInSelector = function(selectorIndex, wrapperSlt) {

      Shopify.optionsMap = wrapperSlt === '.product' ? Shopify.productOptionsMap : Shopify.quickViewOptionsMap;

      switch (selectorIndex) {
        case 0:
          var key = 'root';
          var selector = $(wrapperSlt + '.single-option-selector:eq(0)');
          break;
        case 1:
          var key = $(wrapperSlt + ' .single-option-selector:eq(0)').val();
          var selector = $(wrapperSlt + ' .single-option-selector:eq(1)');
          break;
        case 2:
          var key = $(wrapperSlt + ' .single-option-selector:eq(0)').val();
          key += ' / ' + $(wrapperSlt + ' .single-option-selector:eq(1)').val();
          var selector = $(wrapperSlt + ' .single-option-selector:eq(2)');
      }

      var initialValue = selector.val();

      selector.empty();

      var availableOptions = Shopify.optionsMap[key];

      if (availableOptions && availableOptions.length) {
        for (var i = 0; i < availableOptions.length; i++) {
          var option = availableOptions[i];

          var newOption = $('<option></option>').val(option).html(option);

          selector.append(newOption);
        }

        $(wrapperSlt + ' .swatch[data-option-index="' + selectorIndex + '"] .swatch-element').each(function() {
          if ($.inArray($(this).attr('data-value'), availableOptions) !== -1) {
            $(this).removeClass('soldout').find(':radio').removeAttr('disabled', 'disabled').removeAttr('checked');
          }
          else {
            $(this).addClass('soldout').find(':radio').removeAttr('checked').attr('disabled', 'disabled');
          }
        });

        if ($.inArray(initialValue, availableOptions) !== -1) {
          selector.val(initialValue);
        }

        //         selector.trigger('change');
      };
    };

    Shopify.linkOptionSelectors = function(product, wrapperSlt) {
      // Building our mapping object.
      Shopify.optionsMap = wrapperSlt === '.product' ? Shopify.productOptionsMap : Shopify.quickViewOptionsMap;

      for (var i = 0; i < product.variants.length; i++) {
        var variant = product.variants[i];

        if (variant.available) {
          // Gathering values for the 1st drop-down.
          Shopify.optionsMap['root'] = Shopify.optionsMap['root'] || [];

          Shopify.optionsMap['root'].push(variant.option1);
          Shopify.optionsMap['root'] = Shopify.uniq(Shopify.optionsMap['root']);

          // Gathering values for the 2nd drop-down.
          if (product.options.length > 1) {
            var key = variant.option1;
            Shopify.optionsMap[key] = Shopify.optionsMap[key] || [];
            Shopify.optionsMap[key].push(variant.option2);
            Shopify.optionsMap[key] = Shopify.uniq(Shopify.optionsMap[key]);
          }

          // Gathering values for the 3rd drop-down.
          if (product.options.length === 3) {
            var key = variant.option1 + ' / ' + variant.option2;
            Shopify.optionsMap[key] = Shopify.optionsMap[key] || [];
            Shopify.optionsMap[key].push(variant.option3);
            Shopify.optionsMap[key] = Shopify.uniq(Shopify.optionsMap[key]);
          }
        }
      };

      // Update options right away.
      Shopify.updateOptionsInSelector(0, wrapperSlt);

      if (product.options.length > 1) Shopify.updateOptionsInSelector(1, wrapperSlt);
      if (product.options.length === 3) Shopify.updateOptionsInSelector(2, wrapperSlt);

      // When there is an update in the first dropdown.
      $(wrapperSlt + " .single-option-selector:eq(0)").change(function() {
        Shopify.updateOptionsInSelector(1, wrapperSlt);
        if (product.options.length === 3) Shopify.updateOptionsInSelector(2, wrapperSlt);
        return true;
      });

      // When there is an update in the second dropdown.
      $(wrapperSlt + " .single-option-selector:eq(1)").change(function() {
        if (product.options.length === 3) Shopify.updateOptionsInSelector(2, wrapperSlt);
        return true;
      });

    };
    }

    $(document).ready(function() {
        furnitica.init();
      	doc
            .on('shopify:section:load', furnitica.initSlideshow)
            .on('shopify:section:unload', furnitica.initSlideshow)
    });

    $(window).resize(function() {
        furnitica.initMobileMenu();
        furnitica.initResizeImage();
    });

    $(window).scroll(function() {
        if ($(this).scrollTop() > 200) {
            $('#back-top').fadeIn();
        } else {
            $('#back-top').fadeOut();
        }
    });
    $(document).on('click touchstart', function(e) {
      var quickview = $(".quick-view");
      var dropdowncart = $("#dropdown-cart");
      var cartButton = $("#cartToggle");
      var newsletter = $("#email-modal .modal-window");
      var dropdownAccount = $(".customer-area");
      var dropdownOtp = $('.opt-area');

      //close quickview and dropdowncart when clicking outside
      if (!dropdownOtp.is(e.target) && dropdownOtp.has(e.target).length === 0 &&  !quickview.is(e.target) && quickview.has(e.target).length === 0 && !dropdowncart.is(e.target) && dropdowncart.has(e.target).length === 0 && !cartButton.is(e.target) && cartButton.has(e.target).length === 0 && !newsletter.is(e.target) && newsletter.has(e.target).length === 0 && !dropdownAccount.is(e.target) && dropdownAccount.has(e.target).length === 0) {
        furnitica.closeQuickViewPopup();
        furnitica.closeDropdownCart();
        furnitica.closeDropdownAccount();
      }
    });
    $(document).keyup(function(e) {
        if (e.keyCode == 27) {
            furnitica.closeQuickViewPopup();
            furnitica.closeDropdownCart();
            furnitica.closeDropdownAccount();
      		furnitica.closeDropdownSearch();
            clearTimeout(furnitica.furniticaTimeout);
            if ($('.modal').is(':visible')) {
                $('.modal').fadeOut(500);
            }
        }
    });

    var furnitica = {
        furniticaTimeout: null,
        isSidebarAjaxClick: false,
        init: function() {
            this.initColorSwatchGrid();
            this.initResizeImage();
            this.initSidebar();
            this.initMobileSidebar();
          	this.initMobileMenu();
            this.initScrollTop();
            this.initQuickView();
            this.initCloudzoom();
            this.initProductMoreview();
            this.initAddToCart();
            this.initModal();
            this.initProductAddToCart();
            this.initDropDownCart();
      		this.initDropdownSearch();
            this.initToggleCollectionPanel();
            this.initInfiniteScrolling();
          	this.initScrollbar();
          	this.checkbox_checkout();
          	this.initWishListIcons();
            this.doAddOrRemoveWishlish();
           	this.initWishLists();
          	this.initSlideshow();
          	this.productRecomendation();
            this.cookie_popup();
        },

        cookie_popup: function() {
          $('#accept-cookies').show();
          if ($.cookie('cookieMessage') == 'closed') {
            $('#accept-cookies').remove();
          }

          $('#accept-cookies .btn').bind('click',function(){
            $('#accept-cookies').remove();
            $.cookie('cookieMessage', 'closed', {expires:1, path:'/'});
          });

          $('#accept-cookies .close').bind('click',function(){
            $('#accept-cookies').remove();
          });
        },

        initScrollbar: function () {
//           $("/*.sidebar-links .widget-content > ul, */.sidebar-custom ul").niceScroll({
//             cursoropacitymin: 1,
//             cursorborder:"",
//             cursorwidth: "5px",
//             cursorcolor:"#5e5e5e",
//             cursorborderradius:0,
//             background: "#ebebeb"
//           });
        },
        sidebarMapTagEvents: function() {
          	$('.sidebar-tag a:not(".clear"), .sidebar-tag label').click(function(e) {
                var currentTags = [];
                if (Shopify.queryParams.constraint) {
                    currentTags = Shopify.queryParams.constraint.split('+');
                }

                //one selection or multi selection
                if (!window.enable_sidebar_multiple_choice && !$(this).prev().is(":checked")) {
                    //remove other selection first
                    var otherTag = $(this).parents('.sidebar-tag').find("input:checked");
                    if (otherTag.length > 0) {
                        var tagName = otherTag.val();
                        if (tagName) {
                            var tagPos = currentTags.indexOf(tagName);
                            if (tagPos >= 0) {
                                //remove tag
                                currentTags.splice(tagPos, 1);
                            }
                        }
                    }
                }

                var tagName = $(this).prev().val();
                if (tagName) {
                    var tagPos = currentTags.indexOf(tagName);
                    if (tagPos >= 0) {
                        //tag already existed, remove tag
                        currentTags.splice(tagPos, 1);
                    } else {
                        //tag not existed
                        currentTags.push(tagName);
                    }
                }
                if (currentTags.length) {
                    Shopify.queryParams.constraint = currentTags.join('+');
                } else {
                    delete Shopify.queryParams.constraint;
                }
                furnitica.sidebarAjaxClick();
                e.preventDefault();
            });
        },
        sidebarMapCategories: function() {
            $(".collection-sidebar .sidebar-links a").click(function(e) {
                if (!$(this).hasClass('active')) {
                    delete Shopify.queryParams.q;
                    furnitica.sidebarAjaxClick($(this).attr('data-href'));

                    //activate selected category
                    $(".sidebar-links a.active").removeClass("active");
                    $(this).addClass("active");
                  
                  	var par = $(this).parent();
                  	if (par.hasClass("dropdown") && !par.hasClass("click")) {
                    	$(".dropdown.click").removeClass("click");
						par.addClass("click");                  	  
                  	}
                }
                e.preventDefault();
            });
          
          	$(".sidebar-links li .caret").click(function(n)
            {
                var t = $(this).parent();
                if (t.hasClass("click"))
                {
                    t.removeClass("click");
                }
                else
                {
                    t.addClass("click");
                }              
                n.preventDefault();
            });
        },
       sidebarMapView: function() {
            $(".view-mode a").click(function(e) {
                if (!$(this).hasClass("active")) {
                    var paging = $(".filter-show > button span").text();
                    if ($(this).hasClass("list")) {
                        Shopify.queryParams.view = "list" + paging;
                    } else {
                        Shopify.queryParams.view = paging;
                    }

                    furnitica.sidebarAjaxClick();
                    $(".view-mode a.active").removeClass("active");
                    $(this).addClass("active");
                }
                e.preventDefault();
            });
        },
        sidebarMapShow: function() {
            $(".filter-show a").click(function(e) {
                if (!$(this).parent().hasClass("active")) {
                    var thisPaging = $(this).attr('href');

                    var view = $(".view-mode a.active").attr("href");
                    if (view == "list") {
                        Shopify.queryParams.view = "list" + thisPaging;
                    } else {
                        Shopify.queryParams.view = thisPaging;
                    }

                    furnitica.sidebarAjaxClick();
                    $(".filter-show > button span").text(thisPaging);
                    $(".filter-show li.active").removeClass("active");
                    $(this).parent().addClass("active");
                }
                e.preventDefault();
            });
        },
        sidebarViewMode: function(){
          $(".view-mode a.grid").click(function(e) {
            $('.view-mode a.list').removeClass('active');
            $(this).addClass('active');
            if($('.product-collection').hasClass('product-list')){
                $('.product-collection').addClass('products-grid-covert');
            }
            else if($('.product-collection').hasClass('products-grid')){
              $('.product-collection').removeClass('products-list-covert');
            }
          });

          $(".view-mode a.list").click(function(e) {
            $('.view-mode a.grid').removeClass('active');
            $(this).addClass('active');   
            if($('.product-collection').hasClass('products-grid')){
                $('.product-collection').addClass('products-list-covert');
            }
            else if($('.product-collection').hasClass('product-list')){
              $('.product-collection').removeClass('products-grid-covert');
            }
          });
        },
        sidebarInitToggle: function() {
            if ($(".sidebar-tag").length > 0) {
                $(".sidebar-tag .widget-title span").click(function() {
                    var $title = $(this).parents('.widget-title');
                    if ($title.hasClass('click')) {
                        $title.removeClass('click');
                    } else {
                        $title.addClass('click');
                    }

                    $(this).parents(".sidebar-tag").find(".widget-content").slideToggle();
                });
            }
            if ($(".sidebar-links").length > 0) {
                $('.sidebar-links ul.cat-dropdown a').parents(".dropdown").removeClass("click");  
              	//$('.sidebar-links a.active').parents('.dropdown').addClass("click");
                $('.sidebar-links a.active').parents(".dropdown").addClass("click").find("ul.cat-dropdown").show();
                //$('.sidebar-links a.active').parent().addClass("click").find("ul.dropdown-cat").show();
            }
        },
         sidebarMapSorting: function(e) {
            $(".filter-sortby li span").click(function(e) {
                if (!$(this).parent().hasClass("active")) {
                    Shopify.queryParams.sort_by = $(this).attr("data-href");
                    furnitica.sidebarAjaxClick();
                    var sortbyText = $(this).text();
                    $(".filter-sortby > button span").text(sortbyText);
                    $(".filter-sortby li.active").removeClass("active");
                    $(this).parent().addClass("active");
                }
                e.preventDefault();
            });
        },
        sidebarMapPaging: function() {
            $(".template-collection .pagination-page a").click(function(e) {
                var page = $(this).attr("href").match(/page=\d+/g);
                if (page) {
                    Shopify.queryParams.page = parseInt(page[0].match(/\d+/g));
                    if (Shopify.queryParams.page) {
                        var newurl = furnitica.sidebarCreateUrl();
                        furnitica.isSidebarAjaxClick = true;
                        History.pushState({
                            param: Shopify.queryParams
                        }, newurl, newurl);
                        furnitica.sidebarGetContent(newurl);
                        //go to top
                        $('body,html').animate({
                            scrollTop: 500
                        }, 600);
                    }
                }
                e.preventDefault();
            });
        },
        sidebarMapClearAll: function() {
            //clear all selection
            $('.refined-widgets a.clear-all').click(function(e) {
                delete Shopify.queryParams.constraint;
                delete Shopify.queryParams.q;
                furnitica.sidebarAjaxClick();
                e.preventDefault();
            });
        },
        ClearSelected: function(){
              $('.selected-tag a').click(function(e) {
                  var currentTags = [];
                  if (Shopify.queryParams.constraint) {
                      currentTags = Shopify.queryParams.constraint.split('+');
                  }

                  //one selection or multi selection
                  if (!window.enable_sidebar_multiple_choice && !$(this).prev().is(":checked")) {
                      //remove other selection first
                      var otherTag = $(this).parents('.selected-tag').find("input:checked");
                      if (otherTag.length > 0) {
                          var tagName = otherTag.val();
                          if (tagName) {
                              var tagPos = currentTags.indexOf(tagName);
                              if (tagPos >= 0) {
                                  //remove tag
                                  currentTags.splice(tagPos, 1);
                              }
                          }
                      }
                  }

                  var tagName = $(this).prev().val();
                  if (tagName) {
                      var tagPos = currentTags.indexOf(tagName);
                      if (tagPos >= 0) {
                          //tag already existed, remove tag
                          currentTags.splice(tagPos, 1);
                      } else {
                          //tag not existed
                          currentTags.push(tagName);
                      }
                  }
                  if (currentTags.length) {
                      Shopify.queryParams.constraint = currentTags.join('+');
                  } else {
                      delete Shopify.queryParams.constraint;
                  }
                  furnitica.sidebarAjaxClick();
                  e.preventDefault();
              });
        },
        sidebarMapClear: function() {
            $(".sidebar-tag").each(function() {
                var sidebarTag = $(this);
                if (sidebarTag.find("input:checked").length > 0) {
                    //has active tag
                    sidebarTag.find(".clear").show().click(function(e) {
                        var currentTags = [];
                        if (Shopify.queryParams.constraint) {
                            currentTags = Shopify.queryParams.constraint.split('+');
                        }
                        sidebarTag.find("input:checked").each(function() {
                            var selectedTag = $(this);
                            var tagName = selectedTag.val();
                            if (tagName) {
                                var tagPos = currentTags.indexOf(tagName);
                                if (tagPos >= 0) {
                                    //remove tag
                                    currentTags.splice(tagPos, 1);
                                }
                            }
                        });
                        if (currentTags.length) {
                            Shopify.queryParams.constraint = currentTags.join('+');
                        } else {
                            delete Shopify.queryParams.constraint;
                        }
						furnitica.sidebarAjaxClick();
                        e.preventDefault();
                    });
                }
            });
        },
        sidebarMapEvents: function() {
            furnitica.sidebarMapTagEvents();
            furnitica.sidebarMapCategories();
           furnitica.sidebarMapView();
            furnitica.sidebarMapShow();
          
      		//furnitica.sidebarViewMode();
            furnitica.sidebarMapSorting();
        },
        reActivateSidebar: function() {
            $(".sidebar-custom .active, .sidebar-links .active").removeClass("active");
            $(".sidebar-tag input:checked").attr("checked", false);

            //category
            var cat = location.pathname.match(/\/collections\/(.*)(\?)?/);
            if (cat && cat[1]) {
                $(".sidebar-links a[data-href='" + cat[0] + "']").addClass("active");
            }

            //view mode and show filter
            if (Shopify.queryParams.view) {
                $(".view-mode .active").removeClass("active");
                var view = Shopify.queryParams.view;
                if (view.indexOf("list") >= 0) {
                    $(".view-mode .list").addClass("active");
                    //paging
                    view = view.replace("list", "");
                } else {
                    $(".view-mode .grid").addClass("active");
                }
                $(".filter-show > button span.number").text(view);
                $(".filter-show li.active").removeClass("active");
                $(".filter-show a[href='" + view + "']").parent().addClass("active");
            }
            furnitica.initSortby();
        },
        initSortby: function() {
            //sort by filter
            if (Shopify.queryParams.sort_by) {
                var sortby = Shopify.queryParams.sort_by;
                var sortbyText = $(".filter-sortby span[data-href='" + sortby + "']").text();
                $(".filter-sortby > button span").text(sortbyText);
                $(".filter-sortby li.active").removeClass("active");
                $(".filter-sortby span[data-href='" + sortby + "']").parent().addClass("active");
            }
        },
        sidebarMapData: function(data) {
            var currentList = $(".col-main .products-grid");
            if (currentList.length == 0) {
                currentList = $(".col-main .product-list");
            }
            var productList = $(data).find(".col-main .products-grid");
            if (productList.length == 0) {
                productList = $(data).find(".col-main .product-list");
            }
            if (productList.length > 0 && productList.hasClass("products-grid")) {
                if (window.product_image_resize) {
                    productList.find('img').fakecrop({
                        fill: window.images_size.is_crop,
                        widthSelector: ".products-grid .grid-item .product-image",
                        ratioWrapper: window.images_size
                    });
                }
            }
            currentList.replaceWith(productList);
            //convert currency
            if (furnitica.checkNeedToConvertCurrency()) {
              Currency.convertAll(window.shop_currency, jQuery('.currencies').val(), '.col-main span.money', 'money_format');
            }

            //replace paging
            if ($(".padding").length > 0) {
                $(".padding").replaceWith($(data).find(".padding"));
            } else {
                $(".block-row.col-main").append($(data).find(".padding"));
            }
          
            // page top
          	if ($(".padding_top").length > 0) {
                $(".padding_top").replaceWith($(data).find(".padding_top"));
            } else {
                $(".block-row.col-main .product-collection.products-grid").before($(data).find(".padding_top"));
            }
            //replace title & description
            var currentHeader = $(".page-header");
            var dataHeader = $(data).find(".page-header");
            if (currentHeader.find("h3").text() != dataHeader.find("h3").text()) {
                currentHeader.find("h3").replaceWith(dataHeader.find("h3"));
              
                var currentDes = $(".collection-des");
                var dataDes = $(data).find(".collection-des");
              
                if (currentDes.find(".rte").length) {
                    if (dataDes.find(".rte").length) {
                        currentDes.html(dataDes.find(".rte"));
                    } else {
                        currentDes.find(".rte").hide();
                    }
                } else {
                    currentDes.html(dataDes.find(".rte"));
                }
              
                var currentImg = $(".collection-img");
                var dataImg = $(data).find(".collection-img");
                if (currentImg.find("p").length) {
                    if (dataImg.find("p").length) {
                        currentImg.html(dataImg.find("p"));
                    } else {
                        currentImg.find("p").hide();
                    }
                } else {
                    currentImg.html(dataImg.find("p"));
                }
            }

            //replace refined
            $(".refined-widgets").replaceWith($(data).find(".refined-widgets"));
            
            //replace tags
            $(".sidebar-block").replaceWith($(data).find(".sidebar-block"));
          
            //breadcrumb
           $(".breadcrumb .br_title").replaceWith($(data).find(".breadcrumb .br_title"));
          
            furnitica.initColorSwatchGrid();
          
            //product review
            if ($(".spr-badge").length > 0) {
                return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
            }
        },
        sidebarCreateUrl: function(baseLink) {
            var newQuery = $.param(Shopify.queryParams).replace(/%2B/g, '+');
            if (baseLink) {
                //location.href = baseLink + "?" + newQuery;
                if (newQuery != "")
                    return baseLink + "?" + newQuery;
                else
                    return baseLink;
            }
            return location.pathname + "?" + newQuery;
        },
        sidebarAjaxClick: function(baseLink) {
            delete Shopify.queryParams.page;
            var newurl = furnitica.sidebarCreateUrl(baseLink);
            furnitica.isSidebarAjaxClick = true;
            History.pushState({
                param: Shopify.queryParams
            }, newurl, newurl);
            furnitica.sidebarGetContent(newurl);
        },
        sidebarGetContent: function(newurl) {
            $.ajax({
                type: 'get',
                url: newurl,
                beforeSend: function() {
                    furnitica.showLoading();
                },
                success: function(data) {
                    furnitica.sidebarMapData(data);
                    furnitica.sidebarMapPaging();
                    furnitica.translateBlock(".main-content");
                    furnitica.sidebarMapTagEvents();
                    furnitica.sidebarInitToggle();
                    furnitica.sidebarMapClear();
                    furnitica.sidebarMapClearAll();
                    furnitica.ClearSelected();
                    furnitica.hideLoading();

                    furnitica.initQuickView();
                    furnitica.initAddToCart();
                  	furnitica.initWishLists();
                  	furnitica.initWishListIcons();
                    furnitica.initInfiniteScrolling();
                    furnitica.initScrollbar();
                },
                error: function(xhr, text) {
                    furnitica.hideLoading();
                    $('.loading-modal').hide();
                    $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);
                    furnitica.showModal('.ajax-error-modal');
                }
            });
        },
        sidebarParams: function() {
            Shopify.queryParams = {};
            //get after ?...=> Object {q: "Acme"} 
            if (location.search.length) {
                for (var aKeyValue, i = 0, aCouples = location.search.substr(1).split('&'); i < aCouples.length; i++) {
                    aKeyValue = aCouples[i].split('=');
                    if (aKeyValue.length > 1) {
                        Shopify.queryParams[decodeURIComponent(aKeyValue[0])] = decodeURIComponent(aKeyValue[1]);
                    }
                }
            }
        },
        initMobileSidebar: function() {
            //if ($(".header-mobile").is(":visible")) {
            $('footer').append("<a class='option-sidebar left' id='displayTextLeft' href='javascript:void(0)' title='Show Sidebar'><span>Show Sidebar</span></a>");
            $('#displayTextLeft').click(
                function(event) {
                    event.preventDefault();
                    if ($('.sidebar').is(":hidden")) {
                        //jQuery('.col-main').fadeOut(800);
                        $('.sidebar').fadeIn(800);
                        $('body,html').animate({
                            scrollTop: 200
                        }, 600);
                        $('#displayTextLeft').toggleClass('hidden-arrow-left');
                        $('#displayTextLeft').attr('title', 'hide-sidebar');
                        $('#displayTextLeft').html('<span>Hide Sidebar</span>');
                    } else {
                        $('.sidebar').fadeOut(800);
                        $('#displayTextLeft').removeClass('hidden-arrow-left');
                        $('#displayTextLeft').attr('title', 'show-sidebar');
                        $('#displayTextLeft').html('<span>Show Sidebar</span>');
                        //jQuery('.col-main').fadeIn(800);
                    }
                });
            //}
        },
        initSidebar: function() {
            //if category page then init sidebar
            if ($(".collection-sidebar").length >= 0) {
                furnitica.sidebarParams();
                furnitica.initSortby();
                furnitica.sidebarMapEvents();
                furnitica.sidebarMapPaging();
                furnitica.sidebarInitToggle();
                furnitica.sidebarMapClear();
                furnitica.sidebarMapClearAll();
                furnitica.ClearSelected();
            }
          
          	$(".sidebar-links.no-ajax li .caret").click(function(n)
            {
                var t = $(this).parent();
                if (t.hasClass("click"))
                {
                    t.removeClass("click");
                }
                else
                {
                    t.addClass("click");
                }              
                n.preventDefault();
            });
        },
      
        initSlideshow: function () {
          var slickSlideshow = $('[data-init-slideshow]');

          if (slickSlideshow.length) {
            slickSlideshow.each(function () {
              var self = $(this),
                  auto_playvideo = self.data('auto-video');

              if(auto_playvideo) {
                // POST commands to YouTube or Vimeo API
                function postMessageToPlayer(player, command) {
                  if (player == null || command == null) return;
                  player.contentWindow.postMessage(JSON.stringify(command), "*");
                }

                // When the slide is changing
                function playPauseVideo(slick, control) {
                  var currentSlide, player, video;

                  currentSlide = slick.find('.slick-active .slide-youtube');
                  player = currentSlide.find("iframe").get(0);

                  if (currentSlide.hasClass('slide-youtube')) {
                    switch (control) {
                      case "play":
                        postMessageToPlayer(player, {
                          "event": "command",
                          "func": "mute"
                        });
                        postMessageToPlayer(player, {
                          "event": "command",
                          "func": "playVideo"
                        });
                        break;

                      case "pause":
                        postMessageToPlayer(player, {
                          "event": "command",
                          "func": "pauseVideo"
                        });
                        break;
                    }

                  } else if (currentSlide.hasClass('slide-video')) {
                    video = currentSlide.children("video").get(0);

                    if (video != null) {
                      if (control === "play"){
                        video.play();
                      } else {
                        video.pause();
                      }
                    }
                  };
                };

                self.on('init', function(slick) {
                  slick = $(slick.currentTarget);

                  setTimeout(function(){
                    playPauseVideo(slick,"play");
                  }, 1000);
                });

                self.on("beforeChange", function(event, slick) {
                  slick = $(slick.$slider);
                  playPauseVideo(slick,"pause");
                });

                self.on("afterChange", function(event, slick) {
                  slick = $(slick.$slider);
                  playPauseVideo(slick,"play");
                });
              };

              if (self.not('.slick-initialized')) {
                self.slick({
                  slidesToScroll: 1,
                  fade: self.data('fade'),
                  cssEase: "ease",
                  adaptiveHeight: true,
                  autoplay: self.data('autoplay'),
                  autoplaySpeed: self.data('autoplay-speed'),
                  nextArrow: '<button type="button" class="slideshow-slick-next"><i class="fa fa-angle-right" aria-hidden="true"></i></button>',
                  prevArrow: '<button type="button" class="slideshow-slick-prev"><i class="fa fa-angle-left" aria-hidden="true"></i></button>'
                });
              };
            });
          };
        },
      
      
      
      	initMobileMenu: function() {
          if ($(".menu-block").is(':visible')) {
                $(".gf-menu-device-container ul.gf-menu li.dropdown").each(function() {
                    if ($(this).find("> p.toogleClick").length == 0) {
                        $(this).prepend('<p class="toogleClick">+</p>');
                    }
                });

                if ($(".menu-block").children().hasClass("gf-menu-device-wrapper") == false) {
                    $(".menu-block").children().addClass("gf-menu-device-wrapper");
                }
                if ($(".gf-menu-device-container").find("ul.gf-menu").size() == 0) {
                    $(".gf-menu-device-container").append($(".nav-bar .container").html());
                    $(".gf-menu-device-container .site-nav").addClass("gf-menu");
                    $(".gf-menu-device-container .site-nav").removeClass("nav")
                }
                $("p.toogleClick").click(function() {
                    if ($(this).hasClass("mobile-toggle-open")) {
                        $(this).next().next().hide();
                        $(this).removeClass("mobile-toggle-open");
                    } else {
                        $(this).next().next().show();
                        $(this).addClass("mobile-toggle-open")
                    }
                });
               var w = window.innerWidth;
                  if (w < 1024) {
                    jQuery('.site-nav .dropdown .menu__moblie').bind('click', function(event) {
                      if (currentEl != this) {
                        $(this).next().show();
                        $(this).prev().addClass('mobile-toggle-open');
                        event.preventDefault();
                        currentEl = this;
                      }
                    });
                  }
                $("p.toogleClick").show();
                $("div.gf-menu-toggle").hide();
                $(".nav-bar .container").hide();
                if ($("ul.gf-menu").hasClass("clicked") == false) {
                    $(".gf-menu").hide();
                    $(".gf-menu li.dropdown ul.site-nav-dropdown").hide();
                }


                $(".col-1 .inner ul.dropdown").parent().each(function() {
                    if ($(this).find("> p.toogleClick").length == 0) {
                        $(this).prepend('<p class="toogleClick">+</p>');
                    }
                });

                $(".cbp-spmenu span.icon-dropdown").remove();

                $("ul.gf-menu li.dropdown").each(function() {
                    if ($(this).find("> p.toogleClick").length == 0) {
                        $(this).prepend('<p class="toogleClick">+</p>');
                    }
                });
            

                $("p.toogleClick").click(function() {
                    if ($(this).hasClass("mobile-toggle-open")) {
                        $(this).next().next().hide();
                        $(this).removeClass("mobile-toggle-open");
                       $(this).text('+');
                    } else {
                        $(this).next().next().show();
                        $(this).addClass("mobile-toggle-open");
                      $(this).text('-');
                    }
                });

            } else {
                $(".nav-bar .container").show();
                $(".gf-menu").hide();
				
            }
            if ($(".menu-block").children().hasClass("gf-menu-device-wrapper") == false) {
                $(".menu-block").children().addClass("resized");
            };
          if ($('.header-mobile').is(':visible')) {            
            // $('.header-search').appendTo(jQuery('.search-mobile'));
            $('.lang-block').appendTo(jQuery('.opt-area'));
            $('.currency').appendTo(jQuery('.opt-area'));                
          }else {
            $('.lang-block').prependTo(jQuery('.right-header-top'));
            $('.currency').prependTo(jQuery('.right-header-top'));
          }
        },

        //opt header

        closeDropdownOpt: function() {
          if ($('.opt-area .dropdown-menu').is(':visible')) {
            $('.opt-area .dropdown-menu').slideUp('fast');
          }
        },

        initDropdownOpt: function() {
          if ($('.header-mobile').is(':visible')) {
            $('.lang-block').appendTo(jQuery('.opt-area .dropdown-menu'));
            $('.currency').appendTo(jQuery('.opt-area .dropdown-menu'));
            $('.opt-area .fa-cog').click(function(){                
              if ($('.opt-area .dropdown-menu').is(':visible')) {
                $('.opt-area .dropdown-menu').slideUp('fast');
              } else {
                $('.opt-area .dropdown-menu').slideDown('fast');
              }
            })
          } else {
            $('.lang-block').appendTo(jQuery('.header-panel-top .container'));
            $('.currency').appendTo(jQuery('.header-panel-top .container'));
          }

          $('.opt-area .fa-cog').click(function(){
            furnitica.closeDropdownCart();
          })


          $('#cartToggle').click(function(){
            furnitica.closeDropdownOpt();
          })
        },
        closeDropdownAccount: function() {
            if ($('.customer-area').hasClass('open')) {
                $('.customer-area').removeClass('open');
            }
        },
        initDropdownAccount: function() {
            if ($('.header-mobile').is(':visible')) {
                $('.lang-block').appendTo(jQuery('.customer-area .dropdown'));
                $('.currency').appendTo(jQuery('.customer-area .dropdown'));
            } else {
              	$('.lang-block').prependTo(jQuery('.header-panel .pull-left'));
                $('.currency').prependTo(jQuery('.header-panel .pull-left'));
            }
          
            $('.customer-area > a').click(function(){              
                if ($(this).parent().hasClass('open')) {
                    $(this).parent().removeClass('open');
                } else {
                    $(this).parent().addClass('open');
                }
            })

            $('#cartToggle').click(function(){
                furnitica.closeDropdownAccount();
            });
        },
      
      
      
      	createWishListTplItem: function(ProductHandle) {
            var wishListCotainer = $('[data-wishlist-container]');

            jQuery.getJSON(window.router + '/products/'+ProductHandle+'.js', function(product) {
                var productHTML = '',
                    price_min = Shopify.formatMoney(product.price_min, window.money_format);

                productHTML += '<div class="grid-item" data-wishlist-added="wishlist-'+product.id+'">';
                productHTML += '<div class="inner product-item" data-product-id="product-'+product.handle+'">';
                productHTML += '<div class="column col-img"><div class="product-image">';
                productHTML +='<a href="'+product.url+'" class="product-grid-image" data-collections-related="/collections/all?view=related">';
                productHTML += '<img src="'+product.featured_image+'" alt="'+product.featured_image.alt+'">';
                productHTML += '</a></div></div>';
                productHTML += '<div class="column col-prod">';
                productHTML += '<a class="product-title" href="'+product.url+'" title="'+product.title+'">'+product.title+'</a>';
                productHTML += '<div class="product-vendor">';
                productHTML += '<a href="/collections/vendors?q='+product.vendor+'" title="'+product.vendor+'">'+product.vendor+'</a></div></div>';
                productHTML += '<div class="column col-price text-center"><div class="price-box">'+ price_min +'</div></div>';
                productHTML += '<div class="column col-options text-center">';
                productHTML += '<form action="/cart/add" method="post" class="variants" id="wishlist-product-form-' + product.id +'" data-id="product-actions-'+product.id+'" enctype="multipart/form-data">';

                if (product.available) {
                    if (product.variants.length == 1) {
                        productHTML += '<button data-btn-addToCart class="btn add-to-cart-btn" data-form-id="#wishlist-product-form-' + product.id +'" type="submit">'+window.inventory_text.add_to_cart+'</button><input type="hidden" name="id" value="'+ product.variants[0].id +'" />';
                    }
                    if (product.variants.length > 1){
                        productHTML += '<a class="btn" title="'+product.title+'" href="' + product.url +'">'+window.inventory_text.select_options+'</a>';
                    }
                } else {
                    productHTML += '<button class="btn add-to-cart-btn" type="submit" disabled="disabled">'+window.inventory_text.unavailable+'</button>';
                }

                productHTML += '</form></div>';
                productHTML += '<div class="column col-remove text-center"><a class="whislist-added" href="#" data-product-handle="'+ product.handle +'" data-icon-wishlist data-id="'+ product.id +'"><svg class="closemnu" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 357 357" xml:space="preserve"><g><g><polygon points="357,35.7 321.3,0 178.5,142.8 35.7,0 0,35.7 142.8,178.5 0,321.3 35.7,357 178.5,214.2 321.3,357 357,321.3 214.2,178.5"></polygon></g></g></svg></a></div>';
                productHTML += '</div></div>';

                wishListCotainer.append(productHTML);
                var regex = /(<([^>]+)>)/ig;
                var href = $('.wrapper-wishlist a.share').attr("href");
                href += encodeURIComponent( product.title + '\nPrice: ' + price_min.replace(regex, "") + '\nLink: ' + window.location.protocol + '//' + window.location.hostname + product.url +'\n\n');
                $('.wrapper-wishlist a.share').attr("href", href );
            });
        },

        initWishListPagging: function() {
            var data = JSON.parse(localStorage.getItem('items'));

            var wlpaggingContainer = $('#wishlist-paginate');
            var paggingTpl = '<li class="text disabled prev"><a href="#" title="'+window.inventory_text.previous+'"><i class="fa fa-angle-left" aria-hidden="true"></i><span>'+window.inventory_text.previous+'</span></a></li>';
            var wishListCotainer = $('[data-wishlist-container]');

            wlpaggingContainer.children().remove();

            var totalPages = Math.ceil(data.length / 3);

            if (totalPages <= 1) {
                wishListCotainer.children().show();
                return;
            }

            for (var i = 0; i < totalPages; i++) {
                var pageNum = i + 1;
                if (i === 0) paggingTpl += '<li class="active"><a data-page="' + pageNum + '" href="'+ pageNum +'" title="'+ pageNum +'">' + pageNum + '</a></li>'
                else paggingTpl += '<li><a data-page="' + pageNum + '" href="'+ pageNum +'" title="'+ pageNum +'">' + pageNum + '</a></li>'
            }

            paggingTpl += '<li class="text next"><a href="#" title="'+window.inventory_text.next+'"><span>'+window.inventory_text.next+'</span><i class="fa fa-angle-right" aria-hidden="true"></i></a></li>';

            wlpaggingContainer.append(paggingTpl);

            wishListCotainer.children().each(function(idx, elm) {
                if (idx >= 0 && idx < 3) {
                    $(elm).show();
                }
                else {
                    $(elm).hide();
                }
            });

            wlpaggingContainer.off('click.wl-pagging').on('click.wl-pagging', 'li a', function(e) {
                e.preventDefault();

                var isPrev = $(this).parent().hasClass('prev');
                var isNext = $(this).parent().hasClass('next');
                var pageNumber = $(this).data('page');

                if (isPrev) {
                    var curPage = parseInt($(this).parent().siblings('.active').children().data('page'));
                    pageNumber = curPage - 1;
                }

                if (isNext) {
                    var curPage = parseInt($(this).parent().siblings('.active').children().data('page'));
                    pageNumber = curPage + 1;
                }

                wishListCotainer.children().each(function(idx, elm) {
                    if (idx >= (pageNumber - 1) * 3 && idx < pageNumber * 3) {
                        $(elm).show();
                    }
                    else {
                        $(elm).hide();
                    }
                });

                if (pageNumber === 1) {
                    wlpaggingContainer.find('.prev').addClass('disabled');
                    wlpaggingContainer.find('.next').removeClass('disabled');
                }
                else if (pageNumber === totalPages) {
                    wlpaggingContainer.find('.next').addClass('disabled');
                    wlpaggingContainer.find('.prev').removeClass('disabled');
                }
                else {
                    wlpaggingContainer.find('.prev').removeClass('disabled');
                    wlpaggingContainer.find('.next').removeClass('disabled');
                }

                $(this).parent().siblings('.active').removeClass('active');
                wlpaggingContainer.find('[data-page="' + pageNumber + '"]').parent().addClass('active');

            });
        },

        initWishLists: function() {
            if (typeof(Storage) !== 'undefined') {
                var data = JSON.parse(localStorage.getItem('items'));

                if (data.length <= 0) {
                    return;
                }
                data.forEach(function(item) {
                  
                    furnitica.createWishListTplItem(item);
                });

                this.initWishListPagging();
                this.translateBlock('.wishlist-page');

            } else {
                alert('Sorry! No web storage support..');
            }
        },

        setAddedForWishlistIcon: function(ProductHandle) {
            var wishlistElm = $('[data-product-handle="'+ ProductHandle +'"]'),
                idxArr = wishListsArr.indexOf(ProductHandle);

            if(idxArr >= 0) {
                wishlistElm.addClass('whislist-added');
                wishlistElm.find('.wishlist-text').text(window.inventory_text.remove_wishlist);
            }
            else {
                wishlistElm.removeClass('whislist-added');
                wishlistElm.find('.wishlist-text').text(window.inventory_text.add_wishlist);
            };
        },

        doAddOrRemoveWishlish: function() {
            var iconWishListsSlt = '[data-icon-wishlist]';

            doc.off('click.addOrRemoveWishlist', iconWishListsSlt).on('click.addOrRemoveWishlist', iconWishListsSlt, function(e) {
                e.preventDefault();

                var self = $(this),
                    productId = self.data('id'),
                    ProductHandle = self.data('product-handle'),
                    idxArr = wishListsArr.indexOf(ProductHandle);

                if(!self.hasClass('whislist-added')) {
                    self.addClass('whislist-added');
                    self.find('.wishlist-text').text(window.inventory_text.remove_wishlist);

                    if($('[data-wishlist-container]').length) {
                        furnitica.createWishListTplItem(ProductHandle);
                    };

                    wishListsArr.push(ProductHandle);
                    localStorage.setItem('items', JSON.stringify(wishListsArr));
                } else {
                    self.removeClass('whislist-added');
                    self.find('.wishlist-text').text(window.inventory_text.add_wishlist);

                    if($('[data-wishlist-added="wishlist-'+productId+'"]').length) {
                        $('[data-wishlist-added="wishlist-'+productId+'"]').remove();
                    }

                    wishListsArr.splice(idxArr, 1);
                    localStorage.setItem('items', JSON.stringify(wishListsArr));

                    if($('[data-wishlist-container]').length) {
                        furnitica.initWishListPagging();
                    };
                };

                furnitica.setAddedForWishlistIcon(ProductHandle);
            });
        },

        initWishListIcons: function() {
            var wishListItems = localStorage.getItem('items') ? JSON.parse(localStorage.getItem('items')) : [];

            if (!wishListItems.length) {
                return;
            }

            for (var i = 0; i < wishListItems.length; i++) {
                var icon = $('[data-product-handle="'+ wishListItems[i] +'"]');
                icon.addClass('whislist-added');
                icon.find('.wishlist-text').text(window.inventory_text.remove_wishlist);
            };
        },
      
      
      
      
        initColorSwatchGrid: function() { 
          jQuery('.item-swatch li label').hover(function(){
            var newImage = jQuery(this).parent().find('.hidden a').attr('href');
            jQuery(this).parents('.grid-item').find('.product-grid-image img').attr({ src: newImage }); 
            return false;
          });
        },
        initResizeImage: function() {
            if (window.product_image_resize) {
                $('.products-grid .product-image img').fakecrop({
                    fill: window.images_size.is_crop,
                    widthSelector: ".products-grid .grid-item .product-image",
                    ratioWrapper: window.images_size
                });
            }
        },
        initInfiniteScrolling: function() {
            if ($('.infinite-scrolling').length > 0) {
                $('.infinite-scrolling a').click(function(e) {
                    e.preventDefault();
                    if (!$(this).hasClass('disabled')) {
                        furnitica.doInfiniteScrolling();
                    }
                });
            }
        },
        doInfiniteScrolling: function() {
            var currentList = $('.block-row .products-grid');
            if (!currentList.length) {
                currentList = $('.block-row .product-list');
            }
            if (currentList) {
                var showMoreButton = $('.infinite-scrolling a').first();
                $.ajax({
                    type: 'GET',
                    url: showMoreButton.attr("href"),
                    beforeSend: function() {
                        furnitica.showLoading();
                        $('.loading-modal').show();
                    },
                    success: function(data) {
                        furnitica.hideLoading();
                        var products = $(data).find(".block-row .products-grid");
                        if (!products.length) {
                            products = $(data).find(".block-row .product-list");
                        }
                        if (products.length) {
                            if (products.hasClass('products-grid')) {
                                /*fake crop*/
                                if (window.product_image_resize) {
                                    products.children().find('img').fakecrop({
                                        fill: window.images_size.is_crop,
                                        widthSelector: ".products-grid .grid-item .product-image",
                                        ratioWrapper: window.images_size
                                    });
                                }
                            }

                            currentList.append(products.children());
                            furnitica.translateBlock("." + currentList.attr("class"));
                            furnitica.initQuickView();
                            furnitica.initAddToCart();
                          	furnitica.initWishLists();
                          	furnitica.initWishListIcons();
                            //get link of Show more
                            if ($(data).find('.infinite-scrolling').length > 0) {
                                showMoreButton.attr('href', $(data).find('.infinite-scrolling a').attr('href'));
                            } else {
                                //no more products
                                showMoreButton.hide();
                                showMoreButton.next().show();
                            }
                          
                          	//currency
                            if (window.show_multiple_currencies && window.shop_currency != jQuery(".currencies").val())
                            {
                              Currency.convertAll(window.shop_currency, jQuery(".currencies").val(), "span.money", "money_format")
                            }
                          
                            furnitica.initColorSwatchGrid();
                          
                            //product review
                            if ($(".spr-badge").length > 0) {
                                return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
                            }
                        }
                    },
                    error: function(xhr, text) {
                        furnitica.hideLoading();
                        $('.loading-modal').hide();
                        $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);
                        furnitica.showModal('.ajax-error-modal');
                    },
                    dataType: "html"
                });
            }
        },
        closeEmailModalWindow: function() {
            if ($('#email-modal').length > 0 && $('#email-modal').is(':visible')) {
                $('#email-modal .modal-window').fadeOut(600, function() {
                    $('#email-modal .modal-overlay').fadeOut(600, function() {
                        $('#email-modal').hide();
                        Cookies.set('emailSubcribeModal', 'closed', {
                            expires: 1,
                            path: '/'
                        });
                    });
                });
            }
        },
        showModal: function(selector) {
            $(selector).fadeIn(500)
            furnitica.furniticaTimeout = setTimeout(function() {
                $(selector).fadeOut(500);
            }, 5000);
        },
        initToggleCollectionPanel: function() {
            if ($('.collection-sharing-btn').length > 0) {
                $('.collection-sharing-btn').click(function() {
                    $('.collection-sharing-panel').toggle();
                    if ($('.collection-sharing-panel').is(':visible')) {
                        $('.collection-sharing-btn').addClass('btn-hover');
                        $('.collection-filter-panel').hide();
                        $('.collection-filter-btn').removeClass('btn-hover');
                    } else {
                        $('.collection-sharing-btn').removeClass('btn-hover');
                    }
                });
            }
            if ($('.collection-filter-btn').length > 0) {
                $('.collection-filter-btn').click(function() {
                    $('.collection-filter-panel').toggle();
                    if ($('.collection-filter-panel').is(':visible')) {
                        $('.collection-filter-btn').addClass('btn-hover');
                        $('.collection-sharing-panel').hide();
                        $('.collection-sharing-btn').removeClass('btn-hover');
                    } else {
                        $('.collection-filter-btn').removeClass('btn-hover');
                    }
                });
                $('.collection-filter-panel select').change(function(index) {
                    window.location = $(this).find('option:selected').val();
                });
            }
        },
        checkItemsInDropdownCart: function() {
            if ($('#dropdown-cart .mini-products-list').children().length > 0) {
                //Has item in dropdown cart
                $('#dropdown-cart .no-items').hide();
                $('#dropdown-cart .has-items').show();
            } else {
                //No item in dropdown cart                
                $('#dropdown-cart .has-items').hide();
                $('#dropdown-cart .no-items').show();
            }
        },
        initModal: function() {
            $('.continue-shopping').click(function() {
                clearTimeout(furnitica.furniticaTimeout);
                $('.ajax-success-modal').fadeOut(500);
            });
            $('.close-modal, .overlay').click(function() {
                clearTimeout(furnitica.furniticaTimeout);
                $('.ajax-success-modal').fadeOut(500);
            });
        },
        initDropDownCart: function() {
            if (window.dropdowncart_type == "click") {
                //click type  
                $('#cartToggle').click(function() {
                    if ($('#dropdown-cart').is(':visible')) {
                        $("#dropdown-cart").slideUp('fast');
                    } else {
                        $("#dropdown-cart").slideDown('fast');
                    }
                });
            } else {
                //hover type
                if (!('ontouchstart' in document)) {
                    $('#cartToggle').hover(function() {
                        if (!$('#dropdown-cart').is(':visible')) {
                            $("#dropdown-cart").slideDown('fast');
                        }
                    });
                    $('.wrapper-top-cart').mouseleave(function() {
                        $("#dropdown-cart").slideUp('fast');
                    });
                } else {
                    //mobile
                    $('#cartToggle').click(function() {
                        if ($('#dropdown-cart').is(':visible')) {
                            $("#dropdown-cart").slideUp('fast');
                        } else {
                            $("#dropdown-cart").slideDown('fast');
                        }
                    });
                }
            }

            furnitica.checkItemsInDropdownCart();

            $('#dropdown-cart .no-items a').click(function() {
                $("#dropdown-cart").slideUp('fast');
            });

            $('#dropdown-cart .btn-remove').click(function(event) {
                event.preventDefault();
                var productId = $(this).parents('.item').attr('id');
                productId = productId.match(/\d+/g);
                Shopify.removeItem(productId, function(cart) {
                    furnitica.doUpdateDropdownCart(cart);
                });
            });
        },
        closeDropdownCart: function() {
            if ($('#dropdown-cart').is(':visible')) {
                $("#dropdown-cart").slideUp('fast');
            }
        },
        initDropdownSearch: function() {
          $('.have-fixed .nav-search .icon-search').click(function() {
            if ($('.have-fixed .nav-search .search-bar').is(':visible')) {
              $('.have-fixed .nav-search .search-bar').slideUp('fast');
            } else {
              $('.have-fixed .nav-search .search-bar').slideDown('fast');
            }
          });
        },
        closeDropdownSearch: function() {
          if ($(".have-fixed .nav-search .search-bar").is(":visible")) {
            $(".have-fixed .nav-search .search-bar").slideUp("fast");
          }
        },
        initProductMoreview: function() {
            if ($('.more-view.horizontal').length > 0) {
                this.initOwlMoreview();
            } else if ($('.more-view.vertical').length > 0) {
                this.initJcarouselMoreview();
            }
        },
        initOwlMoreview: function() {  
//             $('.more-view.horizontal ul').owlCarousel({
//                 pagination: false,
//                 navigation: true,
//               	items : 5,
//                 itemsDesktop: [1199, 5],
//                 itemsDesktopSmall: [979, 4],
//                 itemsTablet: [767, 4],
//                 itemsTabletSmall: [540, 5],
//                 itemsMobile: [450, 4]
//             });
        },
        initJcarouselMoreview: function() {
            $('.more-view.vertical ul').jcarousel({
                vertical: true
            });
            if ($("#product-featured-image").length > 0) {
              var height_moreview = $("#product-featured-image").height();
              $('.more-view.vertical').css('height',height_moreview + 'px');
            }
        },
        initCloudzoom: function() {
            if ($("img[id|='product-featured-image']").length > 0) {
              if ($("img[id|='product-featured-image']").is(":visible")) {
                //mobile display
                $("img[id|='product-featured-image']").elevateZoom({

                    gallery: 'more-view-carousel',
                    cursor: 'pointer',
                    galleryActiveClass: 'active',
                    imageCrossfade: false,
                    scrollZoom: false,
                    onImageSwapComplete: function() {
                        $(".zoomWrapper div").hide();
                    },
                    loadingIcon: window.loading_url
                });
                $(".fancybox").fancybox();
              } else {
                $("img[id|='product-featured-image']").elevateZoom({
                    gallery: 'more-view-carousel',
                    cursor: 'pointer',
                    galleryActiveClass: 'active',
                    imageCrossfade: true,
                    scrollZoom: true,
                    onImageSwapComplete: function() {
                        $(".zoomWrapper div").hide();
                    },
                    loadingIcon: window.loading_url
                });

                $("img[id|='product-featured-image']").bind("click", function(e) {
                  var ez = $("img[id|='product-featured-image']").data('elevateZoom');
                  $.fancybox(ez.getGalleryList());
                  return false;
                });
              }
            }
        },
        initScrollTop: function() {
            $('#back-top').click(function() {
                $('body,html').animate({
                    scrollTop: 0
                }, 400);
                return false;
            });
        },
        initProductAddToCart: function() {
            if ($('#product-add-to-cart').length > 0) {
                $('#product-add-to-cart').click(function(event) {
                    event.preventDefault();
                    var self = $(this),
                        data = self.closest('form').serialize();
                    if ($(this).attr('disabled') != 'disabled') {
                        if (!window.ajax_cart) {
                            $(this).closest('form').submit();
                        } else {
//                             var variant_id = $('#add-to-cart-form select[name=id]').val();
//                             if (!variant_id) {
//                                 variant_id = $('#add-to-cart-form input[name=id]').val();
//                             }
//                             var quantity = $('#add-to-cart-form input[name=quantity]').val();
//                             if (!quantity) {
//                                 quantity = 1;
//                             }
                            var title = $('.product-title h3').html();
                            var image = $(".slick-active img[id|='product-featured-image']").attr('src');
                            furnitica.doAjaxAddToCart(data, title, image);
                        }
                    }
                    return false;
                });
            }
        },
        initAddToCart: function() {
            if ($('.add-to-cart-btn').length > 0) {
                $('.add-to-cart-btn').click(function(event) {
                    event.preventDefault();
                  	var self = $(this),
                        data = self.closest('form').serialize();
                    if ($(this).attr('disabled') != 'disabled') {
                        var productItem = $(this).parents('.product-item');
                        var productId = $(productItem).attr('id');
                        productId = productId.match(/\d+/g);
                        if (!window.ajax_cart) {
                            $('#product-actions-' + productId).submit();
                        } else {
//                             var variant_id = $('#product-actions-' + productId + ' select[name=id]').val();
//                             if (!variant_id) {
//                                 variant_id = $('#product-actions-' + productId + ' input[name=id]').val();
//                             }
//                             var quantity = $('#product-actions-' + productId + ' input[name=quantity]').val();
//                             if (!quantity) {
//                                 quantity = 1;
//                             }
                            var title = $(productItem).find('.product-title').html();
                            var image = $(productItem).find('.product-grid-image img').attr('src');
                            furnitica.doAjaxAddToCart(data, title, image);
                        }
                    }
                    return false;
                });
            }
        },
        showLoading: function() {
            $('.loading-modal').show();
        },
        hideLoading: function() {
            $('.loading-modal').hide();
        },
        doAjaxAddToCart: function(data, title, image) {
            $.ajax({
                type: "post",
                url: window.router + "/cart/add.js",
                data: data,
                dataType: 'json',
                beforeSend: function() {
                    furnitica.showLoading();
                },
                success: function(msg) {
                    furnitica.hideLoading();
                    $('.ajax-success-modal').find('.ajax-product-title').html(furnitica.translateText(title));
                    $('.ajax-success-modal').find('.ajax-product-image').attr('src', image);
                    $('.ajax-success-modal').find('.btn-go-to-wishlist').hide();
                    $('.ajax-success-modal').find('.btn-go-to-cart').show();

                    furnitica.showModal('.ajax-success-modal');
                    furnitica.updateDropdownCart();
                },
                error: function(xhr, text) {
                    furnitica.hideLoading();
                    $('.ajax-error-message').text($.parseJSON(xhr.responseText).description);
                    furnitica.showModal('.ajax-error-modal');
                }
            });
        },
        initQuickView: function() {
            $('.quickview-button a').click(function() {
                var product_handle = $(this).attr('id');
//                 Shopify.getProduct(product_handle, function(product) {
                jQuery.getJSON(window.router + '/products/'+product_handle+'.js', function(product) {
                    var template = $('#quickview-template').html();
                    $('.quick-view').html(template);
                    var quickview = $('.quick-view');

                    quickview.find('.product-title a').html(furnitica.translateText(product.title));
                    quickview.find('.product-title a').attr('href', product.url);
                    if (quickview.find('.sample-vendor > span').length > 0) {
                        quickview.find('.sample-vendor > span').text(product.vendor);
                    }
                    if (quickview.find('.product-vendor > span').length > 0) {
                        quickview.find('.product-vendor > span').text(product.vendor);
                    }
                    if (quickview.find('.product-type > span').length > 0) {
                        quickview.find('.product-type > span').text(product.type);
                    }
                    if (quickview.find('.variant-sku > span').length > 0) {
                          quickview.find('.variant-sku > span').text(product.sku);
                    }	
                    if (quickview.find('.product-inventory > span').length > 0) {
                      var variant = product.variants[0];
                      var inventoryInfo = quickview.find('.product-inventory > span');                      
                      if (variant.available) {
                        if (variant.inventory_management!=null) {
                          inventoryInfo.text(window.inventory_text.in_stock);
                        } else {
                          inventoryInfo.text(window.inventory_text.many_in_stock);
                        }
                      } else {
                        inventoryInfo.text(window.inventory_text.out_of_stock);
                      }
                    }
                    //countdown for quickview
                    
 					if(product.description != null) {
                    if (product.description.indexOf("[countdown]") > 0) {
                        var countdownTime = product.description.match(/\[countdown\](.*)\[\/countdown\]/);
                        if (countdownTime && countdownTime.length > 0) {
                            quickview.find(".countdown").show();
                            quickview.find(".quickview-clock").countdown(countdownTime[1], function(event) {
                                $(this).html(event.strftime('%Dd %H:%M:%S'));
                            });
                        }
                    }else{quickview.find('.countdown').remove();}
                    if (quickview.find('.short-description').length > 0) {
                        var ahihi = product.description.replace(/(<([^>]+)>)/ig, "");
                        var ahoho = ahihi.replace(/\[countdown\](.*)\[\/countdown\]/g, "");
                        var description = ahoho.replace(/\[custom-tab\](.*)([^>]+)(.*)\[\/custom-tab\]/g, "");
                        if (window.multi_lang) {
                          if (description.indexOf("[lang2]") > 0) {
                            var descList = description.split("[lang2]");
                            if (jQuery.cookie("language") != null) {
                                description = descList[translator.current_lang - 1];
                            } else {
                                description = descList[0];
                            }
                          }
                        }
                        description = description.split(" ").splice(0, 30).join(" ") + "...";
                        quickview.find('.short-description').text(description);
                    } else {
                        quickview.find('.short-description').remove();
                    }
                  }

                    quickview.find('.price').html(Shopify.formatMoney(product.price, window.money_format));
                    quickview.find('.product-item').attr('id', 'product-' + product.id);
                    quickview.find('.variants').attr('id', 'product-actions-' + product.id);
                  
                  quickview.find('.product-img-box').attr('id', 'product-' + product.id);
                  
                    quickview.find('.variants select').attr('id', 'product-select-' + product.id);
                  
                  // review
                  	var in_fo = $('#product-'+ product.id +' .spr-badge').html();
          	 		$('#product-'+ product.id +' .re_view').html(in_fo);
					
                   // Sold Out 
                  

                  	var in_fo = $('#product-'+ product.id +' .product-label').html();
          	 		$('#product-'+ product.id +' .product-label-qiuck').html(in_fo);
                  
                  
                    //if has compare price
                    if (product.compare_at_price > product.price) {
                        quickview.find('.compare-price').html(Shopify.formatMoney(product.compare_at_price_max, window.money_format)).show();
                        quickview.find('.price').addClass('on-sale');
                    } else {
                        quickview.find('.compare-price').hide();
                        quickview.find('.price').removeClass('on-sale');
                    }

                    //out of stock
                    if (!product.available) {
                        quickview.find("select, input, .total-price, .dec, .inc, .variants label, .extra").remove();
                        quickview.find(".add-to-cart-btn").text(window.inventory_text.unavailable).addClass('disabled').attr("disabled", "disabled");;
                    } else {
                        quickview.find('.total-price span').html(Shopify.formatMoney(product.price, window.money_format));
                        if (window.use_color_swatch) {
                            furnitica.createQuickViewVariantsSwatch(product, quickview);
                        } else {
                            furnitica.createQuickViewVariants(product, quickview);
                        }
                    }

                    //quantity
                    quickview.find(".button").on("click", function() {
                        var oldValue = quickview.find(".quantity").val(),
                            newVal = 1;
                        if ($(this).text() == "+") {
                            newVal = parseInt(oldValue) + 1;
                        } else if (oldValue > 1) {
                            newVal = parseInt(oldValue) - 1;
                        }
                        quickview.find(".quantity").val(newVal);

                        if (quickview.find(".total-price").length > 0) {
                            furnitica.updatePricingQuickview();
                        }
                    });

                    if (furnitica.checkNeedToConvertCurrency()) {
                      Currency.convertAll(window.shop_currency, jQuery('.currencies').val(), 'span.money', 'money_format');
                    }

                    furnitica.loadQuickViewSlider(product, quickview);
                    furnitica.initQuickviewAddToCart();
                    furnitica.translateBlock(".quick-view");

                    $('.quick-view').fadeIn(500);
                    if ($('.quick-view .total-price').length > 0) {
                        $('.quick-view input[name=quantity]').on('change', furnitica.updatePricingQuickview);
                    }
                });

                return false;
            });

            $(document).on("click", ".quick-view .overlay, .close-window", function() {
                furnitica.closeQuickViewPopup();
                return false;
            });
        },
        updatePricingQuickview: function() {
            //try pattern one before pattern 2
          
            var quantity = parseInt($('.quick-view input[name=quantity]').val());
            var p = $('.quick-view #product_regular_price').val();
            var totalPrice1 = p * quantity;
            var g = Shopify.formatMoney(totalPrice1, window.money_format);
            $('.quick-view .total-price span').html(g);

            if (furnitica.checkNeedToConvertCurrency()) {
              Currency.convertAll(window.shop_currency, jQuery('.currencies').val(), 'span.money', 'money_format');
            }
          
          
          
          
//             var regex = /([0-9]+[.|,][0-9]+[.|,][0-9]+)/g;
//             var unitPriceTextMatch = $('.quick-view .price').text().match(regex);

//             if (!unitPriceTextMatch) {
//                 regex = /([0-9]+[.|,][0-9]+)/g;
//                 unitPriceTextMatch = $('.quick-view .price').text().match(regex);
//             }

//             if (unitPriceTextMatch) {
//                 var unitPriceText = unitPriceTextMatch[0];
//                 var unitPrice = unitPriceText.replace(/[.|,]/g, '');
//                 var quantity = parseInt($('.quick-view input[name=quantity]').val());
//                 var totalPrice = unitPrice * quantity;

//                 var totalPriceText = Shopify.formatMoney(totalPrice, window.money_format);
//                 regex = /([0-9]+[.|,][0-9]+[.|,][0-9]+)/g;     
//                 if (!totalPriceText.match(regex)) {
//                    regex = /([0-9]+[.|,][0-9]+)/g;
//                 } 
//                 totalPriceText = totalPriceText.match(regex)[0];

//                 var regInput = new RegExp(unitPriceText, "g");
//                 var totalPriceHtml = $('.quick-view .price').html().replace(regInput, totalPriceText);

//                 $('.quick-view .total-price span').html(totalPriceHtml);
//             }
        },
        initQuickviewAddToCart: function() {
            if ($('.quick-view .add-to-cart-btn').length > 0) {
                $('.quick-view .add-to-cart-btn').click(function() {
                  	var self = $(this),
                        data = self.closest('form').serialize();
//                     var variant_id = $('.quick-view select[name=id]').val();
//                     if (!variant_id) {
//                         variant_id = $('.quick-view input[name=id]').val();
//                     }
//                     var quantity = $('.quick-view input[name=quantity]').val();
//                     if (!quantity) {
//                         quantity = 1;
//                     }

                    var title = $('.quick-view .product-title a').html();
                    var image = $('.quick-view .quickview-featured-image img').attr('src');
                    furnitica.doAjaxAddToCart(data, title, image);
                    furnitica.closeQuickViewPopup();
                });
            }
        },
        updateDropdownCart: function() {
            Shopify.getCart(function(cart) {
                furnitica.doUpdateDropdownCart(cart);
            });
        },
        doUpdateDropdownCart: function(cart) {
            var template = '<li class="item" id="cart-item-{ID}"><a href="{URL}" title="{TITLE}" class="product-image"><img src="{IMAGE}" alt="{TITLE}"></a><div class="product-details"><a href="javascript:void(0)" title="Remove This Item" class="btn-remove">X</a><p class="product-name"><a href="{URL}">{TITLE}</a></p><div class="cart-collateral"><span class="price">{PRICE}</span> x {QUANTITY}</div></div></li>';

            $('#cartCount').text(cart.item_count);
            /*Total price*/
            $('#dropdown-cart .summary .price').html(Shopify.formatMoney(cart.total_price, window.money_format));
            /*Clear cart*/
            $('#dropdown-cart .mini-products-list').html('');
            /*Add product to cart*/
            if (cart.item_count > 0) {
                for (var i = 0; i < cart.items.length; i++) {
                    var item = template;
                    item = item.replace(/\{ID\}/g, cart.items[i].id);
                    item = item.replace(/\{URL\}/g, cart.items[i].url);
                    item = item.replace(/\{TITLE\}/g, furnitica.translateText(cart.items[i].title));
                    item = item.replace(/\{QUANTITY\}/g, cart.items[i].quantity);
                    item = item.replace(/\{IMAGE\}/g, Shopify.resizeImage(cart.items[i].image, 'small'));
                    item = item.replace(/\{PRICE\}/g, Shopify.formatMoney(cart.items[i].price, window.money_format));
                    $('#dropdown-cart .mini-products-list').append(item);
                }
                $('#dropdown-cart .btn-remove').click(function(event) {
                    event.preventDefault();
                    var productId = $(this).parents('.item').attr('id');
                    productId = productId.match(/\d+/g);
                    Shopify.removeItem(productId, function(cart) {
                        furnitica.doUpdateDropdownCart(cart);
                    });
                });
                if (furnitica.checkNeedToConvertCurrency()) {
                    Currency.convertAll(window.shop_currency, jQuery('.currencies').val(), '#dropdown-cart span.money', 'money_format');
                }
            }
            furnitica.checkItemsInDropdownCart();
        },
        checkNeedToConvertCurrency: function() {
            return (window.show_multiple_currencies && Currency.currentCurrency != shopCurrency) || window.show_auto_currency;
        },
        loadQuickViewSlider: function(product, quickviewTemplate) {
          var featuredImage = Shopify.resizeImage(product.featured_image, 'grande');
          quickviewTemplate.find('.quickview-featured-image').append('<a href="' + product.url + '"><img src="' + featuredImage + '" title="' + product.title + '"/><div style="height: 100%; width: 100%; top:0; left:0 z-index: 2000; position: absolute; display: none; background: url(' + window.loading_url + ') 50% 50% no-repeat;"></div></a>');
// 		  quickviewTemplate.find('.rating').attr('data-id', product.id);
          quickviewTemplate.find('.product-label strong.new').append(product.tags);
            if (product.images.length > 1) {
                var quickViewCarousel = quickviewTemplate.find('.quick-view-more-view ul');
                var count = 0;
                for (i in product.images) {
                  if (count < product.images.length) {
                    var grande = Shopify.resizeImage(product.images[i], 'grande');
                    var compact = Shopify.resizeImage(product.images[i], 'compact');
                    var item = '<li><a href="javascript:void(0)" data-image="' + grande + '"><img src="' + compact + '"  /></a></li>'

                    quickViewCarousel.append(item);
                    count = count + 1;
                  }
                }

                quickViewCarousel.find('a').click(function() {
                    var quickViewFeatureImage = quickviewTemplate.find('.quickview-featured-image img');
                    var quickViewFeatureLoading = quickviewTemplate.find('.quickview-featured-image div');
                    if (quickViewFeatureImage.attr('src') != $(this).attr('data-image')) {
                        quickViewFeatureImage.attr('src', $(this).attr('data-image'));
                        quickViewFeatureLoading.show();
                        quickViewFeatureImage.load(function(e) {
                            quickViewFeatureLoading.hide();
                            $(this).unbind('load');
                            quickViewFeatureLoading.hide();
                        });
                    }
                });
                if (quickViewCarousel.parent().hasClass("horizontal")) {
                    furnitica.initQuickViewCarousel(quickViewCarousel);
                } else {
                    furnitica.initQuickViewVerticalMoreview(quickViewCarousel);
                }
            } else {
                quickviewTemplate.find('.quickview-more-views').remove();
            }

        },
        initQuickViewCarousel: function(quickViewCarousel) {
            if (quickViewCarousel) {
                quickViewCarousel.owlCarousel({
                    pagination: false,
                    navigation: true,
                    items: 5,
                    itemsDesktop: [1199, 4],
                    itemsDesktopSmall: [979, 3],
                    itemsTablet: [768, 3],
                    itemsTabletSmall: [540, 3],
                    itemsMobile: [360, 3]
                });
            }
        },
        initQuickViewVerticalMoreview: function(quickViewCarousel) {
            if (quickViewCarousel) {
                if (jQuery(".quick-view-more-view.vertical ul").children().length > 3) {
                  jQuery(".quick-view-more-view").niceScroll({
                    cursoropacitymin: 1,
                    cursorborder:"",
                    cursorwidth: "5px",
                    cursorcolor:"#d2d2d2",
                    cursorborderradius:0,
                    background: "#ebebeb"
                  });
                }
              
                $('.product-img-box').addClass('has-jcarousel');
            }
        },
        convertToSlug: function(text) {
            return text
                .toLowerCase()
                .replace(/[^a-z0-9 -]/g, '') // remove invalid chars
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-');
        },
        createQuickViewVariantsSwatch: function(product, quickviewTemplate) {
            if (product.variants.length > 1) { //multiple variants
                for (var i = 0; i < product.variants.length; i++) {
                    var variant = product.variants[i];
                    var option = '<option value="' + variant.id + '">' + variant.title + '</option>';
                    quickviewTemplate.find('form.variants > select').append(option);
                }
                new Shopify.OptionSelectors("product-select-" + product.id, {
                    product: product,
                    onVariantSelected: selectCallbackQuickview
                });

                //start of quickview variant;
                var filePath = window.file_url.substring(0, window.file_url.lastIndexOf('?'));
                var assetUrl = window.asset_url.substring(0, window.asset_url.lastIndexOf('?'));
                var options = "";
                for (var i = 0; i < product.options.length; i++) {
                    options += '<div class="swatch clearfix" data-option-index="' + i + '">';
                    options += '<div class="header">' + product.options[i].name + '<span>*</span></div>';
                    var is_color = false;
                    if (/Color|Colour/i.test(product.options[i].name)) {
                        is_color = true;
                    }
                    var optionValues = new Array();
                    for (var j = 0; j < product.variants.length; j++) {
                        var variant = product.variants[j];
                        var value = variant.options[i];
                        var valueHandle = this.convertToSlug(value);
                        var forText = 'swatch-' + i + '-' + valueHandle;
                        if (optionValues.indexOf(value) < 0) {
                            //not yet inserted
                            options += '<div data-value="' + value + '" class="swatch-element ' + (is_color ? "color" : "") + valueHandle + (variant.available ? ' available ' : ' soldout ') + '">';

                            if (is_color) {
                                options += '<div class="tooltip">' + value + '</div>';
                            }
                            options += '<input id="' + forText + '" type="radio" name="option-' + i + '" value="' + value + '" ' + (j == 0 ? ' checked ' : '') + (variant.available ? '' : ' disabled') + ' />';

                            if (is_color) {
                                options += '<label for="' + forText + '" style="background-color: ' + valueHandle + '; background-image: url(' + filePath + valueHandle + '.png)"><img class="crossed-out" src="' + assetUrl +'" /></label>';
                            } else {
                                options += '<label for="' + forText + '">' + value + '<img class="crossed-out" src="' + assetUrl + '" /></label>';
                            }
                            options += '</div>';
                            if (variant.available) {
                                $('.quick-view .swatch[data-option-index="' + i + '"] .' + valueHandle).removeClass('soldout').addClass('available').find(':radio').removeAttr('disabled');
                            }
                            optionValues.push(value);
                        }
                    }
                    options += '</div>';
                }
                quickviewTemplate.find('form.variants > select').after(options);
                quickviewTemplate.find('.swatch :radio').change(function() {
                    var optionIndex = $(this).closest('.swatch').attr('data-option-index');
                    var optionValue = $(this).val();
                    $(this)
                        .closest('form')
                        .find('.single-option-selector')
                        .eq(optionIndex)
                        .val(optionValue)
                        .trigger('change');
                });
                if (product.available) {
                    Shopify.quickViewOptionsMap = {};
                    Shopify.linkOptionSelectors(product, '.quick-view');
                }

                //end of quickview variant
            } else { //single variant
                quickviewTemplate.find('form.variants > select').remove();
                var variant_field = '<input type="hidden" name="id" value="' + product.variants[0].id + '">';
                quickviewTemplate.find('form.variants').append(variant_field);
            }
        },
        createQuickViewVariants: function(product, quickviewTemplate) {
            if (product.variants.length > 1) { //multiple variants
                for (var i = 0; i < product.variants.length; i++) {
                    var variant = product.variants[i];
                    var option = '<option value="' + variant.id + '">' + variant.title + '</option>';
                    quickviewTemplate.find('form.variants > select').append(option);
                }

                new Shopify.OptionSelectors("product-select-" + product.id, {
                    product: product,
                    onVariantSelected: selectCallbackQuickview
                });
                $('.quick-view .single-option-selector').selectize();
                $('.quick-view .selectize-input input').attr("disabled", "disabled");

                if (product.options.length == 1) {
                    $('.selector-wrapper:eq(0)').prepend('<label>' + product.options[0].name + '</label>');
                }
                quickviewTemplate.find('form.variants .selector-wrapper label').each(function(i, v) {
                    $(this).html(product.options[i].name);
                });
            } else { //single variant
                quickviewTemplate.find('form.variants > select').remove();
                var variant_field = '<input type="hidden" name="id" value="' + product.variants[0].id + '">';
                quickviewTemplate.find('form.variants').append(variant_field);
            }

        },
        closeQuickViewPopup: function() {
            $('.quick-view').fadeOut(500);
        },
        translateText: function(str) {
          if (!window.multi_lang || str.indexOf("|") < 0)
            return str;

          if (window.multi_lang) {
            var textArr = str.split("|");
            if (translator.isLang2())
              return textArr[1];
            return textArr[0];
          }          
        },
        checkbox_checkout: function(){
          var inputWrapper = $('.checkbox-group label');  

          var checkBox = $('.checkbox-group input[type="checkbox"]');

          setTimeout(function(){
            checkBox.each(function(){
              if ($(this).is(':checked')) {
                $(this).parent().parent().find('.btn-checkout').removeClass('show');
              } else {
                $(this).parent().parent().find('.btn-checkout').addClass('show');
              }
            });
          },300);

          inputWrapper.off('click').on('click', function (e) {
            var inputTrigger= $(this).parent().find('.conditions'),
                divAddClassbtn = $(this).parent().parent().find('.btn-checkout');

            if (!inputTrigger.is(':checked')) {
              divAddClassbtn.removeClass('show');
              inputTrigger.prop('checked', true);
            } else {
              divAddClassbtn.addClass('show');
              inputTrigger.prop('checked', false);
            }

          });
        },
      
      	productRecomendation: function() {
          var $container = $('.js-product-recomendation');
          var productId = $container.data('productId');
          var template = $container.data('template');
          var sectionId = $container.data('sectionId');
          var limit = $container.data('limit');
          var productRecommendationsUrlAndContainerClass =
              window.router + '/recommendations/products?&section_id='+ sectionId +'&limit=' + limit + '&product_id=' + productId + ' .product-recommendations';
          $container.parent().load(productRecommendationsUrlAndContainerClass, function(){
            furnitica.translateBlock('#product-recommendations');
            furnitica.initQuickView();
            if (furnitica.checkNeedToConvertCurrency()) {
              Currency.convertAll(window.shop_currency, jQuery('.currencies').val(), '.col-main span.money', 'money_format');
            }
          });
          
        },
      
        translateBlock: function(blockSelector) {
          if (window.multi_lang && translator.isLang2()) {
            translator.doTranslate(blockSelector);
          }
        }
    }
//     $('a').on('click touchend', function(e) {
// var el = $(this);
// var link = el.attr('href');
// window.location = link;
//});
})(jQuery);
$( window ).resize(function() {
      if ($("#product-featured-image").length > 0) {
        var height_moreview = $("#product-featured-image").height();
        $('.more-view.vertical').css('height',height_moreview + 'px');
      }
})